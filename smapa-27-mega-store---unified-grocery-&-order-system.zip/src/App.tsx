import React, { useState, useEffect } from 'react';
import {
  Package, ShoppingBag, Heart, PhoneCall, Sparkles, AlertCircle,
  CheckCircle2, RefreshCw, MessageCircle, ShieldCheck, ChevronRight
} from 'lucide-react';
import { Language, Product, Order, CartItem, CustomerProfile } from './types';
import { TRANSLATIONS } from './translations';
import { UnifiedStore } from './services/store';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { ProductCard } from './components/ProductCard';
import { ProductDetailsModal } from './components/ProductDetailsModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { OrderSuccessModal } from './components/OrderSuccessModal';
import { OrderTrackerModal } from './components/OrderTrackerModal';
import { FavouritesModal } from './components/FavouritesModal';
import { WhatsAppContactModal } from './components/WhatsAppContactModal';
import { PaymentGatewayModal } from './components/PaymentGatewayModal';
import { ShareStoreModal } from './components/ShareStoreModal';
import { CustomerAuthModal } from './components/CustomerAuthModal';
import { AdminPortal, AdminTab } from './components/admin/AdminPortal';
import { FolderCatalogExplorer } from './components/FolderCatalogExplorer';

export default function App() {
  const [lang, setLang] = useState<Language>('si'); // Default to Sinhala per user brief, easily toggled!
  const [isAdminMode, setIsAdminMode] = useState<boolean>(false);
  const [adminInitialTab, setAdminInitialTab] = useState<AdminTab>('dashboard');
  const [activeCustomer, setActiveCustomer] = useState<CustomerProfile | null>(UnifiedStore.getActiveCustomer());
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Store data state
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [favourites, setFavourites] = useState<string[]>([]);
  const [categories, setCategories] = useState(UnifiedStore.getCategories());

  // Modals state
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isTrackerOpen, setIsTrackerOpen] = useState(false);
  const [isFavsOpen, setIsFavsOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isAuthOpen, setIsAuthOpen] = useState(false);
  const [isPaymentGatewayOpen, setIsPaymentGatewayOpen] = useState(false);
  const [paymentGatewayOrder, setPaymentGatewayOrder] = useState<Order | null>(null);
  const [activeProductDetail, setActiveProductDetail] = useState<Product | null>(null);
  const [recentOrderSuccess, setRecentOrderSuccess] = useState<Order | null>(null);
  const [trackOrderNumber, setTrackOrderNumber] = useState<string>('');

  // Toast notification
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3200);
  };

  // Sync state with UnifiedStore & listen for cross-tab updates
  const syncFromStore = () => {
    setProducts([...UnifiedStore.getProducts()]);
    setCart([...UnifiedStore.getCart()]);
    setFavourites([...UnifiedStore.getFavourites()]);
    setCategories([...UnifiedStore.getCategories()]);
  };

  useEffect(() => {
    syncFromStore();
    const unsubscribe = UnifiedStore.subscribe(syncFromStore);

    const handleStorage = () => syncFromStore();
    window.addEventListener('storage', handleStorage);
    window.addEventListener('lankamart_state_updated', handleStorage);

    return () => {
      unsubscribe();
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('lankamart_state_updated', handleStorage);
    };
  }, []);

  const t = TRANSLATIONS[lang];
  const isSi = lang === 'si';

  // Cart calculations
  const cartTotal = cart.reduce((sum, item) => sum + (item.unitPrice || item.product.price) * item.quantity, 0);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const lowStockCount = products.filter((p) => p.stock <= p.minStockAlert).length;

  // Handlers
  const handleAddToCart = (product: Product, qty: number = 1) => {
    const res = UnifiedStore.addToCart(product, qty);
    if (res.success) {
      showToast(isSi ? `"${product.nameSi}" කරත්තයට එක් කළා!` : `Added "${product.name}" to cart!`, 'success');
    } else {
      showToast(res.message || (isSi ? 'භාණ්ඩය එක් කළ නොහැක' : 'Cannot add item'), 'error');
    }
  };

  const handleUpdateCartQty = (productId: string, qty: number) => {
    UnifiedStore.updateCartQuantity(productId, qty);
  };

  const handleRemoveFromCart = (productId: string) => {
    UnifiedStore.removeFromCart(productId);
  };

  const handleClearCart = () => {
    UnifiedStore.clearCart();
    showToast(isSi ? 'කරත්තය හිස් කරන ලදී.' : 'Cart cleared.');
  };

  const handleToggleFav = (productId: string) => {
    const added = UnifiedStore.toggleFavourite(productId);
    showToast(
      added
        ? (isSi ? 'කැමති දෑ ලැයිස්තුවට එකතු කළා ❤️' : 'Added to Favourites ❤️')
        : (isSi ? 'කැමති දෑ ලැයිස්තුවෙන් ඉවත් කළා' : 'Removed from Favourites'),
      'info'
    );
  };

  const handleProceedToCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleQuickWhatsAppOrder = () => {
    if (cart.length === 0) return;
    const totalRegularPrice = cart.reduce((sum, item) => {
      const orig = item.product.originalPrice && item.product.originalPrice > item.product.price
        ? item.product.originalPrice
        : item.product.price;
      return sum + orig * item.quantity;
    }, 0);
    const totalSavings = Math.max(0, totalRegularPrice - cartTotal);

    const lines = [
      `*🛒 ${isSi ? 'SMAPA 27 මෙගා ස්ටෝර් ඉක්මන් ඇණවුම' : 'SMAPA 27 Mega Store Quick WhatsApp Order'}*`,
      ``,
      ...cart.map((item, idx) => {
        const hasD = item.product.originalPrice && item.product.originalPrice > item.product.price;
        const priceStr = hasD
          ? `(Original: රු. ${item.product.originalPrice} ➔ Now: රු. ${item.product.price})`
          : `(රු. ${item.product.price})`;
        return `${idx + 1}. ${isSi ? item.product.nameSi : item.product.name} ${priceStr} × ${item.quantity} = රු. ${(item.product.price * item.quantity).toLocaleString()}`;
      }),
      ``,
      ...(totalSavings > 0 ? [`*🎉 ඔබ ඉතිරි කළ මුළු වට්ටම් මුදල: රු. ${totalSavings.toLocaleString()}*`, ``] : []),
      `*මුළු එකතුව: රු. ${cartTotal.toLocaleString()}*`,
      ``,
      isSi ? 'මගේ ලිපිනයට මෙම භාණ්ඩ එවීමට කටයුතු කරන්න. ස්තුතියි!' : 'Please deliver these items to my address. Thank you!'
    ];
    const url = `https://wa.me/94774778190?text=${encodeURIComponent(lines.join('\n'))}`;
    window.open(url, '_blank');
  };

  const handleOrderSuccess = (order: Order) => {
    setIsCheckoutOpen(false);
    setRecentOrderSuccess(order);
    showToast(isSi ? 'ඇණවුම සාර්ථකව භාරගන්නා ලදී! 🎉' : 'Order placed successfully! 🎉', 'success');

    // If card or bank transfer, prompt Payment Gateway Modal
    if (order.paymentMethod === 'card' || order.paymentMethod === 'bank_transfer') {
      setPaymentGatewayOrder(order);
      setIsPaymentGatewayOpen(true);
    }
  };

  const handleOpenTracker = (orderNum?: string) => {
    if (orderNum) {
      setTrackOrderNumber(orderNum);
    }
    setIsTrackerOpen(true);
  };

  // Filter products by Category, Deals, and Search
  const filteredProducts = products.filter((p) => {
    if (!p.isActive) return false;
    const matchesCategory =
      selectedCategory === 'all'
        ? true
        : selectedCategory === 'deals'
        ? Boolean((p.originalPrice && p.originalPrice > p.price) || p.isHotDeal)
        : p.category === selectedCategory;

    const matchesSearch =
      searchTerm.trim() === '' ||
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.nameSi.includes(searchTerm) ||
      p.brand.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.category.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // If in Admin Mode, show Admin Portal
  if (isAdminMode) {
    return (
      <AdminPortal
        lang={lang}
        initialTab={adminInitialTab}
        onCloseAdmin={() => {
          setIsAdminMode(false);
          setAdminInitialTab('dashboard');
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 animate-in slide-in-from-bottom-5 fade-in duration-200">
          <div
            className={`px-4 py-3 rounded-2xl shadow-xl border text-xs font-bold flex items-center gap-2.5 ${
              toast.type === 'error'
                ? 'bg-rose-900 text-white border-rose-700'
                : toast.type === 'info'
                ? 'bg-slate-900 text-white border-slate-700'
                : 'bg-emerald-900 text-white border-emerald-700'
            }`}
          >
            {toast.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            )}
            <span>{toast.message}</span>
          </div>
        </div>
      )}

      {/* Header */}
      <Header
        lang={lang}
        onToggleLang={() => setLang(lang === 'en' ? 'si' : 'en')}
        isAdminMode={isAdminMode}
        onToggleAdmin={() => {
          setAdminInitialTab('dashboard');
          setIsAdminMode(true);
        }}
        onOpenStep7={() => {
          setAdminInitialTab('notifications');
          setIsAdminMode(true);
        }}
        onOpenShareStore={() => setIsShareModalOpen(true)}
        onOpenAuth={() => setIsAuthOpen(true)}
        currentCustomer={activeCustomer}
        onLogoutCustomer={() => {
          UnifiedStore.logoutCustomer();
          setActiveCustomer(null);
          showToast(lang === 'si' ? 'ගිණුමෙන් ඉවත් විය.' : 'Logged out successfully.', 'info');
        }}
        cartCount={cartCount}
        cartTotal={cartTotal}
        favCount={favourites.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenFavs={() => setIsFavsOpen(true)}
        onOpenTracker={() => handleOpenTracker()}
        onOpenContact={() => setIsContactOpen(true)}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        lowStockCount={lowStockCount}
      />

      {/* Hero Banner with omnichannel highlight & category chips */}
      <HeroBanner
        lang={lang}
        categories={categories}
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex-1 w-full space-y-6">
        {/* Section title & product counter */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-2 border-b border-slate-200/80">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span>
                {selectedCategory === 'all'
                  ? (isSi ? '🛒 සුපිරි වෙළඳසැල් කාණ්ඩ ෆෝල්ඩර' : '🛒 Supermarket Category Folders')
                  : categories.find((c) => c.id === selectedCategory)?.[isSi ? 'nameSi' : 'name']}
              </span>
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                {filteredProducts.length} {isSi ? 'ක්' : 'items'}
              </span>
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              {isSi
                ? 'කඩේ සජීවී තොගය අනුව ක්ෂණිකව මිලදී ගත හැක (Real-Time Synchronized Stock)'
                : 'Live warehouse stock updated in real time with physical shop counter'}
            </p>
          </div>

          {/* Omnichannel quick tester notice */}
          <button
            onClick={() => setIsAdminMode(true)}
            className="text-xs text-emerald-700 hover:text-emerald-800 font-semibold flex items-center gap-1.5 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-xl border border-emerald-200 cursor-pointer transition-colors"
          >
            <RefreshCw className="w-3.5 h-3.5 text-emerald-600" />
            <span>{isSi ? 'කඩේ කවුන්ටරයෙන් විකිණීම පරීක්ෂා කරන්න (POS)' : 'Test Physical Shop Counter POS'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Search Results or Folder Catalog Explorer */}
        {searchTerm.trim() !== '' ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-slate-700">
                {isSi ? `"${searchTerm}" සඳහා සෙවුම් ප්‍රතිඵල (${filteredProducts.length})` : `Search results for "${searchTerm}" (${filteredProducts.length})`}
              </span>
              <button
                onClick={() => setSearchTerm('')}
                className="text-xs text-emerald-700 hover:underline font-bold cursor-pointer"
              >
                {isSi ? '✕ සෙවීම ඉවත් කර ෆෝල්ඩර වෙත යන්න' : '✕ Clear Search & Show Folders'}
              </button>
            </div>

            {filteredProducts.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 space-y-3">
                <Package className="w-12 h-12 mx-auto text-slate-300" />
                <h3 className="text-base font-bold text-slate-700">
                  {isSi ? 'සොයන භාණ්ඩ හමු නොවීය' : 'No products found'}
                </h3>
                <button
                  onClick={() => setSearchTerm('')}
                  className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold cursor-pointer"
                >
                  {isSi ? 'ෆෝල්ඩර වෙත යන්න' : 'Back to Categories'}
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
                {filteredProducts.map((product) => {
                  const cartItem = cart.find((i) => i.product.id === product.id);
                  const isFav = favourites.includes(product.id);

                  return (
                    <ProductCard
                      key={product.id}
                      product={product}
                      lang={lang}
                      cartQuantity={cartItem?.quantity || 0}
                      isFavourite={isFav}
                      onAddToCart={handleAddToCart}
                      onUpdateCartQty={handleUpdateCartQty}
                      onToggleFav={handleToggleFav}
                      onViewDetails={setActiveProductDetail}
                    />
                  );
                })}
              </div>
            )}
          </div>
        ) : (
          <FolderCatalogExplorer
            lang={lang}
            categories={categories}
            products={products}
            cart={cart}
            favourites={favourites}
            onAddToCart={handleAddToCart}
            onUpdateCartQty={handleUpdateCartQty}
            onToggleFav={handleToggleFav}
            onViewDetails={setActiveProductDetail}
            initialCategoryId={selectedCategory !== 'all' ? selectedCategory : undefined}
          />
        )}
      </main>

      {/* Floating Mobile Cart Bar */}
      {cartCount > 0 && !isCartOpen && !isCheckoutOpen && (
        <div className="fixed bottom-4 inset-x-4 z-40 sm:hidden">
          <div
            onClick={() => setIsCartOpen(true)}
            className="bg-emerald-600 text-white p-3.5 rounded-2xl shadow-xl shadow-emerald-700/40 flex items-center justify-between cursor-pointer active:scale-[0.99] transition-transform"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center font-bold text-xs">
                {cartCount}
              </div>
              <div>
                <span className="text-xs font-bold block">{t.cart}</span>
                <span className="text-[11px] text-emerald-100">{cartCount} {isSi ? 'බඩු' : 'items'}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-sm font-black">Rs. {cartTotal.toLocaleString()}</span>
              <ChevronRight className="w-4 h-4" />
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 mt-16 pt-12 pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Col 1: Store Bio */}
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 font-black text-2xl tracking-tight">
                <span className="text-white">SMAPA</span>
                <span className="text-emerald-400">27</span>
                <span className="text-xs font-bold text-emerald-200/80 uppercase tracking-wider ml-1 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800/80">
                  Mega Store
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {isSi
                  ? 'ශ්‍රී ලංකාවේ විශ්වාසවන්ත සිල්ලර බඩු අලෙවිසැල. කඩේ කවුන්ටරය හා වෙබ් අඩවිය එකට සම්බන්ධ කළ නවීන සජීවී තොග පද්ධතිය.'
                  : 'Sri Lanka’s modern grocery retailer with unified real-time inventory between the physical walk-in store and online web ordering.'}
              </p>
              <div className="pt-1 flex items-center gap-2 text-xs text-emerald-400">
                <ShieldCheck className="w-4 h-4" />
                <span>100% Quality & Freshness Guarantee</span>
              </div>
            </div>

            {/* Col 2: Quick Services */}
            <div className="space-y-2 text-xs">
              <h4 className="text-white font-bold uppercase tracking-wider text-[11px]">
                {isSi ? 'ක්ෂණික සේවා' : 'Quick Services'}
              </h4>
              <ul className="space-y-1.5 text-slate-400">
                <li>
                  <button onClick={() => handleOpenTracker()} className="hover:text-emerald-400 cursor-pointer">
                    {t.trackOrder}
                  </button>
                </li>
                <li>
                  <button onClick={() => setIsFavsOpen(true)} className="hover:text-emerald-400 cursor-pointer">
                    {t.favourites}
                  </button>
                </li>
                <li>
                  <button onClick={() => setIsContactOpen(true)} className="hover:text-emerald-400 cursor-pointer">
                    {t.whatsappChat}
                  </button>
                </li>
                <li>
                  <button onClick={() => setIsAdminMode(true)} className="hover:text-emerald-400 cursor-pointer text-amber-400">
                    {t.adminPortal}
                  </button>
                </li>
              </ul>
            </div>

            {/* Col 3: Contact & Delivery Areas */}
            <div className="space-y-2 text-xs">
              <h4 className="text-white font-bold uppercase tracking-wider text-[11px]">
                {isSi ? 'බෙදාහැරීම් සහ ලිපිනය' : 'Store & Delivery'}
              </h4>
              <p className="text-slate-400">
                No. 128, High Level Road, Maharagama
              </p>
              <p className="text-slate-400">
                Hotline: 077 477 8190
              </p>
              <p className="text-slate-400">
                Email: orders@smapa27.lk
              </p>
              <p className="text-[11px] text-emerald-400 font-medium">
                {isSi ? 'දිනපතා උදෑසන 7:30 - රාත්‍රී 9:30' : 'Open Daily: 7:30 AM - 9:30 PM'}
              </p>
            </div>

            {/* Col 4: Payment & Security */}
            <div className="space-y-3 text-xs">
              <h4 className="text-white font-bold uppercase tracking-wider text-[11px]">
                {isSi ? 'ගෙවීම් ක්‍රම' : 'Payment Accepted'}
              </h4>
              <div className="flex flex-wrap gap-2 text-[11px]">
                <span className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
                  Cash on Delivery (COD)
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
                  Visa / Mastercard
                </span>
                <span className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
                  Bank Transfer (BOC / ComBank)
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                {isSi ? 'V1 MVP වෙබ් අඩවිය සාර්ථකව ක්‍රියාත්මක වේ.' : 'V1 MVP Online Storefront running smoothly.'}
              </p>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-800 flex flex-wrap justify-between items-center gap-4 text-xs text-slate-500">
            <p>© {new Date().getFullYear()} SMAPA 27 Mega Store. All rights reserved. Built with unified physical ↔ online inventory.</p>
            <div className="flex items-center gap-4">
              <button onClick={() => setLang(lang === 'en' ? 'si' : 'en')} className="hover:text-emerald-400 cursor-pointer">
                {lang === 'en' ? '🇱🇰 සිංහල භාෂාවට මාරු වන්න' : '🇬🇧 Switch to English'}
              </button>
            </div>
          </div>
        </div>
      </footer>

      {/* All Functional Modals */}
      {activeProductDetail && (
        <ProductDetailsModal
          product={activeProductDetail}
          lang={lang}
          onClose={() => setActiveProductDetail(null)}
          onAddToCart={handleAddToCart}
          isFavourite={favourites.includes(activeProductDetail.id)}
          onToggleFav={handleToggleFav}
        />
      )}

      {isCartOpen && (
        <CartDrawer
          isOpen={isCartOpen}
          onClose={() => setIsCartOpen(false)}
          items={cart}
          lang={lang}
          onUpdateQty={handleUpdateCartQty}
          onRemoveItem={handleRemoveFromCart}
          onClearCart={handleClearCart}
          onProceedToCheckout={handleProceedToCheckout}
          onQuickWhatsAppOrder={handleQuickWhatsAppOrder}
        />
      )}

      {isCheckoutOpen && (
        <CheckoutModal
          isOpen={isCheckoutOpen}
          onClose={() => setIsCheckoutOpen(false)}
          items={cart}
          lang={lang}
          onOrderSuccess={handleOrderSuccess}
        />
      )}

      {recentOrderSuccess && (
        <OrderSuccessModal
          order={recentOrderSuccess}
          lang={lang}
          onClose={() => setRecentOrderSuccess(null)}
          onTrackOrder={(orderNum) => handleOpenTracker(orderNum)}
        />
      )}

      {isTrackerOpen && (
        <OrderTrackerModal
          isOpen={isTrackerOpen}
          onClose={() => setIsTrackerOpen(false)}
          lang={lang}
          initialOrderNumber={trackOrderNumber}
          onReorderSuccess={() => {
            showToast(isSi ? 'භාණ්ඩ නැවත කරත්තයට එකතු විය!' : 'Items reordered into cart!', 'success');
            setIsCartOpen(true);
          }}
          onPayNow={(order) => {
            setPaymentGatewayOrder(order);
            setIsPaymentGatewayOpen(true);
          }}
        />
      )}

      {isFavsOpen && (
        <FavouritesModal
          isOpen={isFavsOpen}
          onClose={() => setIsFavsOpen(false)}
          lang={lang}
          onAddToCart={handleAddToCart}
          onViewDetails={setActiveProductDetail}
        />
      )}

      {isContactOpen && (
        <WhatsAppContactModal
          isOpen={isContactOpen}
          onClose={() => setIsContactOpen(false)}
          lang={lang}
        />
      )}

      {isPaymentGatewayOpen && paymentGatewayOrder && (
        <PaymentGatewayModal
          isOpen={isPaymentGatewayOpen}
          onClose={() => setIsPaymentGatewayOpen(false)}
          order={paymentGatewayOrder}
          lang={lang}
          onPaymentSuccess={(paidOrder, txnId) => {
            showToast(isSi ? `ගෙවීම තහවුරු විය (Ref: ${txnId})! 🎉` : `Payment Confirmed (Ref: ${txnId})! 🎉`, 'success');
            setRecentOrderSuccess(paidOrder);
          }}
        />
      )}

      {isShareModalOpen && (
        <ShareStoreModal
          isOpen={isShareModalOpen}
          onClose={() => setIsShareModalOpen(false)}
          lang={lang}
        />
      )}

      {isAuthOpen && (
        <CustomerAuthModal
          isOpen={isAuthOpen}
          onClose={() => setIsAuthOpen(false)}
          lang={lang}
          onLoginSuccess={(cust) => {
            setActiveCustomer(cust);
            showToast(
              lang === 'si'
                ? `ආයුබෝවන් ${cust.name}! ගිණුමට සාර්ථකව පිවිසුණා.`
                : `Welcome ${cust.name}! Logged in successfully.`,
              'success'
            );
          }}
        />
      )}
    </div>
  );
}
