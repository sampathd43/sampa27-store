export type Language = 'en' | 'si';

export type ChannelSource = 'shop_pos' | 'online_web' | 'mobile_app' | 'whatsapp';

export interface SupplierInfo {
  name: string;
  phone: string;
  leadTimeDays: number;
}

export interface Product {
  id: string;
  sku: string;
  barcode: string;
  name: string;
  nameSi: string;
  brand: string;
  category: string;
  categorySi: string;
  subcategory?: string;
  
  // Pricing Structure
  price: number; // Retail selling price
  originalPrice?: number; // Regular / MRP strikethrough price (e.g. 1750 when selling at 1550)
  isHotDeal?: boolean; // Highlighted under Special Discounts
  wholesalePrice: number; // Bulk / wholesale price
  wholesaleMinQty: number; // Minimum quantity to trigger wholesale rate (e.g. 3 or 5)
  costPrice: number; // Buying / procurement price
  profitMarginPercent?: number; // ((price - costPrice) / price) * 100
  
  // Stock / Inventory Structure
  stock: number; // Total available stock
  shelfStock: number; // On display at physical shop counter
  backstoreStock: number; // In stockroom / warehouse
  reservedOnlineStock: number; // Allocated to currently pending online orders
  minStockAlert: number; // Low stock threshold / Reorder level
  reorderQuantity: number; // Standard batch size to order from supplier
  supplier: SupplierInfo;
  
  unit: string; // e.g. "5 kg bag", "1 kg", "400 g", "750 ml"
  unitSi: string;
  image: string;
  isActive: boolean;
  soldCount: number;
  description: string;
  descriptionSi: string;
}

export interface CartItem {
  product: Product;
  quantity: number;
  unitPrice: number;
  isWholesaleApplied: boolean;
}

export type DeliveryOption = 'standard' | 'express' | 'pickup';

export type DeliveryZone = 'colombo_suburbs' | 'colombo_central' | 'outstation' | 'in_store';

export interface DeliveryZoneConfig {
  id: DeliveryZone;
  name: string;
  nameSi: string;
  coverageAreas: string[];
  standardFee: number;
  expressFee: number;
  estimatedHours: string;
  freeDeliveryThreshold?: number;
  active: boolean;
}

export interface DeliveryRider {
  id: string;
  name: string;
  phone: string;
  vehicleNumber: string;
  agency: 'In-House LankaMart Express' | 'PickMe Flash Partner' | 'Koombiyo Delivery';
}

export type PaymentMethod = 'cod' | 'card' | 'bank_transfer';

export type OrderStatus = 'new' | 'confirmed' | 'packing' | 'out_for_delivery' | 'delivered' | 'cancelled';

export interface OrderStatusHistory {
  status: OrderStatus;
  timestamp: string;
  note?: string;
}

export interface OrderCustomer {
  name: string;
  phone: string;
  whatsapp?: string;
  address: string;
  city: string;
  landmarkNotes?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  customer: OrderCustomer;
  items: CartItem[];
  deliveryOption: DeliveryOption;
  deliveryZone: DeliveryZone;
  deliveryFee: number;
  deliveryTimeSlot?: string;
  subtotal: number;
  discount: number;
  total: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'pending' | 'paid' | 'refunded';
  status: OrderStatus;
  statusHistory: OrderStatusHistory[];
  channel: ChannelSource;
  assignedRider?: DeliveryRider;
  notes?: string;
  cashTendered?: number;
  changeGiven?: number;
}

export interface NotificationLog {
  id: string;
  timestamp: string;
  type: 'sms' | 'whatsapp';
  recipient: string;
  orderNumber: string;
  title: string;
  message: string;
  status: 'delivered' | 'pending';
}

export interface CustomerProfile {
  id: string;
  name: string;
  phone: string;
  alternatePhone?: string;
  username?: string;
  password?: string;
  email?: string;
  address: string;
  city: string;
  landmarkNotes?: string;
  totalSpent: number;
  ordersCount: number;
  loyaltyPoints: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'VIP';
  frequentItems: string[];
  notes?: string;
  lastOrderDate: string;
}

export interface StockLog {
  id: string;
  timestamp: string;
  productId: string;
  productName: string;
  productNameSi: string;
  type: 'web_order' | 'shop_pos_sale' | 'mobile_app_order' | 'restock' | 'order_cancel_restock' | 'manual_edit';
  quantityChange: number;
  resultingStock: number;
  referenceId?: string;
  channel: 'Shop Counter POS' | 'Online Website' | 'Mobile App' | 'Admin Inventory';
}

export interface Category {
  id: string;
  name: string;
  nameSi: string;
  icon: string;
  image?: string;
  badge?: string;
  subcategoriesSummary?: string;
  subcategoriesSummarySi?: string;
  subcategories?: { id: string; name: string; nameSi: string }[];
  popularBrands?: string[];
  colorTheme?: string;
}

export interface ReorderItem {
  product: Product;
  currentStock: number;
  reorderLevel: number;
  recommendedOrderQty: number;
  supplier: SupplierInfo;
  estimatedCost: number;
}
