import {
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  INITIAL_DELIVERY_ZONES,
  INITIAL_RIDERS,
  INITIAL_CUSTOMERS
} from '../data/initialData';
import {
  CartItem,
  Category,
  ChannelSource,
  CustomerProfile,
  DeliveryOption,
  DeliveryRider,
  DeliveryZone,
  DeliveryZoneConfig,
  NotificationLog,
  Order,
  OrderStatus,
  Product,
  ReorderItem,
  StockLog
} from '../types';

const STORAGE_KEYS = {
  PRODUCTS: 'lankamart_products_v2',
  ORDERS: 'lankamart_orders_v2',
  STOCK_LOGS: 'lankamart_stock_logs_v2',
  CART: 'lankamart_cart_v2',
  FAVOURITES: 'lankamart_favourites_v2',
  CATEGORIES: 'lankamart_categories_v2',
  CUSTOMERS: 'lankamart_customers_v2',
  RIDERS: 'lankamart_riders_v2',
  DELIVERY_ZONES: 'lankamart_delivery_zones_v2',
  NOTIFICATIONS: 'lankamart_notifications_v2',
  ACTIVE_CUSTOMER: 'lankamart_active_customer_v2'
};

const INITIAL_SAMPLE_ORDERS: Order[] = [
  {
    id: 'ord-sample-101',
    orderNumber: 'LK-8421',
    createdAt: new Date(Date.now() - 3600000 * 5).toISOString(),
    customer: {
      name: 'Kasun Bandara',
      phone: '0771234567',
      whatsapp: '0771234567',
      address: 'No 45/A, Temple Road, Maharagama',
      city: 'Maharagama',
      landmarkNotes: 'Near Maharagama clock tower'
    },
    items: [
      {
        product: INITIAL_PRODUCTS[0],
        quantity: 1,
        unitPrice: INITIAL_PRODUCTS[0].price,
        isWholesaleApplied: false
      },
      {
        product: INITIAL_PRODUCTS[2],
        quantity: 5,
        unitPrice: INITIAL_PRODUCTS[2].wholesalePrice,
        isWholesaleApplied: true // Wholesale tier applied!
      },
      {
        product: INITIAL_PRODUCTS[4],
        quantity: 1,
        unitPrice: INITIAL_PRODUCTS[4].price,
        isWholesaleApplied: false
      }
    ],
    deliveryOption: 'standard',
    deliveryZone: 'colombo_suburbs',
    deliveryFee: 350,
    subtotal: 3350,
    discount: 150,
    total: 3550,
    paymentMethod: 'cod',
    paymentStatus: 'pending',
    status: 'packing',
    statusHistory: [
      { status: 'new', timestamp: new Date(Date.now() - 3600000 * 5).toISOString(), note: 'Web order received into unified engine' },
      { status: 'confirmed', timestamp: new Date(Date.now() - 3600000 * 3).toISOString(), note: 'Confirmed with customer via phone' },
      { status: 'packing', timestamp: new Date(Date.now() - 3600000 * 1).toISOString(), note: 'Items packed in crate #4' }
    ],
    channel: 'online_web',
    assignedRider: INITIAL_RIDERS[0]
  },
  {
    id: 'ord-sample-pos-102',
    orderNumber: 'POS-2914',
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    customer: {
      name: 'Walk-in Cash Customer',
      phone: 'Counter Sale',
      address: 'In-Store Physical Counter',
      city: 'Maharagama',
      landmarkNotes: 'Direct cash transaction'
    },
    items: [
      {
        product: INITIAL_PRODUCTS[0],
        quantity: 1,
        unitPrice: INITIAL_PRODUCTS[0].price,
        isWholesaleApplied: false
      }
    ],
    deliveryOption: 'pickup',
    deliveryZone: 'in_store',
    deliveryFee: 0,
    subtotal: 1550,
    discount: 0,
    total: 1550,
    paymentMethod: 'cod',
    paymentStatus: 'paid',
    status: 'delivered',
    statusHistory: [
      { status: 'delivered', timestamp: new Date(Date.now() - 3600000 * 2).toISOString(), note: 'Instant counter cash checkout completed' }
    ],
    channel: 'shop_pos'
  }
];

const INITIAL_STOCK_LOGS: StockLog[] = [
  {
    id: 'log-seed-1',
    timestamp: new Date(Date.now() - 3600000 * 6).toISOString(),
    productId: 'prod-rice-keeri-5kg',
    productName: 'Araliya Keeri Samba Rice (5kg)',
    productNameSi: 'අරලිය කීරි සම්බා සහල් (5kg)',
    type: 'web_order',
    quantityChange: -1,
    resultingStock: 20,
    referenceId: 'LK-8421',
    channel: 'Online Website'
  },
  {
    id: 'log-seed-2',
    timestamp: new Date(Date.now() - 3600000 * 2).toISOString(),
    productId: 'prod-rice-keeri-5kg',
    productName: 'Araliya Keeri Samba Rice (5kg)',
    productNameSi: 'අරලිය කීරි සම්බා සහල් (5kg)',
    type: 'shop_pos_sale',
    quantityChange: -1,
    resultingStock: 19,
    referenceId: 'POS-2914',
    channel: 'Shop Counter POS'
  }
];

export class UnifiedStore {
  private static listeners: Set<() => void> = new Set();

  public static subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private static notify() {
    this.listeners.forEach((fn) => {
      try {
        fn();
      } catch (err) {
        console.error('UnifiedStore listener error:', err);
      }
    });
    try {
      window.dispatchEvent(new CustomEvent('lankamart_state_updated'));
    } catch {
      // browser safe
    }
  }

  // --- PRODUCTS ---
  public static getProducts(): Product[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
        return INITIAL_PRODUCTS;
      }
      const parsed: Product[] = JSON.parse(data);
      if (parsed.length < 12 || !parsed.some((p) => p.category === 'rice')) {
        localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
        return INITIAL_PRODUCTS;
      }
      let hasUpdate = false;
      const merged = parsed.map((p) => {
        const initial = INITIAL_PRODUCTS.find((ip) => ip.id === p.id);
        if (initial && (!p.originalPrice || p.isHotDeal === undefined)) {
          hasUpdate = true;
          return {
            ...p,
            originalPrice: initial.originalPrice,
            isHotDeal: initial.isHotDeal
          };
        }
        return p;
      });

      if (hasUpdate) {
        localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(merged));
      }
      return merged;
    } catch {
      return INITIAL_PRODUCTS;
    }
  }

  public static getCategories(): Category[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(INITIAL_CATEGORIES));
        return INITIAL_CATEGORIES;
      }
      const parsed: Category[] = JSON.parse(data);
      if (parsed.length < 15 || !parsed.some((c) => c.id === 'rice') || !parsed.some((c) => c.image)) {
        localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(INITIAL_CATEGORIES));
        return INITIAL_CATEGORIES;
      }
      return parsed;
    } catch {
      return INITIAL_CATEGORIES;
    }
  }

  public static saveCategory(category: Category): void {
    const categories = this.getCategories();
    const index = categories.findIndex((c) => c.id === category.id);
    if (index >= 0) {
      categories[index] = category;
    } else {
      categories.push(category);
    }
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
    this.notify();
  }

  public static getDeliveryZones(): DeliveryZoneConfig[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.DELIVERY_ZONES);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.DELIVERY_ZONES, JSON.stringify(INITIAL_DELIVERY_ZONES));
        return INITIAL_DELIVERY_ZONES;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_DELIVERY_ZONES;
    }
  }

  public static saveDeliveryZone(zone: DeliveryZoneConfig): void {
    const zones = this.getDeliveryZones();
    const index = zones.findIndex((z) => z.id === zone.id);
    if (index >= 0) {
      zones[index] = zone;
    } else {
      zones.push(zone);
    }
    localStorage.setItem(STORAGE_KEYS.DELIVERY_ZONES, JSON.stringify(zones));
    this.notify();
  }

  // --- NOTIFICATIONS (SMS & WHATSAPP) ---
  public static getNotifications(): NotificationLog[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  public static sendSmsNotification(
    recipient: string,
    orderNumber: string,
    title: string,
    message: string
  ): NotificationLog {
    const logs = this.getNotifications();
    const notif: NotificationLog = {
      id: `notif-sms-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString(),
      type: 'sms',
      recipient,
      orderNumber,
      title,
      message,
      status: 'delivered'
    };
    logs.unshift(notif);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(logs.slice(0, 100)));
    this.notify();
    return notif;
  }

  public static sendWhatsAppNotification(
    recipient: string,
    orderNumber: string,
    title: string,
    message: string
  ): NotificationLog {
    const logs = this.getNotifications();
    const notif: NotificationLog = {
      id: `notif-wa-${Date.now()}-${Math.floor(100 + Math.random() * 900)}`,
      timestamp: new Date().toISOString(),
      type: 'whatsapp',
      recipient,
      orderNumber,
      title,
      message,
      status: 'delivered'
    };
    logs.unshift(notif);
    localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(logs.slice(0, 100)));
    this.notify();
    return notif;
  }

  public static getRiders(): DeliveryRider[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.RIDERS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.RIDERS, JSON.stringify(INITIAL_RIDERS));
        return INITIAL_RIDERS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_RIDERS;
    }
  }

  public static getProductById(id: string): Product | undefined {
    return this.getProducts().find((p) => p.id === id);
  }

  public static saveProduct(product: Product): void {
    const products = this.getProducts();
    const index = products.findIndex((p) => p.id === product.id);
    let oldProduct: Product | undefined;

    // Auto-calculate profit margin
    if (product.costPrice && product.costPrice > 0) {
      product.profitMarginPercent = Number((((product.price - product.costPrice) / product.price) * 100).toFixed(1));
    }

    if (index >= 0) {
      oldProduct = products[index];
      products[index] = product;
    } else {
      products.unshift(product);
    }

    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));

    if (oldProduct && oldProduct.stock !== product.stock) {
      const diff = product.stock - oldProduct.stock;
      this.addStockLog({
        productId: product.id,
        productName: product.name,
        productNameSi: product.nameSi,
        type: 'manual_edit',
        quantityChange: diff,
        resultingStock: product.stock,
        referenceId: 'Admin Stock Calibration',
        channel: 'Admin Inventory'
      });
    }

    this.notify();
  }

  public static deleteProduct(id: string): void {
    const products = this.getProducts().filter((p) => p.id !== id);
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    this.notify();
  }

  // --- UNIFIED STOCK ENGINE (SHOP ↔ WEB ↔ APP) ---
  public static updateStock(
    productId: string,
    delta: number, // negative for sale, positive for restock
    type: StockLog['type'],
    channel: StockLog['channel'],
    referenceId?: string
  ): boolean {
    const products = this.getProducts();
    const prod = products.find((p) => p.id === productId);
    if (!prod) return false;

    if (delta < 0 && prod.stock + delta < 0) {
      return false; // Out of stock
    }

    prod.stock = Math.max(0, prod.stock + delta);

    // Update shelf and backstore proportions
    if (delta < 0) {
      const deduction = Math.abs(delta);
      if (prod.shelfStock >= deduction) {
        prod.shelfStock -= deduction;
      } else {
        const remainder = deduction - prod.shelfStock;
        prod.shelfStock = 0;
        prod.backstoreStock = Math.max(0, prod.backstoreStock - remainder);
      }
      prod.soldCount = (prod.soldCount || 0) + deduction;
    } else {
      prod.backstoreStock = (prod.backstoreStock || 0) + delta;
      if (type === 'order_cancel_restock') {
        prod.soldCount = Math.max(0, (prod.soldCount || 0) - delta);
      }
    }

    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));

    this.addStockLog({
      productId: prod.id,
      productName: prod.name,
      productNameSi: prod.nameSi,
      type,
      quantityChange: delta,
      resultingStock: prod.stock,
      referenceId,
      channel
    });

    this.notify();
    return true;
  }

  // Restock action from Supplier Reorder Sheet
  public static restockProduct(productId: string, quantity: number, invoiceRef?: string): boolean {
    return this.updateStock(
      productId,
      quantity,
      'restock',
      'Admin Inventory',
      invoiceRef || `Supplier Restock Batch (+${quantity})`
    );
  }

  // --- POS / PHYSICAL COUNTER SALE ---
  public static performShopCounterSale(
    items: { productId: string; quantity: number }[],
    customerName: string = 'Walk-in Cash Customer',
    cashTendered?: number,
    customerPhone?: string
  ): { success: boolean; error?: string; orderNumber?: string; order?: Order; changeGiven?: number } {
    const products = this.getProducts();

    for (const item of items) {
      const prod = products.find((p) => p.id === item.productId);
      if (!prod) return { success: false, error: `Product not found: ${item.productId}` };
      if (prod.stock < item.quantity) {
        return {
          success: false,
          error: `Insufficient stock for ${prod.name}. Available: ${prod.stock}, Requested: ${item.quantity}`
        };
      }
    }

    const orderNumber = `POS-${Math.floor(1000 + Math.random() * 9000)}`;
    const cartItems: CartItem[] = [];
    let subtotal = 0;

    for (const item of items) {
      const prod = products.find((p) => p.id === item.productId)!;
      const isWholesale = item.quantity >= prod.wholesaleMinQty;
      const unitPrice = isWholesale ? prod.wholesalePrice : prod.price;

      this.updateStock(
        item.productId,
        -item.quantity,
        'shop_pos_sale',
        'Shop Counter POS',
        `${orderNumber} (${customerName})`
      );

      cartItems.push({
        product: { ...prod, stock: prod.stock - item.quantity },
        quantity: item.quantity,
        unitPrice,
        isWholesaleApplied: isWholesale
      });
      subtotal += unitPrice * item.quantity;
    }

    let totalSavings = 0;
    for (const item of cartItems) {
      const orig = (item.product.originalPrice && item.product.originalPrice > item.unitPrice)
        ? item.product.originalPrice
        : (item.product.price > item.unitPrice ? item.product.price : item.unitPrice);
      if (orig > item.unitPrice) {
        totalSavings += (orig - item.unitPrice) * item.quantity;
      }
    }

    const changeGiven = cashTendered && cashTendered >= subtotal ? cashTendered - subtotal : 0;

    const posOrder: Order = {
      id: `ord-pos-${Date.now()}`,
      orderNumber,
      createdAt: new Date().toISOString(),
      customer: {
        name: customerName,
        phone: customerPhone || 'Counter Cash Sale',
        address: 'Physical Superstore Counter',
        city: 'Maharagama',
        landmarkNotes: 'Direct cash transaction'
      },
      items: cartItems,
      deliveryOption: 'pickup',
      deliveryZone: 'in_store',
      deliveryFee: 0,
      subtotal,
      discount: totalSavings,
      total: subtotal,
      paymentMethod: 'cod',
      paymentStatus: 'paid',
      status: 'delivered',
      cashTendered: cashTendered || subtotal,
      changeGiven,
      statusHistory: [
        {
          status: 'delivered',
          timestamp: new Date().toISOString(),
          note: `Instant counter cash checkout. Tendered: Rs. ${cashTendered || subtotal}, Change: Rs. ${changeGiven}`
        }
      ],
      channel: 'shop_pos'
    };

    this.saveOrder(posOrder);
    this.recordCustomerOrder(posOrder);
    return { success: true, orderNumber, order: posOrder, changeGiven };
  }

  // --- SIMULTANEOUS OMNICHANNEL TESTER (SHOP ↔ WEB ↔ APP) ---
  // Demonstrates user's explicit requirement:
  // "Shop එකේ customer කෙනෙක් Rice 5kg එකක් ගත්තා → stock 20 → 19
  //  Website order එකක් ආවා → stock 19 → 18
  //  App එකෙන් order එකක් ආවා → stock 18 → 17"
  public static simulateOmnichannelTripleSync(productId: string = 'prod-rice-keeri-5kg'): {
    initialStock: number;
    afterShop: number;
    afterWeb: number;
    afterApp: number;
    success: boolean;
  } {
    const prod = this.getProductById(productId);
    if (!prod || prod.stock < 3) {
      return { initialStock: prod?.stock || 0, afterShop: 0, afterWeb: 0, afterApp: 0, success: false };
    }

    const initialStock = prod.stock;

    // 1. Shop Counter Walk-in sale: 20 -> 19
    this.updateStock(productId, -1, 'shop_pos_sale', 'Shop Counter POS', 'Walk-in Counter Simulation');
    const p1 = this.getProductById(productId)!;
    const afterShop = p1.stock;

    // 2. Online Website order: 19 -> 18
    this.updateStock(productId, -1, 'web_order', 'Online Website', 'Web Checkout #LK-SIM-1');
    const p2 = this.getProductById(productId)!;
    const afterWeb = p2.stock;

    // 3. Mobile App order: 18 -> 17
    this.updateStock(productId, -1, 'mobile_app_order', 'Mobile App', 'Mobile App Push #APP-SIM-2');
    const p3 = this.getProductById(productId)!;
    const afterApp = p3.stock;

    return {
      initialStock,
      afterShop,
      afterWeb,
      afterApp,
      success: true
    };
  }

  // --- ORDERS ---
  public static getOrders(): Order[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ORDERS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(INITIAL_SAMPLE_ORDERS));
        return INITIAL_SAMPLE_ORDERS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_SAMPLE_ORDERS;
    }
  }

  public static saveOrder(order: Order): void {
    const orders = this.getOrders();
    const index = orders.findIndex((o) => o.id === order.id);
    if (index >= 0) {
      orders[index] = order;
    } else {
      orders.unshift(order);
    }
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    this.notify();
  }

  public static placeOnlineOrder(
    customer: Order['customer'],
    items: CartItem[],
    deliveryOption: Order['deliveryOption'],
    deliveryZone: DeliveryZone,
    deliveryFee: number,
    paymentMethod: Order['paymentMethod'],
    deliveryTimeSlot?: string
  ): { success: boolean; order?: Order; error?: string } {
    const products = this.getProducts();

    // Check availability
    for (const item of items) {
      const liveProduct = products.find((p) => p.id === item.product.id);
      if (!liveProduct) {
        return { success: false, error: `Product not found: ${item.product.name}` };
      }
      if (liveProduct.stock < item.quantity) {
        return {
          success: false,
          error: `Insufficient stock for "${liveProduct.name}". Only ${liveProduct.stock} left in stock.`
        };
      }
    }

    // Pricing calculation with wholesale tier logic
    let subtotal = 0;
    const processedItems: CartItem[] = items.map((item) => {
      const liveProd = products.find((p) => p.id === item.product.id)!;
      const isWholesale = item.quantity >= liveProd.wholesaleMinQty;
      const unitPrice = isWholesale ? liveProd.wholesalePrice : liveProd.price;
      subtotal += unitPrice * item.quantity;
      return {
        product: liveProd,
        quantity: item.quantity,
        unitPrice,
        isWholesaleApplied: isWholesale
      };
    });

    const total = subtotal + deliveryFee;
    const orderNumber = `LK-${Math.floor(1000 + Math.random() * 9000)}`;

    let totalSavings = 0;
    for (const item of processedItems) {
      const orig = (item.product.originalPrice && item.product.originalPrice > item.unitPrice)
        ? item.product.originalPrice
        : (item.product.price > item.unitPrice ? item.product.price : item.unitPrice);
      if (orig > item.unitPrice) {
        totalSavings += (orig - item.unitPrice) * item.quantity;
      }
    }

    // Assign default rider based on zone
    const riders = this.getRiders();
    const assignedRider = deliveryOption === 'pickup' ? undefined : riders[Math.floor(Math.random() * riders.length)];

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      createdAt: new Date().toISOString(),
      customer,
      items: processedItems,
      deliveryOption,
      deliveryZone,
      deliveryFee,
      deliveryTimeSlot: deliveryTimeSlot || 'Standard Same-Day Slot',
      subtotal,
      discount: totalSavings,
      total,
      paymentMethod,
      paymentStatus: paymentMethod === 'card' ? 'paid' : 'pending',
      status: 'new',
      statusHistory: [
        {
          status: 'new',
          timestamp: new Date().toISOString(),
          note: 'Online order placed via Web Store'
        }
      ],
      channel: 'online_web',
      assignedRider
    };

    // Deduct stock unified across entire system
    for (const item of processedItems) {
      this.updateStock(
        item.product.id,
        -item.quantity,
        'web_order',
        'Online Website',
        `Web Order #${orderNumber}`
      );
    }

    this.saveOrder(newOrder);
    this.recordCustomerOrder(newOrder);

    // Automated notifications (SMS to customer, WhatsApp alert to shop hotline 0774778190)
    this.sendSmsNotification(
      customer.phone,
      orderNumber,
      'Order Confirmed',
      `[SMAPA 27] Order #${orderNumber} received! Total: Rs. ${total.toLocaleString()}. Slot: ${deliveryTimeSlot || 'Standard Delivery'}. Thank you for ordering with SMAPA 27 Mega Store.`
    );
    this.sendWhatsAppNotification(
      '0774778190',
      orderNumber,
      'New Order Received',
      `*New SMAPA 27 Mega Store Order #${orderNumber}*\nCustomer: ${customer.name}\nPhone: ${customer.phone}\nAddress: ${customer.address}, ${customer.city}\nTotal: Rs. ${total.toLocaleString()}\nMethod: ${paymentMethod.toUpperCase()}`
    );

    this.clearCart();
    return { success: true, order: newOrder };
  }

  public static updateOrderStatus(
    orderId: string,
    status: OrderStatus,
    note?: string,
    assignedRider?: DeliveryRider
  ): void {
    const orders = this.getOrders();
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    const previousStatus = order.status;
    order.status = status;
    if (assignedRider) {
      order.assignedRider = assignedRider;
    }

    order.statusHistory.push({
      status,
      timestamp: new Date().toISOString(),
      note: note || `Status updated to ${status}`
    });

    if (status === 'delivered') {
      order.paymentStatus = 'paid';
    }

    // Cancellation: Auto-restore inventory stock
    if (status === 'cancelled' && previousStatus !== 'cancelled') {
      for (const item of order.items) {
        this.updateStock(
          item.product.id,
          item.quantity,
          'order_cancel_restock',
          'Admin Inventory',
          `Restored from Cancelled Order #${order.orderNumber}`
        );
      }
    }

    // Automated Dispatch Notifications
    if (status === 'out_for_delivery') {
      const rider = assignedRider || order.assignedRider;
      this.sendSmsNotification(
        order.customer.phone,
        order.orderNumber,
        'Out for Delivery',
        `[SMAPA 27] Great news! Order #${order.orderNumber} is Out for Delivery with rider ${rider ? rider.name + ' (' + rider.phone + ', ' + rider.vehicleNumber + ')' : 'Express Rider'}.`
      );
    } else if (status === 'delivered') {
      this.sendSmsNotification(
        order.customer.phone,
        order.orderNumber,
        'Delivered',
        `[SMAPA 27] Order #${order.orderNumber} has been delivered successfully! Thank you for choosing SMAPA 27 Mega Store!`
      );
    }

    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    this.notify();
  }

  // --- CUSTOMER DATABASE & CRM ---
  public static getCustomers(): CustomerProfile[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CUSTOMERS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(INITIAL_CUSTOMERS));
        return INITIAL_CUSTOMERS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_CUSTOMERS;
    }
  }

  public static saveCustomer(customer: CustomerProfile): void {
    const list = this.getCustomers();
    const index = list.findIndex((c) => c.id === customer.id || c.phone === customer.phone);
    if (index >= 0) {
      list[index] = customer;
    } else {
      list.unshift(customer);
    }
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(list));
    this.notify();
  }

  private static recordCustomerOrder(order: Order): void {
    if (!order.customer.phone || order.customer.phone.includes('Counter')) return;

    const customers = this.getCustomers();
    const existing = customers.find((c) => c.phone === order.customer.phone);

    const pointsEarned = Math.floor(order.total / 100);

    if (existing) {
      existing.ordersCount += 1;
      existing.totalSpent += order.total;
      existing.loyaltyPoints += pointsEarned;
      existing.lastOrderDate = order.createdAt;
      existing.address = order.customer.address || existing.address;
      existing.city = order.customer.city || existing.city;

      // Tier progression
      if (existing.totalSpent > 30000) existing.tier = 'VIP';
      else if (existing.totalSpent > 15000) existing.tier = 'Gold';
      else if (existing.totalSpent > 5000) existing.tier = 'Silver';
      else existing.tier = 'Bronze';

      // Frequent items append
      const itemNames = order.items.map((i) => i.product.name);
      existing.frequentItems = Array.from(new Set([...existing.frequentItems, ...itemNames])).slice(0, 5);
    } else {
      const newProfile: CustomerProfile = {
        id: `cust-${Date.now()}`,
        name: order.customer.name,
        phone: order.customer.phone,
        alternatePhone: order.customer.whatsapp,
        address: order.customer.address,
        city: order.customer.city,
        landmarkNotes: order.customer.landmarkNotes,
        totalSpent: order.total,
        ordersCount: 1,
        loyaltyPoints: pointsEarned,
        tier: order.total > 15000 ? 'Gold' : order.total > 5000 ? 'Silver' : 'Bronze',
        frequentItems: order.items.map((i) => i.product.name).slice(0, 4),
        lastOrderDate: order.createdAt
      };
      customers.unshift(newProfile);
    }

    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
  }

  // --- CUSTOMER SESSION & AUTHENTICATION ---
  public static getActiveCustomer(): CustomerProfile | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ACTIVE_CUSTOMER);
      return data ? JSON.parse(data) : null;
    } catch {
      return null;
    }
  }

  public static setActiveCustomer(customer: CustomerProfile | null): void {
    if (customer) {
      localStorage.setItem(STORAGE_KEYS.ACTIVE_CUSTOMER, JSON.stringify(customer));
    } else {
      localStorage.removeItem(STORAGE_KEYS.ACTIVE_CUSTOMER);
    }
    this.notify();
  }

  public static loginWithWhatsApp(
    phone: string,
    otp: string,
    name?: string
  ): { success: boolean; customer?: CustomerProfile; error?: string } {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 9) {
      return { success: false, error: 'Please enter a valid mobile number (e.g. 0771234567)' };
    }
    if (otp !== '8342' && otp.length < 4) {
      return { success: false, error: 'Invalid OTP code. Please enter the 4-digit code (8342).' };
    }

    const customers = this.getCustomers();
    let existing = customers.find((c) => c.phone.replace(/[^0-9]/g, '') === cleanPhone);

    if (!existing) {
      existing = {
        id: `cust-${Date.now()}`,
        name: name?.trim() || `Customer (${cleanPhone.slice(-4)})`,
        phone: cleanPhone,
        address: 'No 28, Station Road',
        city: 'Maharagama',
        totalSpent: 0,
        ordersCount: 0,
        loyaltyPoints: 50,
        tier: 'Bronze',
        frequentItems: [],
        lastOrderDate: new Date().toISOString()
      };
      customers.unshift(existing);
      localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
    }

    this.setActiveCustomer(existing);
    return { success: true, customer: existing };
  }

  public static loginWithUsernamePassword(
    identifier: string,
    password: string
  ): { success: boolean; customer?: CustomerProfile; error?: string } {
    const idClean = identifier.trim().toLowerCase();
    const customers = this.getCustomers();
    const customer = customers.find(
      (c) =>
        (c.username && c.username.toLowerCase() === idClean) ||
        (c.phone && c.phone.replace(/[^0-9]/g, '') === idClean.replace(/[^0-9]/g, '')) ||
        (c.email && c.email.toLowerCase() === idClean)
    );

    if (!customer) {
      return { success: false, error: 'Account not found. Please register or log in with WhatsApp OTP.' };
    }

    if (customer.password && customer.password !== password) {
      return { success: false, error: 'Incorrect password. (Demo password is password123)' };
    }

    this.setActiveCustomer(customer);
    return { success: true, customer };
  }

  public static registerCustomer(data: {
    name: string;
    phone: string;
    username?: string;
    password?: string;
    email?: string;
    address: string;
    city: string;
  }): { success: boolean; customer?: CustomerProfile; error?: string } {
    const cleanPhone = data.phone.replace(/[^0-9]/g, '');
    if (cleanPhone.length < 9) {
      return { success: false, error: 'Please enter a valid Sri Lankan mobile number.' };
    }

    const customers = this.getCustomers();
    if (customers.some((c) => c.phone.replace(/[^0-9]/g, '') === cleanPhone)) {
      return { success: false, error: 'An account with this mobile number already exists. Please log in.' };
    }

    const newCustomer: CustomerProfile = {
      id: `cust-${Date.now()}`,
      name: data.name.trim(),
      phone: cleanPhone,
      username: data.username?.trim().toLowerCase(),
      password: data.password || 'password123',
      email: data.email?.trim().toLowerCase(),
      address: data.address.trim(),
      city: data.city.trim() || 'Maharagama',
      totalSpent: 0,
      ordersCount: 0,
      loyaltyPoints: 100, // 100 welcome bonus points!
      tier: 'Bronze',
      frequentItems: [],
      lastOrderDate: new Date().toISOString()
    };

    customers.unshift(newCustomer);
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(customers));
    this.setActiveCustomer(newCustomer);
    return { success: true, customer: newCustomer };
  }

  public static logoutCustomer(): void {
    this.setActiveCustomer(null);
  }

  // --- LOW STOCK & REORDER CONCEPT ---
  public static getReorderRecommendations(): ReorderItem[] {
    const products = this.getProducts();
    const lowStock = products.filter((p) => p.stock <= p.minStockAlert);

    return lowStock.map((prod) => ({
      product: prod,
      currentStock: prod.stock,
      reorderLevel: prod.minStockAlert,
      recommendedOrderQty: prod.reorderQuantity || 25,
      supplier: prod.supplier || {
        name: 'General Wholesale Supplier',
        phone: '011 234 5678',
        leadTimeDays: 2
      },
      estimatedCost: (prod.reorderQuantity || 25) * prod.costPrice
    }));
  }

  // --- STOCK LOGS ---
  public static getStockLogs(): StockLog[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.STOCK_LOGS);
      if (!data) {
        localStorage.setItem(STORAGE_KEYS.STOCK_LOGS, JSON.stringify(INITIAL_STOCK_LOGS));
        return INITIAL_STOCK_LOGS;
      }
      return JSON.parse(data);
    } catch {
      return INITIAL_STOCK_LOGS;
    }
  }

  private static addStockLog(log: Omit<StockLog, 'id' | 'timestamp'>): void {
    const logs = this.getStockLogs();
    const newLog: StockLog = {
      ...log,
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: new Date().toISOString()
    };
    logs.unshift(newLog);
    const trimmed = logs.slice(0, 150);
    localStorage.setItem(STORAGE_KEYS.STOCK_LOGS, JSON.stringify(trimmed));
  }

  // --- CART ---
  public static getCart(): CartItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CART);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  public static setCart(items: CartItem[]): void {
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(items));
    this.notify();
  }

  public static addToCart(product: Product, quantity: number = 1): { success: boolean; message?: string } {
    const cart = this.getCart();
    const liveProduct = this.getProductById(product.id) || product;

    const existingIndex = cart.findIndex((i) => i.product.id === product.id);
    const currentQtyInCart = existingIndex >= 0 ? cart[existingIndex].quantity : 0;
    const targetQty = currentQtyInCart + quantity;

    if (liveProduct.stock <= 0) {
      return { success: false, message: 'Item is currently Out of Stock!' };
    }

    if (targetQty > liveProduct.stock) {
      return {
        success: false,
        message: `Only ${liveProduct.stock} available in stock! (You already have ${currentQtyInCart} in cart)`
      };
    }

    const isWholesale = targetQty >= liveProduct.wholesaleMinQty;
    const unitPrice = isWholesale ? liveProduct.wholesalePrice : liveProdPrice(liveProduct);

    if (existingIndex >= 0) {
      cart[existingIndex].quantity = targetQty;
      cart[existingIndex].unitPrice = unitPrice;
      cart[existingIndex].isWholesaleApplied = isWholesale;
    } else {
      cart.push({
        product: liveProduct,
        quantity,
        unitPrice,
        isWholesaleApplied: isWholesale
      });
    }

    this.setCart(cart);
    return { success: true };
  }

  public static updateCartQuantity(productId: string, quantity: number): boolean {
    const cart = this.getCart();
    const liveProduct = this.getProductById(productId);

    if (quantity <= 0) {
      const filtered = cart.filter((i) => i.product.id !== productId);
      this.setCart(filtered);
      return true;
    }

    if (liveProduct && quantity > liveProduct.stock) {
      return false;
    }

    const item = cart.find((i) => i.product.id === productId);
    if (item && liveProduct) {
      const isWholesale = quantity >= liveProduct.wholesaleMinQty;
      item.quantity = quantity;
      item.unitPrice = isWholesale ? liveProduct.wholesalePrice : liveProduct.price;
      item.isWholesaleApplied = isWholesale;
      this.setCart(cart);
      return true;
    }
    return false;
  }

  public static removeFromCart(productId: string): void {
    const cart = this.getCart().filter((i) => i.product.id !== productId);
    this.setCart(cart);
  }

  public static clearCart(): void {
    this.setCart([]);
  }

  // --- FAVOURITES ---
  public static getFavourites(): string[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.FAVOURITES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  public static toggleFavourite(productId: string): boolean {
    const favs = this.getFavourites();
    const exists = favs.includes(productId);
    const updated = exists ? favs.filter((id) => id !== productId) : [...favs, productId];
    localStorage.setItem(STORAGE_KEYS.FAVOURITES, JSON.stringify(updated));
    this.notify();
    return !exists;
  }

  // --- RESET ALL DATA ---
  public static resetToDefault(): void {
    localStorage.setItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
    localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(INITIAL_CATEGORIES));
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(INITIAL_SAMPLE_ORDERS));
    localStorage.setItem(STORAGE_KEYS.STOCK_LOGS, JSON.stringify(INITIAL_STOCK_LOGS));
    localStorage.setItem(STORAGE_KEYS.CUSTOMERS, JSON.stringify(INITIAL_CUSTOMERS));
    localStorage.setItem(STORAGE_KEYS.RIDERS, JSON.stringify(INITIAL_RIDERS));
    localStorage.setItem(STORAGE_KEYS.DELIVERY_ZONES, JSON.stringify(INITIAL_DELIVERY_ZONES));
    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify([]));
    this.notify();
  }
}

function liveProdPrice(p: Product): number {
  return p.price;
}
