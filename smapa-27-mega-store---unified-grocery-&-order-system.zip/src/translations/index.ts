import { Order, OrderStatus } from '../types';

export const TRANSLATIONS = {
  en: {
    storeName: 'SMAPA 27 Mega Store',
    storeTagline: 'Fresh Groceries & Household Essentials',
    storeOmniBadge: 'Unified Real-Time Stock (Shop ↔ Web)',
    searchPlaceholder: 'Search for rice, dhal, milk powder, biscuits...',
    allCategories: 'All Categories',
    cart: 'Cart',
    favourites: 'Favourites',
    trackOrder: 'Track Order',
    adminPortal: 'Shop POS & Admin',
    switchCustomer: 'Customer View',
    switchAdmin: 'Admin / POS View',
    inStock: 'In Stock',
    lowStock: 'Low Stock',
    outOfStock: 'Out of Stock',
    left: 'left',
    addToCart: 'Add to Cart',
    addedToCart: 'Added to Cart!',
    wholesaleDiscount: 'Wholesale',
    wholesalePerUnit: 'Wholesale Price',
    each: 'each',
    itemsInCart: 'items in cart',
    subtotal: 'Subtotal',
    totalDiscount: 'Total Discount Received',
    youSaved: 'You Saved on this Bill',
    regularPrice: 'Regular MRP',
    printReceipt: 'Print Receipt / Bill',
    deliveryFee: 'Delivery Fee',
    freeDelivery: 'Free Delivery',
    total: 'Total',
    checkout: 'Proceed to Checkout',
    emptyCart: 'Your cart is empty',
    startShopping: 'Browse Products',
    orderViaWhatsApp: 'Quick Order via WhatsApp',
    
    // Checkout
    checkoutTitle: 'Complete Your Order',
    stepCustomer: '1. Customer Details',
    stepDelivery: '2. Delivery Method',
    stepPayment: '3. Payment Method',
    fullName: 'Full Name',
    fullNamePlaceholder: 'e.g. Nimal Perera',
    phone: 'Phone Number',
    phonePlaceholder: '07X XXXXXXX',
    whatsappOptional: 'WhatsApp Number (if different)',
    deliveryAddress: 'Delivery Address',
    deliveryAddressPlaceholder: 'House No, Street, Town',
    city: 'City / Area',
    cityPlaceholder: 'e.g. Maharagama, Kottawa, Colombo 03',
    notes: 'Special Delivery Notes (Optional)',
    notesPlaceholder: 'e.g. Near the temple, ring the bell',
    
    // Delivery Options
    standardDelivery: 'Standard Delivery',
    standardDesc: 'Delivery within 24-48 hours',
    expressDelivery: '⚡ Same-Day Express Delivery',
    expressDesc: 'Delivered today (within 3-5 hours)',
    storePickup: '🏪 In-Store Pick Up',
    pickupDesc: 'Collect free directly from our shop counter',
    free: 'FREE',

    // Payment Methods
    cod: '💵 Cash on Delivery (COD)',
    codDesc: 'Pay with cash upon package arrival',
    card: '💳 Credit / Debit Card (Online)',
    cardDesc: 'Fast & secure simulated card payment',
    bankTransfer: '🏦 Bank Transfer / Deposit',
    bankTransferDesc: 'Transfer to Commercial Bank / BOC and send slip',
    placeOrder: 'Place Order Now',
    placingOrder: 'Processing Order...',
    orderSuccessTitle: 'Order Placed Successfully! 🎉',
    orderSuccessSubtitle: 'Thank you for shopping with SMAPA 27 Mega Store.',
    orderIdText: 'Your Order ID',
    sendWhatsAppBtn: 'Send Order Summary via WhatsApp',
    trackOrderBtn: 'Track This Order',
    continueShopping: 'Continue Shopping',

    // Statuses
    status_new: 'Order Placed',
    status_confirmed: 'Confirmed',
    status_packing: 'Packing Items',
    status_out_for_delivery: 'Out for Delivery',
    status_delivered: 'Delivered',
    status_cancelled: 'Cancelled',

    // Order Tracking & Reorder
    trackTitle: 'Track Your Order',
    trackSubtitle: 'Enter your Order ID (e.g. LK-8421) or phone number to check live status',
    searchOrder: 'Find Order',
    reorderBtn: '🔄 Reorder All Items',
    reorderSuccess: 'Items added to cart for reorder!',
    noOrdersFound: 'No matching orders found.',
    recentOrders: 'Your Recent Orders',

    // WhatsApp Contact
    contactTitle: 'Contact Us',
    contactSubtitle: 'We are here to assist you daily from 7:30 AM to 9:30 PM',
    hotline: 'Hotline / Orders',
    whatsappChat: 'Chat on WhatsApp',
    storeLocation: 'Store Location',
    storeAddress: 'No. 128, High Level Road, Maharagama, Sri Lanka'
  },

  si: {
    storeName: 'SMAPA 27 Mega Store',
    storeTagline: 'නැවුම් එළවළු, බඩු බාහිරාදිය සහ සිල්ලර බඩු',
    storeOmniBadge: 'සජීවී ඒකාබද්ධ තොග පද්ධතිය (කඩේ ↔ වෙබ් අඩවිය)',
    searchPlaceholder: 'සහල්, පරිප්පු, කිරිපිටි, බිස්කට්, තෙල් සොයන්න...',
    allCategories: 'සියලු කාණ්ඩ',
    cart: 'කරත්තය',
    favourites: 'කැමති දෑ',
    trackOrder: 'ඇණවුම සොයන්න',
    adminPortal: 'කඩේ POS සහ Admin',
    switchCustomer: 'පාරිභෝගික මුහුණුවර',
    switchAdmin: 'කඩේ POS / Admin පාලනය',
    inStock: 'තොග ඇත',
    lowStock: 'තොග සීමිතයි',
    outOfStock: 'තොග අවසන්',
    left: 'ඉතිරියි',
    addToCart: 'කරත්තයට එක්කරන්න',
    addedToCart: 'කරත්තයට එක්කළා!',
    wholesaleDiscount: 'තොග මිල',
    wholesalePerUnit: 'තොග මිල',
    each: 'එකක්',
    itemsInCart: 'කරත්තයේ භාණ්ඩ',
    subtotal: 'මුළු එකතුව',
    totalDiscount: 'ලැබුණු මුළු වට්ටම',
    youSaved: 'ඔබ ඉතිරි කළ මුදල',
    regularPrice: 'සාමාන්‍ය මුල් මිල',
    printReceipt: 'රිසිට්පත Print කරන්න',
    deliveryFee: 'බෙදාහැරීමේ ගාස්තුව',
    freeDelivery: 'නොමිලේ බෙදාහැරීම',
    total: 'අවසාන මුදල',
    checkout: 'ඇණවුම සම්පූර්ණ කරන්න',
    emptyCart: 'ඔබේ කරත්තය හිස්ය',
    startShopping: 'බඩු තෝරන්න',
    orderViaWhatsApp: 'WhatsApp මඟින් ඉක්මන් ඇණවුම',

    // Checkout
    checkoutTitle: 'ඔබේ ඇණවුම සම්පූර්ණ කරන්න',
    stepCustomer: '1. පාරිභෝගික තොරතුරු',
    stepDelivery: '2. බෙදාහැරීමේ ක්‍රමය',
    stepPayment: '3. මුදල් ගෙවීමේ ක්‍රමය',
    fullName: 'සම්පූර්ණ නම',
    fullNamePlaceholder: 'උදා: නිමල් පෙරේරා',
    phone: 'දුරකථන අංකය',
    phonePlaceholder: '07X XXXXXXX',
    whatsappOptional: 'වට්ස්ඇප් අංකය (වෙනස් නම්)',
    deliveryAddress: 'බෙදාහැරිය යුතු ලිපිනය',
    deliveryAddressPlaceholder: 'නිවසේ අංකය, පාර, නගරය',
    city: 'නගරය / ප්‍රදේශය',
    cityPlaceholder: 'උදා: මහරගම, කොට්ටාව, නුගේගොඩ',
    notes: 'විශේෂ සටහන් (අවශ්‍ය නම්)',
    notesPlaceholder: 'උදා: පන්සල අසල, බෙල් එක ගසන්න',

    // Delivery Options
    standardDelivery: 'සාමාන්‍ය බෙදාහැරීම',
    standardDesc: 'පැය 24-48ක් ඇතුළත නිවසටම',
    expressDelivery: '⚡ එදිනම අධිවේගී බෙදාහැරීම',
    expressDesc: 'අදම පැය 3-5ක් ඇතුළත ලැබෙනු ඇත',
    storePickup: '🏪 කඩෙන් ඇවිත් ලබාගැනීම',
    pickupDesc: 'අපගේ කඩේ කවුන්ටරයෙන් නොමිලේ ලබාගන්න',
    free: 'නොමිලේ',

    // Payment Methods
    cod: '💵 භාණ්ඩ ලැබුණු පසු මුදල් ගෙවීම (COD)',
    codDesc: 'භාණ්ඩ ලැබුණු විට අතින් මුදල් ලබාදෙන්න',
    card: '💳 කාඩ්පත් මඟින් ගෙවීම (Online Card)',
    cardDesc: 'ක්ෂණික සුරක්ෂිත කාඩ්පත් ගෙවීම',
    bankTransfer: '🏦 බැංකු තැන්පතු / Transfer',
    bankTransferDesc: 'ලංකා බැංකුව / කොමර්ෂල් බැංකු ගිණුමට දමා රිසිට්පත එවන්න',
    placeOrder: 'ඇණවුම තහවුරු කරන්න',
    placingOrder: 'ඇණවුම සකස් කරමින්...',
    orderSuccessTitle: 'ඇණවුම සාර්ථකව භාරගන්නා ලදී! 🎉',
    orderSuccessSubtitle: 'SMAPA 27 Mega Store සමඟ සම්බන්ධ වීම ගැන ඔබට ස්තුතියි.',
    orderIdText: 'ඔබේ ඇණවුම් අංකය',
    sendWhatsAppBtn: 'ඇණවුම් විස්තර WhatsApp වෙත යවන්න',
    trackOrderBtn: 'ඇණවුමේ තත්වය බලන්න',
    continueShopping: 'තවත් බඩු තෝරන්න',

    // Statuses
    status_new: 'අලුත් ඇණවුම',
    status_confirmed: 'තහවුරු කර ඇත',
    status_packing: 'ඇසුරුම් කරමින්',
    status_out_for_delivery: 'බෙදාහැරීමට පිටත්ව ඇත',
    status_delivered: 'භාරදී ඇත',
    status_cancelled: 'අවලංගුයි',

    // Order Tracking & Reorder
    trackTitle: 'ඇණවුමේ තත්වය පරික්ෂා කරන්න',
    trackSubtitle: 'ඔබගේ ඇණවුම් අංකය (උදා: LK-8421) හෝ දුරකථන අංකය ඇතුළත් කරන්න',
    searchOrder: 'සොයන්න',
    reorderBtn: '🔄 නැවත ඇණවුම් කරන්න',
    reorderSuccess: 'භාණ්ඩ නැවත කරත්තයට එකතු විය!',
    noOrdersFound: 'ඇණවුම් කිසිවක් හමු නොවීය.',
    recentOrders: 'ඔබේ මෑත ඇණවුම්',

    // WhatsApp Contact
    contactTitle: 'අප අමතන්න',
    contactSubtitle: 'සෑම දිනකම උදෑසන 7:30 සිට රාත්‍රී 9:30 දක්වා අප ඔබගේ සේවයට සූදානම්',
    hotline: 'ක්ෂණික ඇමතුම් / ඇණවුම්',
    whatsappChat: 'WhatsApp මඟින් කතාබස් කරන්න',
    storeLocation: 'කඩේ ලිපිනය',
    storeAddress: 'නො. 128, හයිලෙවල් පාර, මහරගම'
  }
};

export function getStatusBadge(status: OrderStatus, lang: 'en' | 'si') {
  const t = TRANSLATIONS[lang];
  switch (status) {
    case 'new':
      return { label: t.status_new, color: 'bg-amber-100 text-amber-800 border-amber-300' };
    case 'confirmed':
      return { label: t.status_confirmed, color: 'bg-blue-100 text-blue-800 border-blue-300' };
    case 'packing':
      return { label: t.status_packing, color: 'bg-orange-100 text-orange-800 border-orange-300' };
    case 'out_for_delivery':
      return { label: t.status_out_for_delivery, color: 'bg-purple-100 text-purple-800 border-purple-300' };
    case 'delivered':
      return { label: t.status_delivered, color: 'bg-emerald-100 text-emerald-800 border-emerald-300' };
    case 'cancelled':
      return { label: t.status_cancelled, color: 'bg-rose-100 text-rose-800 border-rose-300' };
  }
}

export function formatWhatsAppMessage(order: Order, lang: 'en' | 'si'): string {
  const isSi = lang === 'si';
  const lines: string[] = [];

  // Calculate discount / savings
  let itemSavings = 0;
  for (const it of order.items) {
    const orig = (it.product.originalPrice && it.product.originalPrice > it.unitPrice)
      ? it.product.originalPrice
      : (it.product.price > it.unitPrice ? it.product.price : it.unitPrice);
    if (orig > it.unitPrice) {
      itemSavings += (orig - it.unitPrice) * it.quantity;
    }
  }
  const totalDiscount = Math.max(order.discount || 0, itemSavings);

  if (isSi) {
    lines.push(`*🛒 නව ලංකා මාර්ට් ඇණවුම - #${order.orderNumber}*`);
    lines.push(`🗓 දිනය: ${new Date(order.createdAt).toLocaleDateString()}`);
    lines.push(``);
    lines.push(`*👤 පාරිභෝගික තොරතුරු:*`);
    lines.push(`• නම: ${order.customer.name}`);
    lines.push(`• දුරකථන: ${order.customer.phone}`);
    lines.push(`• ලිපිනය: ${order.customer.address}, ${order.customer.city}`);
    if (order.customer.landmarkNotes) {
      lines.push(`• සටහන්: ${order.customer.landmarkNotes}`);
    }
    lines.push(``);
    lines.push(`*📦 ඇණවුම් කළ භාණ්ඩ:*`);
    order.items.forEach((item, idx) => {
      const orig = item.product.originalPrice && item.product.originalPrice > item.unitPrice
        ? ` (මුල් මිල: රු. ${item.product.originalPrice})`
        : '';
      lines.push(`${idx + 1}. ${item.product.nameSi} (${item.product.unitSi}) x ${item.quantity} = රු. ${(item.unitPrice * item.quantity).toLocaleString()}${orig}`);
    });
    lines.push(``);
    lines.push(`• අයිතම එකතුව: රු. ${order.subtotal.toLocaleString()}`);
    if (totalDiscount > 0) {
      lines.push(`🎉 *ඔබට ලැබුණු මුළු වට්ටම (Discount Saved): -රු. ${totalDiscount.toLocaleString()}*`);
    }
    lines.push(`• බෙදාහැරීමේ ගාස්තුව: රු. ${order.deliveryFee.toLocaleString()}`);
    lines.push(`*💰 සම්පූර්ණ මුදල: රු. ${order.total.toLocaleString()}*`);
    lines.push(`• ගෙවීමේ ක්‍රමය: ${order.paymentMethod === 'cod' ? 'Cash on Delivery (COD)' : order.paymentMethod === 'card' ? 'Online Card' : 'Bank Transfer'}`);
    lines.push(``);
    lines.push(`කරුණාකර මෙම ඇණවුම තහවුරු කර අපට දන්වන්න. ස්තුතියි!`);
  } else {
    lines.push(`*🛒 New LankaMart Order - #${order.orderNumber}*`);
    lines.push(`🗓 Date: ${new Date(order.createdAt).toLocaleDateString()}`);
    lines.push(``);
    lines.push(`*👤 Customer Details:*`);
    lines.push(`• Name: ${order.customer.name}`);
    lines.push(`• Phone: ${order.customer.phone}`);
    lines.push(`• Address: ${order.customer.address}, ${order.customer.city}`);
    if (order.customer.landmarkNotes) {
      lines.push(`• Notes: ${order.customer.landmarkNotes}`);
    }
    lines.push(``);
    lines.push(`*📦 Ordered Items:*`);
    order.items.forEach((item, idx) => {
      const orig = item.product.originalPrice && item.product.originalPrice > item.unitPrice
        ? ` (MRP: Rs. ${item.product.originalPrice})`
        : '';
      lines.push(`${idx + 1}. ${item.product.name} (${item.product.unit}) x ${item.quantity} = Rs. ${(item.unitPrice * item.quantity).toLocaleString()}${orig}`);
    });
    lines.push(``);
    lines.push(`• Items Subtotal: Rs. ${order.subtotal.toLocaleString()}`);
    if (totalDiscount > 0) {
      lines.push(`🎉 *You Saved (Total Discount): -Rs. ${totalDiscount.toLocaleString()}*`);
    }
    lines.push(`• Delivery: Rs. ${order.deliveryFee.toLocaleString()}`);
    lines.push(`*💰 Grand Total: Rs. ${order.total.toLocaleString()}*`);
    lines.push(`• Payment: ${order.paymentMethod === 'cod' ? 'Cash on Delivery' : order.paymentMethod === 'card' ? 'Online Card' : 'Bank Deposit'}`);
    lines.push(``);
    lines.push(`Please confirm this order. Thank you!`);
  }

  return encodeURIComponent(lines.join('\n'));
}
