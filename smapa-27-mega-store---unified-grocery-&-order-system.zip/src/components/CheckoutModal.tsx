import React, { useState } from 'react';
import {
  X, Truck, CreditCard, Banknote, Building2, MapPin, User,
  Phone, CheckCircle2, AlertCircle, Sparkles, Navigation, Clock
} from 'lucide-react';
import { CartItem, DeliveryOption, DeliveryZone, Language, Order, OrderCustomer, PaymentMethod } from '../types';
import { TRANSLATIONS } from '../translations';
import { UnifiedStore } from '../services/store';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  lang: Language;
  onOrderSuccess: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  lang,
  onOrderSuccess
}) => {
  const t = TRANSLATIONS[lang];
  const isSi = lang === 'si';

  const deliveryZones = UnifiedStore.getDeliveryZones();
  const loggedInCustomer = UnifiedStore.getActiveCustomer();

  const [customer, setCustomer] = useState<OrderCustomer>({
    name: loggedInCustomer?.name || '',
    phone: loggedInCustomer?.phone || '',
    whatsapp: loggedInCustomer?.phone || '',
    address: loggedInCustomer?.address || '',
    city: loggedInCustomer?.city || 'Maharagama',
    landmarkNotes: loggedInCustomer?.landmarkNotes || ''
  });

  const [deliveryZone, setDeliveryZone] = useState<DeliveryZone>('colombo_suburbs');
  const [deliveryOption, setDeliveryOption] = useState<DeliveryOption>('standard');
  const [deliveryTimeSlot, setDeliveryTimeSlot] = useState<string>('morning');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cod');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Active zone config
  const activeZoneConfig = deliveryZones.find((z) => z.id === deliveryZone) || deliveryZones[0];

  // Subtotal with wholesale pricing consideration
  const subtotal = items.reduce((sum, i) => sum + (i.unitPrice || i.product.price) * i.quantity, 0);

  const totalRegularPrice = items.reduce((sum, item) => {
    const orig = item.product.originalPrice && item.product.originalPrice > item.product.price
      ? item.product.originalPrice
      : item.product.price;
    return sum + orig * item.quantity;
  }, 0);
  const totalSavings = Math.max(0, totalRegularPrice - subtotal);

  const isFreeDeliveryQualified =
    activeZoneConfig.freeDeliveryThreshold &&
    subtotal >= activeZoneConfig.freeDeliveryThreshold &&
    deliveryOption === 'standard';

  const currentDeliveryFee =
    deliveryOption === 'pickup'
      ? 0
      : isFreeDeliveryQualified
      ? 0
      : deliveryOption === 'express'
      ? activeZoneConfig.expressFee
      : activeZoneConfig.standardFee;

  const total = subtotal + currentDeliveryFee;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!customer.name.trim()) {
      setErrorMsg(isSi ? 'කරුණාකර ඔබගේ නම ඇතුළත් කරන්න.' : 'Please enter your full name.');
      return;
    }
    if (!customer.phone.trim() || customer.phone.trim().length < 9) {
      setErrorMsg(isSi ? 'වලංගු දුරකථන අංකයක් ඇතුළත් කරන්න (උදා: 0771234567).' : 'Please enter a valid phone number (e.g. 0771234567).');
      return;
    }
    if (deliveryOption !== 'pickup' && !customer.address.trim()) {
      setErrorMsg(isSi ? 'බෙදාහැරිය යුතු ලිපිනය ඇතුළත් කරන්න.' : 'Please enter your delivery street address.');
      return;
    }
    if (deliveryOption !== 'pickup' && !customer.city.trim()) {
      setErrorMsg(isSi ? 'නගරය හෝ ප්‍රදේශය සඳහන් කරන්න.' : 'Please enter your city/town.');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const result = UnifiedStore.placeOnlineOrder(
        customer,
        items,
        deliveryOption,
        deliveryZone,
        currentDeliveryFee,
        paymentMethod,
        deliveryTimeSlot
      );

      setIsSubmitting(false);

      if (result.success && result.order) {
        onOrderSuccess(result.order);
      } else {
        setErrorMsg(result.error || (isSi ? 'ඇණවුම සකස් කිරීමේදී ගැටලුවක් ඇති විය.' : 'Error placing order. Please try again.'));
      }
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto p-4 sm:p-6 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 relative max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">{t.checkoutTitle}</h2>
            <p className="text-xs text-slate-500">{items.length} {t.itemsInCart}</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white text-slate-400 hover:text-slate-700 shadow-xs flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-6 space-y-6 flex-1">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Section 1: Customer Details */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-800">
              <User className="w-4 h-4 text-emerald-600" />
              <span>{t.stepCustomer}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {t.fullName} *
                </label>
                <input
                  type="text"
                  required
                  value={customer.name}
                  onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
                  placeholder={t.fullNamePlaceholder}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {t.phone} *
                </label>
                <input
                  type="tel"
                  required
                  value={customer.phone}
                  onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                  placeholder={t.phonePlaceholder}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {t.whatsappOptional}
                </label>
                <input
                  type="tel"
                  value={customer.whatsapp || ''}
                  onChange={(e) => setCustomer({ ...customer, whatsapp: e.target.value })}
                  placeholder="07X XXXXXXX"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Delivery Zone & Option */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-800">
              <Truck className="w-4 h-4 text-emerald-600" />
              <span>{t.stepDelivery} & Delivery Zones</span>
            </div>

            {/* Zone Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Select Your Delivery Area / Zone *
              </label>
              <select
                value={deliveryZone}
                onChange={(e) => setDeliveryZone(e.target.value as DeliveryZone)}
                className="w-full px-3 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none font-medium"
              >
                {deliveryZones.map((z) => (
                  <option key={z.id} value={z.id}>
                    {isSi ? z.nameSi : z.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Delivery Method Options */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Standard */}
              <label
                onClick={() => setDeliveryOption('standard')}
                className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                  deliveryOption === 'standard'
                    ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-slate-50/40'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-900">{t.standardDelivery}</span>
                    <span className="text-xs font-bold text-emerald-700">Rs. {activeZoneConfig.standardFee}</span>
                  </div>
                  <p className="text-[11px] text-slate-500">{activeZoneConfig.estimatedHours}</p>
                </div>
              </label>

              {/* Express */}
              <label
                onClick={() => setDeliveryOption('express')}
                className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                  deliveryOption === 'express'
                    ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-slate-50/40'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-900">{t.expressDelivery}</span>
                    <span className="text-xs font-bold text-emerald-700">Rs. {activeZoneConfig.expressFee}</span>
                  </div>
                  <p className="text-[11px] text-slate-500">Same-Day Priority Dispatch</p>
                </div>
              </label>

              {/* Store Pickup */}
              <label
                onClick={() => setDeliveryOption('pickup')}
                className={`p-3 rounded-2xl border cursor-pointer transition-all flex flex-col justify-between ${
                  deliveryOption === 'pickup'
                    ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-slate-50/40'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-slate-900">{t.storePickup}</span>
                    <span className="text-xs font-bold text-emerald-600 bg-emerald-100 px-1.5 py-0.2 rounded">
                      FREE
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">{t.pickupDesc}</p>
                </div>
              </label>
            </div>

            {/* Free Delivery Threshold Alert / Progress */}
            {activeZoneConfig.freeDeliveryThreshold && (
              <div className="p-3 bg-emerald-50/90 rounded-2xl border border-emerald-200 text-xs">
                {isFreeDeliveryQualified ? (
                  <div className="flex items-center gap-2 text-emerald-800 font-bold">
                    <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>🎉 {isSi ? 'සුභ පැතුම්! ඔබගේ ඇණවුම සඳහා නොමිලේ Standard Delivery හිමිවිය!' : 'Congratulations! You qualified for FREE Standard Delivery!'}</span>
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-slate-700">
                      <span>
                        {isSi ? 'නොමිලේ ඩිලිවරි ලබාගැනීමට තව ' : 'Add '}
                        <strong className="text-emerald-700 font-bold">Rs. {(activeZoneConfig.freeDeliveryThreshold - subtotal).toLocaleString()}</strong>
                        {isSi ? ' ක බඩු එක්කරන්න!' : ' more for FREE DELIVERY!'}
                      </span>
                      <span className="font-bold text-emerald-800">{Math.round((subtotal / activeZoneConfig.freeDeliveryThreshold) * 100)}%</span>
                    </div>
                    <div className="w-full bg-emerald-200/50 rounded-full h-1.5 overflow-hidden">
                      <div
                        className="bg-emerald-600 h-1.5 rounded-full transition-all duration-300"
                        style={{ width: `${Math.min(100, (subtotal / activeZoneConfig.freeDeliveryThreshold) * 100)}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Delivery Time Slots */}
            {deliveryOption !== 'pickup' && (
              <div className="space-y-1.5 pt-1">
                <label className="block text-xs font-semibold text-slate-700 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{isSi ? 'බෙදාහැරිය යුතු වෙලාව (Delivery Slot)' : 'Preferred Delivery Time Slot'} *</span>
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setDeliveryTimeSlot('Morning (8:00 AM - 12:00 PM)')}
                    className={`p-2 rounded-xl border text-center cursor-pointer transition-all ${
                      deliveryTimeSlot.startsWith('Morning')
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold ring-1 ring-emerald-500'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-[11px] block font-semibold">🌅 {isSi ? 'උදෑසන' : 'Morning'}</span>
                    <span className="text-[9px] text-slate-500">8 AM - 12 PM</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeliveryTimeSlot('Afternoon (1:00 PM - 5:00 PM)')}
                    className={`p-2 rounded-xl border text-center cursor-pointer transition-all ${
                      deliveryTimeSlot.startsWith('Afternoon')
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold ring-1 ring-emerald-500'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-[11px] block font-semibold">☀️ {isSi ? 'දවල්' : 'Afternoon'}</span>
                    <span className="text-[9px] text-slate-500">1 PM - 5 PM</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeliveryTimeSlot('Evening Express (6:00 PM - 9:30 PM)')}
                    className={`p-2 rounded-xl border text-center cursor-pointer transition-all ${
                      deliveryTimeSlot.startsWith('Evening')
                        ? 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold ring-1 ring-emerald-500'
                        : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <span className="text-[11px] block font-semibold">🌙 {isSi ? 'සවස' : 'Evening'}</span>
                    <span className="text-[9px] text-slate-500">6 PM - 9:30 PM</span>
                  </button>
                </div>
              </div>
            )}

            {/* Address fields (if not pickup) */}
            {deliveryOption !== 'pickup' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {t.deliveryAddress} *
                  </label>
                  <input
                    type="text"
                    required
                    value={customer.address}
                    onChange={(e) => setCustomer({ ...customer, address: e.target.value })}
                    placeholder={t.deliveryAddressPlaceholder}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {t.city} *
                  </label>
                  <input
                    type="text"
                    required
                    value={customer.city}
                    onChange={(e) => setCustomer({ ...customer, city: e.target.value })}
                    placeholder={t.cityPlaceholder}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    {t.notes}
                  </label>
                  <input
                    type="text"
                    value={customer.landmarkNotes || ''}
                    onChange={(e) => setCustomer({ ...customer, landmarkNotes: e.target.value })}
                    placeholder={t.notesPlaceholder}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Section 3: Payment Method */}
          <div className="space-y-3 pt-2 border-t border-slate-100">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-800">
              <CreditCard className="w-4 h-4 text-emerald-600" />
              <span>{t.stepPayment}</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <label
                onClick={() => setPaymentMethod('cod')}
                className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                  paymentMethod === 'cod'
                    ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-xs text-slate-900 mb-1">
                  <Banknote className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Cash on Delivery</span>
                </div>
                <p className="text-[11px] text-slate-500">{t.codDesc}</p>
              </label>

              <label
                onClick={() => setPaymentMethod('card')}
                className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                  paymentMethod === 'card'
                    ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-xs text-slate-900 mb-1">
                  <CreditCard className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Card (Online)</span>
                </div>
                <p className="text-[11px] text-slate-500">{t.cardDesc}</p>
              </label>

              <label
                onClick={() => setPaymentMethod('bank_transfer')}
                className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                  paymentMethod === 'bank_transfer'
                    ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-1.5 font-bold text-xs text-slate-900 mb-1">
                  <Building2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Bank Deposit</span>
                </div>
                <p className="text-[11px] text-slate-500">{t.bankTransferDesc}</p>
              </label>
            </div>
          </div>

          {/* Order Summary Box */}
          <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 space-y-2 text-xs">
            {totalSavings > 0 && (
              <div className="p-2.5 rounded-xl bg-emerald-100/90 border border-emerald-300 flex items-center justify-between text-emerald-950 font-bold mb-1 shadow-xs">
                <span>🎉 {isSi ? 'ඔබ මෙම ඇණවුමෙන් ඉතිරි කළ මුදල:' : 'You are saving on this order:'}</span>
                <span className="text-emerald-700 font-black text-xs sm:text-sm">
                  -Rs. {totalSavings.toLocaleString()}
                </span>
              </div>
            )}
            <div className="flex justify-between text-slate-600">
              <span>{t.subtotal}</span>
              <div className="text-right">
                {totalSavings > 0 && (
                  <span className="text-[11px] text-slate-400 line-through mr-1.5">
                    Rs. {totalRegularPrice.toLocaleString()}
                  </span>
                )}
                <span className="font-semibold text-slate-900">Rs. {subtotal.toLocaleString()}</span>
              </div>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>{t.deliveryFee} ({activeZoneConfig.name.split('(')[0]})</span>
              <span className="font-semibold text-slate-900">
                {currentDeliveryFee === 0 ? t.free : `Rs. ${currentDeliveryFee.toLocaleString()}`}
              </span>
            </div>
            <div className="flex justify-between text-sm font-extrabold text-slate-950 pt-2 border-t border-slate-200">
              <span>{t.total}</span>
              <span className="text-emerald-700">Rs. {total.toLocaleString()}</span>
            </div>
          </div>

          {/* Submit button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.99] text-sm"
          >
            {isSubmitting ? (
              <span>{t.placingOrder}</span>
            ) : (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>{t.placeOrder} (Rs. {total.toLocaleString()})</span>
              </>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
