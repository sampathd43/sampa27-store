import React, { useState, useEffect } from 'react';
import {
  X, CreditCard, ShieldCheck, CheckCircle2, AlertCircle, QrCode,
  Building2, Banknote, Copy, Upload, ArrowRight, Lock, Smartphone, RefreshCw, Check, Sparkles
} from 'lucide-react';
import { Language, Order, PaymentMethod } from '../types';
import { TRANSLATIONS } from '../translations';
import { UnifiedStore } from '../services/store';

interface PaymentGatewayModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  lang: Language;
  onPaymentSuccess: (order: Order, transactionId: string) => void;
}

type IPGStep = 'select_method' | 'card_entry' | 'bank_otp_3ds' | 'lanka_qr' | 'bank_slip' | 'success';

export const PaymentGatewayModal: React.FC<PaymentGatewayModalProps> = ({
  isOpen,
  onClose,
  order,
  lang,
  onPaymentSuccess
}) => {
  const t = TRANSLATIONS[lang];
  const isSi = lang === 'si';

  const [activeStep, setActiveStep] = useState<IPGStep>(
    order?.paymentMethod === 'card'
      ? 'card_entry'
      : order?.paymentMethod === 'bank_transfer'
      ? 'bank_slip'
      : 'select_method'
  );

  // Card Form State
  const [cardNumber, setCardNumber] = useState('4532 •••• •••• 8921');
  const [cardHolder, setCardHolder] = useState(order?.customer?.name || 'Kasun Bandara');
  const [expiry, setExpiry] = useState('08/28');
  const [cvv, setCvv] = useState('784');
  const [cardBrand, setCardBrand] = useState<'visa' | 'mastercard'>('visa');

  // 3D Secure State
  const [otpValue, setOtpValue] = useState('');
  const [isVerifyingOtp, setIsVerifyingOtp] = useState(false);
  const [otpTimer, setOtpTimer] = useState(115);
  const sampleBankOtp = '742918';

  // LankaQR State
  const [isScanningQr, setIsScanningQr] = useState(false);
  const [selectedBankApp, setSelectedBankApp] = useState('Commercial Bank Q+');

  // Bank Slip State
  const [selectedBank, setSelectedBank] = useState('Commercial Bank of Ceylon');
  const [bankRefNo, setBankRefNo] = useState(`REF-${Math.floor(100000 + Math.random() * 900000)}`);
  const [slipAttached, setSlipAttached] = useState(true);
  const [copiedBankAcc, setCopiedBankAcc] = useState(false);

  // Success details
  const [completedTxnId, setCompletedTxnId] = useState('');

  // Countdown timer for 3D Secure
  useEffect(() => {
    let interval: any;
    if (activeStep === 'bank_otp_3ds' && otpTimer > 0) {
      interval = setInterval(() => setOtpTimer((t) => t - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [activeStep, otpTimer]);

  if (!isOpen || !order) return null;

  // Card input format & brand detection
  const handleCardNumberChange = (val: string) => {
    setCardNumber(val);
    if (val.startsWith('5')) {
      setCardBrand('mastercard');
    } else {
      setCardBrand('visa');
    }
  };

  // Submit Card to Bank 3D Secure
  const handleProceedTo3DSecure = (e: React.FormEvent) => {
    e.preventDefault();
    setActiveStep('bank_otp_3ds');
    setOtpTimer(120);
  };

  // Verify 3D-Secure Bank OTP
  const handleVerifyOtp = async () => {
    if (!otpValue || otpValue.trim() !== sampleBankOtp) {
      alert(isSi ? `කරුණාකර නිවැරදි OTP අංකය (${sampleBankOtp}) ඇතුළත් කරන්න.` : `Please enter the valid OTP code (${sampleBankOtp}).`);
      return;
    }

    setIsVerifyingOtp(true);

    try {
      const response = await fetch('/api/payment/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: order.orderNumber,
          otp: otpValue,
          amount: order.total,
          cardLast4: '8921'
        })
      });

      const data = await response.json();
      setIsVerifyingOtp(false);

      if (data.success) {
        const txnId = data.transactionId;
        setCompletedTxnId(txnId);
        setActiveStep('success');

        // Update order in unified database to paid
        order.paymentStatus = 'paid';
        UnifiedStore.updateOrderStatus(order.id, 'confirmed', `Online Card Payment verified (Ref: ${txnId})`);
        onPaymentSuccess(order, txnId);
      }
    } catch {
      setIsVerifyingOtp(false);
      const fallbackTxn = `TXN-IPG-${Math.floor(100000 + Math.random() * 900000)}`;
      setCompletedTxnId(fallbackTxn);
      setActiveStep('success');
      order.paymentStatus = 'paid';
      UnifiedStore.updateOrderStatus(order.id, 'confirmed', `Online Card Payment verified (Ref: ${fallbackTxn})`);
      onPaymentSuccess(order, fallbackTxn);
    }
  };

  // Simulate LankaQR scan & payment verification
  const handleVerifyLankaQr = async () => {
    setIsScanningQr(true);

    try {
      const response = await fetch('/api/payment/lankaqr-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: order.orderNumber,
          amount: order.total,
          bankApp: selectedBankApp
        })
      });

      const data = await response.json();
      setIsScanningQr(false);

      if (data.success) {
        const qrTxn = data.qrReference;
        setCompletedTxnId(qrTxn);
        setActiveStep('success');
        order.paymentStatus = 'paid';
        UnifiedStore.updateOrderStatus(order.id, 'confirmed', `LankaQR Payment received via ${selectedBankApp} (Ref: ${qrTxn})`);
        onPaymentSuccess(order, qrTxn);
      }
    } catch {
      setIsScanningQr(false);
      const fallbackQr = `LQR-${Math.floor(10000000 + Math.random() * 90000000)}`;
      setCompletedTxnId(fallbackQr);
      setActiveStep('success');
      order.paymentStatus = 'paid';
      UnifiedStore.updateOrderStatus(order.id, 'confirmed', `LankaQR Payment received via ${selectedBankApp} (Ref: ${fallbackQr})`);
      onPaymentSuccess(order, fallbackQr);
    }
  };

  // Submit Bank Transfer Slip
  const handleSubmitBankSlip = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      await fetch('/api/payment/bank-slip', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: order.orderNumber,
          bankName: selectedBank,
          referenceNumber: bankRefNo,
          slipImage: 'sample_deposit_slip.jpg'
        })
      });
    } catch {
      // offline safe
    }

    setCompletedTxnId(bankRefNo);
    setActiveStep('success');
    order.paymentStatus = 'paid';
    UnifiedStore.updateOrderStatus(order.id, 'confirmed', `Bank deposit verified: ${selectedBank} (Ref: ${bankRefNo})`);
    onPaymentSuccess(order, bankRefNo);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedBankAcc(true);
    setTimeout(() => setCopiedBankAcc(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 p-4 sm:p-6 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100 relative flex flex-col max-h-[92vh]">
        {/* Gateway Brand Header */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-sm tracking-tight text-white">LankaPay IPG</span>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded border border-emerald-800 font-mono font-bold">
                  256-bit SSL Secure
                </span>
              </div>
              <p className="text-[11px] text-slate-400">Order #{order.orderNumber} • Rs. {order.total.toLocaleString()}</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Dynamic Step Content */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-slate-800 text-xs">
          {/* ================= STEP: CARD ENTRY ================= */}
          {activeStep === 'card_entry' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="font-bold text-sm text-slate-900">
                  {isSi ? 'කාඩ්පත් විස්තර ඇතුළත් කරන්න' : 'Credit / Debit Card Payment'}
                </span>
                <div className="flex items-center gap-1.5">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${cardBrand === 'visa' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-500'}`}>
                    VISA
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${cardBrand === 'mastercard' ? 'bg-orange-100 text-orange-800' : 'bg-slate-100 text-slate-500'}`}>
                    Mastercard
                  </span>
                </div>
              </div>

              {/* Virtual Card Graphic */}
              <div className="bg-gradient-to-tr from-slate-900 via-slate-800 to-emerald-950 text-white rounded-2xl p-5 shadow-lg space-y-4 border border-slate-700/60">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-mono text-emerald-400 font-bold tracking-widest">LANKAMART PAY</span>
                  <span className="uppercase font-bold tracking-wider">{cardBrand}</span>
                </div>
                <div className="font-mono text-base tracking-widest text-emerald-200">
                  {cardNumber}
                </div>
                <div className="flex justify-between items-end text-[11px] text-slate-300">
                  <div>
                    <span className="text-[9px] text-slate-400 block uppercase">Cardholder</span>
                    <span className="font-semibold">{cardHolder}</span>
                  </div>
                  <div>
                    <span className="text-[9px] text-slate-400 block uppercase">Expires</span>
                    <span className="font-mono">{expiry}</span>
                  </div>
                </div>
              </div>

              {/* Card Inputs */}
              <form onSubmit={handleProceedTo3DSecure} className="space-y-3 pt-1">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Card Number</label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={cardNumber}
                      onChange={(e) => handleCardNumberChange(e.target.value)}
                      placeholder="4532 0000 0000 0000"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none font-mono"
                    />
                    <CreditCard className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">Expiry Date</label>
                    <input
                      type="text"
                      required
                      value={expiry}
                      onChange={(e) => setExpiry(e.target.value)}
                      placeholder="MM/YY"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-slate-700 mb-1">CVV / CVC</label>
                    <input
                      type="password"
                      required
                      maxLength={4}
                      value={cvv}
                      onChange={(e) => setCvv(e.target.value)}
                      placeholder="784"
                      className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">Cardholder Name</label>
                  <input
                    type="text"
                    required
                    value={cardHolder}
                    onChange={(e) => setCardHolder(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.99] text-xs"
                  >
                    <Lock className="w-4 h-4" />
                    <span>Pay Rs. {order.total.toLocaleString()} via 3D Secure</span>
                  </button>
                </div>
              </form>

              <div className="flex items-center justify-center gap-4 pt-2 text-[11px] text-slate-400">
                <button
                  type="button"
                  onClick={() => setActiveStep('lanka_qr')}
                  className="text-emerald-700 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Pay with LankaQR</span>
                </button>
                <span>•</span>
                <button
                  type="button"
                  onClick={() => setActiveStep('bank_slip')}
                  className="text-emerald-700 font-semibold hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <Building2 className="w-3.5 h-3.5" />
                  <span>Bank Transfer</span>
                </button>
              </div>
            </div>
          )}

          {/* ================= STEP: 3D SECURE BANK OTP ================= */}
          {activeStep === 'bank_otp_3ds' && (
            <div className="space-y-4">
              {/* Official Bank Header */}
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-extrabold text-blue-900 text-xs tracking-wider">
                    COMMERCIAL BANK / BOC 3D-SECURE ACS
                  </span>
                  <span className="text-[10px] font-mono text-slate-500">Merchant: LankaMart</span>
                </div>
                <p className="text-[11px] text-slate-600">
                  {isSi
                    ? 'ඔබගේ ලියාපදිංචි ජංගම දුරකථනයට (077 **** 567) තාවකාලික මුරපදයක් (OTP) එවා ඇත.'
                    : 'A One-Time Password (OTP) has been dispatched to your mobile number ending in **** 567.'}
                </p>
              </div>

              {/* OTP Input & Autofill */}
              <div className="p-5 border border-dashed border-emerald-300 bg-emerald-50/50 rounded-2xl space-y-3 text-center">
                <span className="text-xs font-bold text-slate-700 block">
                  Enter 6-Digit Bank Verification OTP
                </span>

                <div className="max-w-[180px] mx-auto">
                  <input
                    type="text"
                    maxLength={6}
                    value={otpValue}
                    onChange={(e) => setOtpValue(e.target.value)}
                    placeholder="742918"
                    className="w-full text-center text-xl font-mono font-black tracking-widest py-2 bg-white border-2 border-emerald-500 rounded-xl outline-none text-slate-900"
                  />
                </div>

                {/* 1-Click Autofill Sandbox button */}
                <button
                  type="button"
                  onClick={() => setOtpValue(sampleBankOtp)}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-200 text-emerald-900 font-bold text-[11px] hover:bg-emerald-300 transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-emerald-800" />
                  <span>Autofill Simulated Bank OTP ({sampleBankOtp})</span>
                </button>

                <p className="text-[10px] text-slate-400">
                  Expires in {Math.floor(otpTimer / 60)}:{(otpTimer % 60).toString().padStart(2, '0')} mins
                </p>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveStep('card_entry')}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
                >
                  Back
                </button>

                <button
                  type="button"
                  disabled={isVerifyingOtp}
                  onClick={handleVerifyOtp}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
                >
                  {isVerifyingOtp ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Authenticating with Bank...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Confirm & Authorize Payment</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* ================= STEP: LANKAQR DYNAMIC QR ================= */}
          {activeStep === 'lanka_qr' && (
            <div className="space-y-4 text-center">
              <div className="space-y-1">
                <h3 className="font-bold text-sm text-slate-900">
                  {isSi ? 'LankaQR මඟින් ක්ෂණිකව ගෙවන්න' : 'Scan & Pay via LankaQR'}
                </h3>
                <p className="text-[11px] text-slate-500">
                  Scan with Commercial Bank Q+, FriMi, Flash, Genie, BOC SmartPay or any LankaPay app.
                </p>
              </div>

              {/* Dynamic QR Code Representation */}
              <div className="w-52 h-52 mx-auto p-4 bg-white rounded-3xl border-2 border-emerald-500/80 shadow-lg flex flex-col items-center justify-center space-y-2 relative">
                {/* Real svg barcode matrix visual */}
                <div className="w-full h-full bg-slate-950 p-2 rounded-2xl flex items-center justify-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(#22c55e_1px,transparent_1px)] [background-size:12px_12px] opacity-80" />
                  <div className="relative z-10 p-3 bg-white rounded-xl shadow-md text-center">
                    <QrCode className="w-20 h-20 text-slate-950" />
                    <span className="text-[9px] font-black text-slate-900 uppercase font-mono block">
                      LANKAPAY EMVCo
                    </span>
                  </div>
                </div>
              </div>

              {/* LankaQR Amount Pill */}
              <div className="inline-block bg-slate-100 px-4 py-1.5 rounded-full font-mono text-xs font-bold text-slate-800">
                Amount: <strong className="text-emerald-700 text-sm">Rs. {order.total.toLocaleString()}</strong>
              </div>

              {/* Bank App Selector for simulation */}
              <div className="text-left bg-slate-50 p-3 rounded-2xl border border-slate-200 space-y-1.5">
                <label className="text-[11px] font-bold text-slate-700 block">
                  Select Your Banking App (Simulate Real-time Scan):
                </label>
                <select
                  value={selectedBankApp}
                  onChange={(e) => setSelectedBankApp(e.target.value)}
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl text-xs font-semibold outline-none text-slate-800"
                >
                  <option value="Commercial Bank Q+">Commercial Bank Q+</option>
                  <option value="Nations Trust FriMi">Nations Trust FriMi</option>
                  <option value="Sampath WePay">Sampath WePay</option>
                  <option value="BOC SmartPay">BOC SmartPay</option>
                  <option value="Dialog Genie">Dialog Genie</option>
                </select>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setActiveStep('card_entry')}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
                >
                  Back
                </button>

                <button
                  type="button"
                  disabled={isScanningQr}
                  onClick={handleVerifyLankaQr}
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
                >
                  {isScanningQr ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Verifying with LankaPay Switch...</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Simulate App Scan & Pay</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* ================= STEP: BANK SLIP UPLOAD ================= */}
          {activeStep === 'bank_slip' && (
            <form onSubmit={handleSubmitBankSlip} className="space-y-4">
              <div className="space-y-1">
                <h3 className="font-bold text-sm text-slate-900">
                  {isSi ? 'බැංකු තැන්පතු රිසිට්පත (Bank Deposit Slip)' : 'Direct Bank Deposit / Transfer'}
                </h3>
                <p className="text-[11px] text-slate-500">
                  Transfer the exact amount to one of our official bank accounts and provide reference.
                </p>
              </div>

              {/* Bank Account Details Card */}
              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-2">
                <div className="flex items-center justify-between text-xs font-bold text-slate-900">
                  <span>Commercial Bank of Ceylon</span>
                  <span className="text-emerald-700">Maharagama Branch</span>
                </div>
                <div className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-200 font-mono text-xs">
                  <span className="font-bold text-slate-800">1000 4829 1920</span>
                  <button
                    type="button"
                    onClick={() => copyToClipboard('100048291920')}
                    className="flex items-center gap-1 text-[11px] text-emerald-700 font-bold hover:underline cursor-pointer"
                  >
                    {copiedBankAcc ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedBankAcc ? 'Copied!' : 'Copy'}</span>
                  </button>
                </div>
                <p className="text-[10px] text-slate-500">Account Name: LankaMart (Pvt) Ltd</p>
              </div>

              {/* Deposit Reference & Slip selector */}
              <div className="space-y-3">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    Bank Reference / Transaction ID *
                  </label>
                  <input
                    type="text"
                    required
                    value={bankRefNo}
                    onChange={(e) => setBankRefNo(e.target.value)}
                    placeholder="e.g. REF-482914 or CEFT94821"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none font-mono"
                  />
                </div>

                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <div>
                      <span className="font-bold text-slate-800 block text-xs">deposit_slip_verified.jpg</span>
                      <span className="text-[10px] text-emerald-700">Ready for instant confirmation</span>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold bg-white text-emerald-800 px-2 py-0.5 rounded border border-emerald-300">
                    Attached
                  </span>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveStep('card_entry')}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl cursor-pointer"
                >
                  Back
                </button>

                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Submit Deposit Verification</span>
                </button>
              </div>
            </form>
          )}

          {/* ================= STEP: SUCCESS CONFIRMATION ================= */}
          {activeStep === 'success' && (
            <div className="text-center space-y-4 py-4">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md shadow-emerald-500/20">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-1">
                <h3 className="text-lg font-black text-slate-900">
                  {isSi ? 'ගෙවීම සාර්ථකව තහවුරු විය! 🎉' : 'Payment Successfully Authorized! 🎉'}
                </h3>
                <p className="text-xs text-slate-500">
                  Transaction approved by banking network and recorded into LankaMart unified engine.
                </p>
              </div>

              <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left space-y-1.5 font-mono text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Transaction Ref:</span>
                  <span className="font-bold text-slate-900">{completedTxnId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Order ID:</span>
                  <span className="font-bold text-slate-900">#{order.orderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Amount Paid:</span>
                  <span className="font-bold text-emerald-700">Rs. {order.total.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Payment Status:</span>
                  <span className="text-emerald-700 font-bold">PAID (SETTLED)</span>
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-2xl cursor-pointer transition-colors"
              >
                Close & View Order Receipt
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
