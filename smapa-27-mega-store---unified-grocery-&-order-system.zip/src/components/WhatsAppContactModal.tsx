import React from 'react';
import { X, MessageCircle, Phone, MapPin, Clock, ExternalLink } from 'lucide-react';
import { Language } from '../types';
import { TRANSLATIONS } from '../translations';

interface WhatsAppContactModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const WhatsAppContactModal: React.FC<WhatsAppContactModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  if (!isOpen) return null;

  const t = TRANSLATIONS[lang];
  const isSi = lang === 'si';

  const phoneNum = '077 477 8190';
  const whatsappUrl = `https://wa.me/94774778190?text=${encodeURIComponent(
    isSi ? 'ආයුබෝවන් ලංකා මාර්ට්! මට බඩු ඇණවුම් කිරීම පිළිබඳව විස්තර දැනගැනීමට අවශ්‍යයි.' : 'Hello LankaMart! I would like to inquire about grocery orders.'
  )}`;

  return (
    <div className="fixed inset-0 z-50 p-4 sm:p-6 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-100 relative p-6 sm:p-8 space-y-5">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-[#25D366]/15 text-[#25D366] flex items-center justify-center">
              <MessageCircle className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900">{t.contactTitle}</h2>
              <p className="text-xs text-slate-500">LankaMart Customer Support</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 text-slate-400 hover:text-slate-700 flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-slate-600 leading-relaxed">
          {t.contactSubtitle}
        </p>

        {/* Contact Links */}
        <div className="space-y-3">
          {/* WhatsApp Direct Chat */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-between p-3.5 bg-emerald-50/80 hover:bg-emerald-100/80 border border-emerald-200 rounded-2xl transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-[#25D366] text-white flex items-center justify-center shadow-xs">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 block">{t.whatsappChat}</span>
                <span className="text-xs text-emerald-800 font-mono">+94 77 477 8190</span>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 text-emerald-600 group-hover:translate-x-0.5 transition-transform" />
          </a>

          {/* Hotline */}
          <a
            href="tel:+94774778190"
            className="flex items-center justify-between p-3.5 bg-slate-50 hover:bg-slate-100 border border-slate-200/80 rounded-2xl transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-800 text-white flex items-center justify-center shadow-xs">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 block">{t.hotline}</span>
                <span className="text-xs text-slate-600 font-mono">{phoneNum}</span>
              </div>
            </div>
            <ExternalLink className="w-4 h-4 text-slate-400 group-hover:translate-x-0.5 transition-transform" />
          </a>

          {/* Location & Times */}
          <div className="p-3.5 bg-slate-50/60 rounded-2xl border border-slate-200/60 space-y-2 text-xs text-slate-600">
            <div className="flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold text-slate-800 block text-[11px] uppercase tracking-wider">{t.storeLocation}</span>
                <span>{t.storeAddress}</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 pt-1 border-t border-slate-200/50">
              <Clock className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                {isSi ? 'සෑම දිනකම: උදෑසන 7:30 - රාත්‍රී 9:30' : 'Daily: 7:30 AM - 9:30 PM'}
              </span>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl cursor-pointer"
        >
          {isSi ? 'වසන්න' : 'Close'}
        </button>
      </div>
    </div>
  );
};
