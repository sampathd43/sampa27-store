import React, { useState } from 'react';
import {
  X, MessageCircle, Lock, User, Phone, MapPin, CheckCircle2,
  AlertCircle, Sparkles, ArrowRight, ShieldCheck, KeyRound
} from 'lucide-react';
import { CustomerProfile, Language } from '../types';
import { UnifiedStore } from '../services/store';

interface CustomerAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onLoginSuccess: (customer: CustomerProfile) => void;
}

type AuthTab = 'whatsapp_otp' | 'username_pw' | 'register';

export const CustomerAuthModal: React.FC<CustomerAuthModalProps> = ({
  isOpen,
  onClose,
  lang,
  onLoginSuccess
}) => {
  const isSi = lang === 'si';

  const [activeTab, setActiveTab] = useState<AuthTab>('whatsapp_otp');

  // WhatsApp OTP state
  const [waPhone, setWaPhone] = useState('0771234567');
  const [waName, setWaName] = useState('Kasun Bandara');
  const [otpSent, setOtpSent] = useState(false);
  const [enteredOtp, setEnteredOtp] = useState('');
  const sampleOtp = '8342';

  // Username/Password state
  const [usernameInput, setUsernameInput] = useState('kasun');
  const [passwordInput, setPasswordInput] = useState('password123');

  // Register form state
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regUsername, setRegUsername] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regAddress, setRegAddress] = useState('');
  const [regCity, setRegCity] = useState('Maharagama');

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  // Handle WhatsApp OTP Request
  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (!waPhone.trim() || waPhone.trim().length < 9) {
      setErrorMsg(isSi ? 'වලංගු දුරකථන අංකයක් ඇතුළත් කරන්න.' : 'Please enter a valid phone number.');
      return;
    }
    setErrorMsg(null);
    setOtpSent(true);
    setEnteredOtp(sampleOtp); // Auto-fill sample OTP for convenient testing!
    setSuccessNotice(
      isSi
        ? `WhatsApp කේතය (OTP: ${sampleOtp}) ${waPhone} වෙත යවන ලදී!`
        : `WhatsApp OTP verification code (${sampleOtp}) sent to ${waPhone}!`
    );
  };

  // Handle WhatsApp OTP Verify
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const res = UnifiedStore.loginWithWhatsApp(waPhone, enteredOtp, waName);
    if (res.success && res.customer) {
      onLoginSuccess(res.customer);
      onClose();
    } else {
      setErrorMsg(res.error || 'Verification failed');
    }
  };

  // Handle Username / Password Login
  const handlePwLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    const res = UnifiedStore.loginWithUsernamePassword(usernameInput, passwordInput);
    if (res.success && res.customer) {
      onLoginSuccess(res.customer);
      onClose();
    } else {
      setErrorMsg(res.error || 'Login failed');
    }
  };

  // Handle Registration
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!regName.trim()) {
      setErrorMsg(isSi ? 'ඔබගේ සම්පූර්ණ නම ඇතුළත් කරන්න.' : 'Please enter your full name.');
      return;
    }
    if (!regPhone.trim() || regPhone.trim().length < 9) {
      setErrorMsg(isSi ? 'වලංගු දුරකථන අංකයක් ඇතුළත් කරන්න.' : 'Please enter a valid phone number.');
      return;
    }
    if (!regAddress.trim()) {
      setErrorMsg(isSi ? 'බඩු බෙදාහැරිය යුතු ලිපිනය ඇතුළත් කරන්න.' : 'Please enter your delivery street address.');
      return;
    }

    const res = UnifiedStore.registerCustomer({
      name: regName,
      phone: regPhone,
      username: regUsername || undefined,
      password: regPassword || 'password123',
      address: regAddress,
      city: regCity
    });

    if (res.success && res.customer) {
      onLoginSuccess(res.customer);
      onClose();
    } else {
      setErrorMsg(res.error || 'Registration failed');
    }
  };

  return (
    <div className="fixed inset-0 z-50 p-4 sm:p-6 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-100 relative max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <User className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {isSi ? 'පාරිභෝගික ගිණුමට පිවිසීම' : 'Customer Account Login'}
              </h2>
              <p className="text-[11px] text-slate-500">
                {isSi ? 'WhatsApp අංකයෙන් හෝ Username එකෙන් පිවිසෙන්න' : 'Log in with WhatsApp OTP or Username/Password'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-700 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="grid grid-cols-3 p-1.5 bg-slate-100 m-5 mb-0 rounded-2xl text-xs font-bold text-slate-600 gap-1">
          <button
            type="button"
            onClick={() => {
              setActiveTab('whatsapp_otp');
              setErrorMsg(null);
            }}
            className={`py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'whatsapp_otp'
                ? 'bg-white text-emerald-700 shadow-xs font-black'
                : 'hover:text-slate-900'
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5 text-[#25D366]" />
            <span>WhatsApp</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('username_pw');
              setErrorMsg(null);
            }}
            className={`py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'username_pw'
                ? 'bg-white text-emerald-700 shadow-xs font-black'
                : 'hover:text-slate-900'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>Password</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveTab('register');
              setErrorMsg(null);
            }}
            className={`py-2 rounded-xl transition-all cursor-pointer flex items-center justify-center gap-1.5 ${
              activeTab === 'register'
                ? 'bg-white text-emerald-700 shadow-xs font-black'
                : 'hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            <span>Register</span>
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4 overflow-y-auto text-xs">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successNotice && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2 font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successNotice}</span>
            </div>
          )}

          {/* TAB 1: WHATSAPP OTP LOGIN */}
          {activeTab === 'whatsapp_otp' && (
            <div className="space-y-4">
              {!otpSent ? (
                <form onSubmit={handleSendOtp} className="space-y-3">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      {isSi ? 'ඔබගේ WhatsApp අංකය' : 'Your WhatsApp Mobile Number'} *
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="tel"
                        required
                        value={waPhone}
                        onChange={(e) => setWaPhone(e.target.value)}
                        placeholder="077 123 4567"
                        className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none font-mono text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      {isSi ? 'නම (නව පාරිභෝගිකයෙකු නම්)' : 'Your Name (Optional)'}
                    </label>
                    <input
                      type="text"
                      value={waName}
                      onChange={(e) => setWaName(e.target.value)}
                      placeholder="Kasun Bandara"
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none text-xs"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-[#25D366] hover:bg-[#20ba5a] text-slate-950 font-black rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2 text-xs"
                  >
                    <MessageCircle className="w-4 h-4 fill-slate-950" />
                    <span>{isSi ? 'WhatsApp OTP කේතය ලබාගන්න' : 'Send WhatsApp OTP Code'}</span>
                  </button>
                </form>
              ) : (
                <form onSubmit={handleVerifyOtp} className="space-y-3">
                  <div>
                    <label className="block text-slate-700 font-semibold mb-1">
                      {isSi ? 'WhatsApp හරහා ලැබුණු 4-digit OTP කේතය ඇතුළත් කරන්න:' : 'Enter 4-digit OTP code received on WhatsApp:'}
                    </label>
                    <input
                      type="text"
                      maxLength={6}
                      required
                      value={enteredOtp}
                      onChange={(e) => setEnteredOtp(e.target.value)}
                      placeholder="8342"
                      className="w-full text-center tracking-[0.5em] py-3 text-lg font-black bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none text-slate-900"
                    />
                    <span className="text-[10px] text-emerald-700 block text-center mt-1 font-semibold">
                      {isSi ? 'පරීක්ෂා කිරීම සඳහා OTP කේතය ස්වයංක්‍රීයව පිරවී ඇත (8342).' : 'Demo OTP (8342) is pre-filled for instant testing.'}
                    </span>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2 text-xs"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>{isSi ? 'කේතය තහවුරු කර පිවිසෙන්න' : 'Verify & Log In'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setOtpSent(false)}
                    className="w-full text-center text-slate-500 hover:text-slate-800 text-[11px] underline"
                  >
                    {isSi ? 'වෙනත් අංකයක් ඇතුළත් කරන්න' : 'Change Phone Number'}
                  </button>
                </form>
              )}
            </div>
          )}

          {/* TAB 2: USERNAME / PASSWORD LOGIN */}
          {activeTab === 'username_pw' && (
            <form onSubmit={handlePwLogin} className="space-y-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  {isSi ? 'Username / දුරකථන අංකය' : 'Username or Mobile Number'} *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value)}
                    placeholder="kasun or 0771234567"
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  {isSi ? 'මුරපදය (Password)' : 'Password'} *
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none text-xs"
                  />
                </div>
                <span className="text-[10px] text-slate-500 mt-1 block">
                  Demo login: <strong className="text-slate-700">kasun</strong> / <strong className="text-slate-700">password123</strong>
                </span>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2 text-xs"
              >
                <KeyRound className="w-4 h-4" />
                <span>{isSi ? 'ගිණුමට පිවිසෙන්න' : 'Log In'}</span>
              </button>
            </form>
          )}

          {/* TAB 3: REGISTER NEW CUSTOMER */}
          {activeTab === 'register' && (
            <form onSubmit={handleRegister} className="space-y-3">
              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  {isSi ? 'සම්පූර්ණ නම' : 'Full Name'} *
                </label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="e.g. Kasun Bandara"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    {isSi ? 'WhatsApp අංකය' : 'WhatsApp Phone'} *
                  </label>
                  <input
                    type="tel"
                    required
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    placeholder="077 123 4567"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-semibold mb-1">
                    {isSi ? 'Username' : 'Username'}
                  </label>
                  <input
                    type="text"
                    value={regUsername}
                    onChange={(e) => setRegUsername(e.target.value)}
                    placeholder="kasun99"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  {isSi ? 'මුරපදය (Password)' : 'Password'} *
                </label>
                <input
                  type="password"
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  placeholder="password123"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  {isSi ? 'බඩු බෙදාහැරිය යුතු ලිපිනය (Delivery Address)' : 'Street Delivery Address'} *
                </label>
                <input
                  type="text"
                  required
                  value={regAddress}
                  onChange={(e) => setRegAddress(e.target.value)}
                  placeholder="No 45/A, Temple Road"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none text-xs"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-semibold mb-1">
                  {isSi ? 'නගරය' : 'City / Suburb'} *
                </label>
                <input
                  type="text"
                  required
                  value={regCity}
                  onChange={(e) => setRegCity(e.target.value)}
                  placeholder="Maharagama"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2 text-xs"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>{isSi ? 'ගිණුම සකසා පිවිසෙන්න (+100 Loyalty Points)' : 'Create Account (+100 Points)'}</span>
              </button>
            </form>
          )}

          {/* Benefits footer */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
            <span>🔒 Secure SMAPA 27 Account</span>
            <span className="text-emerald-700 font-semibold">🎁 Loyalty Points on Orders</span>
          </div>
        </div>
      </div>
    </div>
  );
};
