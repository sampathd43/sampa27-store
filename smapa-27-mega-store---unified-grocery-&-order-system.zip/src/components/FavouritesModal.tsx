import React from 'react';
import { X, Heart, ShoppingCart, Trash2 } from 'lucide-react';
import { Language, Product } from '../types';
import { TRANSLATIONS } from '../translations';
import { UnifiedStore } from '../services/store';

interface FavouritesModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onAddToCart: (product: Product, qty: number) => void;
  onViewDetails: (product: Product) => void;
}

export const FavouritesModal: React.FC<FavouritesModalProps> = ({
  isOpen,
  onClose,
  lang,
  onAddToCart,
  onViewDetails
}) => {
  if (!isOpen) return null;

  const t = TRANSLATIONS[lang];
  const isSi = lang === 'si';

  const favIds = UnifiedStore.getFavourites();
  const allProducts = UnifiedStore.getProducts();
  const favProducts = allProducts.filter((p) => favIds.includes(p.id));

  return (
    <div className="fixed inset-0 z-50 p-4 sm:p-6 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-xl w-full overflow-hidden shadow-2xl border border-slate-100 relative max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-rose-500 fill-rose-500" />
            <h2 className="text-base sm:text-lg font-bold text-slate-900">{t.favourites}</h2>
            <span className="text-xs text-slate-400">({favProducts.length})</span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white text-slate-400 hover:text-slate-700 shadow-xs flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1 space-y-3">
          {favProducts.length === 0 ? (
            <div className="text-center py-10 text-slate-400 space-y-2">
              <Heart className="w-10 h-10 mx-auto text-slate-200" />
              <p className="text-xs">
                {isSi ? 'ඔබ කැමති භාණ්ඩ කිසිවක් තවම එකතු කර නැත.' : 'You have not added any favourite products yet.'}
              </p>
            </div>
          ) : (
            favProducts.map((p) => (
              <div
                key={p.id}
                className="flex items-center gap-3 p-3 bg-white border border-slate-200/80 rounded-2xl hover:border-emerald-200 transition-colors shadow-xs"
              >
                <img
                  src={p.image}
                  alt={p.name}
                  onClick={() => onViewDetails(p)}
                  className="w-14 h-14 rounded-xl object-cover bg-slate-100 shrink-0 cursor-pointer"
                />

                <div className="flex-1 min-w-0">
                  <h4
                    onClick={() => onViewDetails(p)}
                    className="text-xs font-bold text-slate-900 truncate hover:text-emerald-700 cursor-pointer"
                  >
                    {isSi ? p.nameSi : p.name}
                  </h4>
                  <p className="text-[11px] text-slate-400">
                    {isSi ? p.unitSi : p.unit} • <span className="font-bold text-slate-700">Rs. {p.price.toLocaleString()}</span>
                  </p>
                  <span className={`text-[10px] font-semibold ${p.stock > 0 ? 'text-emerald-600' : 'text-rose-500'}`}>
                    {p.stock > 0 ? `${t.inStock}: ${p.stock}` : t.outOfStock}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    disabled={p.stock <= 0}
                    onClick={() => onAddToCart(p, 1)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors ${
                      p.stock > 0
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer shadow-xs'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    }`}
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{t.addToCart}</span>
                  </button>

                  <button
                    onClick={() => UnifiedStore.toggleFavourite(p.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                    title="Remove"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
