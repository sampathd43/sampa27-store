import React, { useState } from 'react';
import {
  X, Share2, Copy, Check, QrCode, MessageCircle, ExternalLink,
  Smartphone, ShieldCheck, Sparkles, Send
} from 'lucide-react';
import { Language } from '../types';

interface ShareStoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const ShareStoreModal: React.FC<ShareStoreModalProps> = ({
  isOpen,
  onClose,
  lang
}) => {
  const [copied, setCopied] = useState(false);
  const isSi = lang === 'si';

  if (!isOpen) return null;

  // The official shared app URL from metadata
  const publicStoreUrl = 'https://ais-pre-jht3vp43qcufigzir37jci-857870170231.asia-southeast1.run.app';

  const inviteMessageSi = `🛒 *ආයුබෝවන්! SMAPA 27 Mega Store වෙතින් නැවුම් බඩු ගෙදරටම ගෙන්වා ගන්න!*\n\n🌾 අරලිය කීරි සම්බා, රතු කැකුළු, පරිප්පු, සීනි, තේ කොළ, කිරිපිටි ඇතුළු සියලුම ගෘහස්ථ බඩු දැන් Online ඇණවුම් කළ හැක.\n\n🚚 පැය 2-4ක් ඇතුළත Same-Day Delivery!\n🎁 රු. 7,500ට වැඩි ඇණවුම් සඳහා *නොමිලේ බෙදාහැරීම* (Free Delivery)!\n\n👇 බඩු ඇණවුම් කිරීමට මෙම සබැඳිය ක්ලික් කරන්න:\n${publicStoreUrl}`;

  const inviteMessageEn = `🛒 *Welcome to SMAPA 27 Mega Store! Order your groceries online now!*\n\n🌾 Fresh Keeri Samba rice, Dhal, Sugar, Tea, Milk powder & Household essentials delivered to your doorstep.\n\n🚚 Same-Day Delivery within 2-4 Hours!\n🎁 Free Delivery on orders over Rs. 7,500!\n\n👇 Click the link below to start shopping:\n${publicStoreUrl}`;

  const shareText = isSi ? inviteMessageSi : inviteMessageEn;
  const whatsappShareUrl = `https://wa.me/?text=${encodeURIComponent(shareText)}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(publicStoreUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 p-4 sm:p-6 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100 relative max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-600 to-teal-600 text-white">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
              <Share2 className="w-4 h-4 text-white" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-bold">
                {isSi ? 'පාරිභෝගිකයින්ට කඩේ Link එක Share කිරීම' : 'Share Online Store with Customers'}
              </h2>
              <p className="text-[11px] text-emerald-100">
                {isSi ? 'WhatsApp හෝ Social Media හරහා සබැඳිය යවන්න' : 'Send store link via WhatsApp or QR Code'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 overflow-y-auto text-xs">
          {/* Public Link Box */}
          <div className="space-y-1.5">
            <label className="font-bold text-slate-700 block">
              {isSi ? 'පාරිභෝගිකයින් සඳහා වන නිල Live Link එක:' : 'Official Customer Public Web Store Link:'}
            </label>
            <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-2xl p-2.5">
              <input
                type="text"
                readOnly
                value={publicStoreUrl}
                className="flex-1 bg-transparent text-slate-800 font-mono text-[11px] outline-none"
              />
              <button
                onClick={handleCopy}
                className={`px-3 py-1.5 rounded-xl font-bold flex items-center gap-1.5 transition-all cursor-pointer ${
                  copied
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200'
                }`}
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? (isSi ? 'Copied!' : 'Copied!') : (isSi ? 'Copy' : 'Copy')}</span>
              </button>
            </div>
          </div>

          {/* 1-Click WhatsApp Share Button */}
          <a
            href={whatsappShareUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3.5 bg-[#25D366] hover:bg-[#20ba5a] text-slate-950 font-black rounded-2xl shadow-lg shadow-emerald-500/10 flex items-center justify-center gap-2.5 transition-transform active:scale-[0.98] text-sm"
          >
            <MessageCircle className="w-5 h-5 fill-slate-950" />
            <span>{isSi ? 'WhatsApp හරහා පාරිභෝගිකයින්ට Share කරන්න' : 'Share Directly on WhatsApp'}</span>
          </a>

          {/* QR Code and In-Store Walk-in Scanner */}
          <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
            <div className="w-24 h-24 bg-white p-2 rounded-xl border border-slate-200 shadow-xs shrink-0 flex flex-col items-center justify-center">
              <QrCode className="w-16 h-16 text-slate-800" />
              <span className="text-[8px] font-mono text-slate-400 mt-0.5">SCAN STORE</span>
            </div>
            <div className="space-y-1">
              <h4 className="font-bold text-slate-900 text-xs flex items-center justify-center sm:justify-start gap-1">
                <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                <span>{isSi ? 'කඩේට එන පාරිභෝගිකයින් සඳහා QR Code' : 'In-Store QR Code for Walk-in Customers'}</span>
              </h4>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                {isSi
                  ? 'කවුන්ටරයේ මෙම QR එක ප්‍රදර්ශනය කළ හැක. පාරිභෝගිකයින්ට තම දුරකථන කැමරාවෙන් ස්කෑන් කර සැනින් ඇණවුම් කළ හැක.'
                  : 'Display this QR code at your shop counter. Customers can scan with their phone camera to order anytime.'}
              </p>
            </div>
          </div>

          {/* How customers login and order guide */}
          <div className="space-y-2 pt-1 border-t border-slate-100">
            <h4 className="font-bold text-slate-900 text-xs">
              {isSi ? 'පාරිභෝගිකයා Login වී බඩු ඇණවුම් කරන අන්දම:' : 'How Customers Log In & Order:'}
            </h4>
            <div className="space-y-1.5 text-[11px] text-slate-600">
              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold shrink-0 text-[10px]">
                  1
                </span>
                <span>
                  <strong>WhatsApp OTP Login:</strong> {isSi ? 'පාරිභෝගිකයා තම WhatsApp අංකය ඇතුළත් කර 4-digit කේතය (OTP) ලබාගෙන තත්පර 5න් Log in වේ.' : 'Customer enters their mobile number and logs in with an instant 4-digit OTP.'}
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold shrink-0 text-[10px]">
                  2
                </span>
                <span>
                  <strong>Username & Password:</strong> {isSi ? 'හෝ තමන්ගේම Username සහ Password එකකින් Register වී Account එක පවත්වාගත හැක.' : 'Or register with their own custom username and password.'}
                </span>
              </div>
              <div className="flex items-start gap-2">
                <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold shrink-0 text-[10px]">
                  3
                </span>
                <span>
                  <strong>Saved Address & Loyalty:</strong> {isSi ? 'එක් වරක් ලිපිනය ඇතුළත් කළ පසු, ඊළඟ වතාවලදී ස්වයංක්‍රීයව පිරවේ. සෑම ඇණවුමකටම Loyalty Points හිමිවේ.' : 'Delivery address is saved for 1-click repeat orders, plus loyalty points are earned!'}
                </span>
              </div>
            </div>
          </div>

          {/* Close action */}
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold cursor-pointer transition-colors"
          >
            {isSi ? 'හරි, වැසීම' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
};
