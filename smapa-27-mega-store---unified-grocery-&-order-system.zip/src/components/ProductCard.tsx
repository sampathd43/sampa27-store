import React from 'react';
import { Heart, Plus, Minus, ShoppingCart, AlertCircle, CheckCircle2, Eye } from 'lucide-react';
import { Language, Product } from '../types';
import { TRANSLATIONS } from '../translations';

interface ProductCardProps {
  product: Product;
  lang: Language;
  cartQuantity: number;
  isFavourite: boolean;
  onAddToCart: (product: Product, qty: number) => void;
  onUpdateCartQty: (productId: string, qty: number) => void;
  onToggleFav: (productId: string) => void;
  onViewDetails: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  lang,
  cartQuantity,
  isFavourite,
  onAddToCart,
  onUpdateCartQty,
  onToggleFav,
  onViewDetails
}) => {
  const t = TRANSLATIONS[lang];
  const isSi = lang === 'si';

  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= product.minStockAlert;
  const hasDiscount = Boolean(product.originalPrice && product.originalPrice > product.price);
  const discountPercent = hasDiscount
    ? Math.round(((product.originalPrice! - product.price) / product.originalPrice!) * 100)
    : 0;
  const saveAmount = hasDiscount ? product.originalPrice! - product.price : 0;

  return (
    <div className="group bg-white rounded-2xl border border-slate-200/80 hover:border-emerald-300 shadow-xs hover:shadow-lg hover:shadow-emerald-500/10 transition-all duration-200 flex flex-col overflow-hidden relative">
      {/* Top Overlays: Reduced Price Badge & Favourite */}
      <div className="absolute top-2.5 inset-x-2.5 z-20 flex items-start justify-between pointer-events-none gap-2">
        {/* Top-Left Corner: Big, Eye-Catching Reduced Price Badge (Direct Rupee Savings) */}
        {hasDiscount ? (
          <div className="pointer-events-auto">
            <span className="inline-flex items-center gap-1.5 bg-gradient-to-r from-rose-600 via-red-600 to-amber-500 text-white font-black text-xs sm:text-sm px-2.5 sm:px-3 py-1 rounded-xl shadow-lg shadow-rose-600/30 border border-white/30 tracking-tight transform group-hover:scale-105 transition-transform animate-in fade-in zoom-in-95 duration-200">
              <span className="text-sm">🔥</span>
              <span>{isSi ? `රු. ${saveAmount}ක් අඩුයි!` : `SAVE Rs. ${saveAmount}`}</span>
            </span>
          </div>
        ) : isOutOfStock ? (
          <span className="inline-flex items-center gap-1 bg-rose-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs pointer-events-auto">
            <AlertCircle className="w-3 h-3" />
            {t.outOfStock}
          </span>
        ) : isLowStock ? (
          <span className="inline-flex items-center gap-1 bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs pointer-events-auto animate-pulse">
            <AlertCircle className="w-3 h-3" />
            {t.lowStock}: {product.stock} {t.left}
          </span>
        ) : (
          <div />
        )}

        {/* Top-Right Corner: Favourite Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFav(product.id);
          }}
          className="p-1.5 rounded-full bg-white/95 hover:bg-white text-slate-400 hover:text-rose-500 shadow-md transition-transform active:scale-90 pointer-events-auto cursor-pointer border border-slate-100"
          title={isFavourite ? 'Remove from favourites' : 'Add to favourites'}
        >
          <Heart className={`w-4 h-4 ${isFavourite ? 'fill-rose-500 text-rose-500' : ''}`} />
        </button>
      </div>

      {/* Product Image */}
      <div
        onClick={() => onViewDetails(product)}
        className="w-full h-44 sm:h-48 overflow-hidden bg-slate-100 relative cursor-pointer group-hover:opacity-95 transition-opacity"
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />

        {/* Stock pill at bottom-left of image */}
        <div className="absolute bottom-2.5 left-2.5 z-10">
          {isOutOfStock && hasDiscount ? (
            <span className="inline-flex items-center gap-1 bg-rose-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs">
              <AlertCircle className="w-3 h-3" />
              {t.outOfStock}
            </span>
          ) : isLowStock && hasDiscount ? (
            <span className="inline-flex items-center gap-1 bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-xs animate-pulse">
              <AlertCircle className="w-3 h-3" />
              {t.lowStock}: {product.stock} {t.left}
            </span>
          ) : (
            <span className="inline-flex items-center gap-1 bg-slate-900/80 backdrop-blur-xs text-white text-[10px] font-semibold px-2 py-0.5 rounded-full shadow-xs">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              {product.stock} {t.left}
            </span>
          )}
        </div>

        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
          <span className="opacity-0 group-hover:opacity-100 bg-white/90 text-slate-800 text-[11px] font-semibold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1 transition-opacity">
            <Eye className="w-3 h-3 text-emerald-600" />
            {isSi ? 'විස්තර' : 'Quick View'}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
        <div>
          {/* Brand & Unit */}
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-medium mb-1">
            <span className="uppercase tracking-wider font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
              {product.brand}
            </span>
            <span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-medium">
              {isSi ? product.unitSi : product.unit}
            </span>
          </div>

          {/* Title */}
          <h3
            onClick={() => onViewDetails(product)}
            className="text-sm font-bold text-slate-900 line-clamp-2 hover:text-emerald-700 cursor-pointer transition-colors"
            title={isSi ? product.nameSi : product.name}
          >
            {isSi ? product.nameSi : product.name}
          </h3>

          {/* Secondary language title preview for clarity */}
          <p className="text-[11px] text-slate-400 truncate mt-0.5">
            {isSi ? product.name : product.nameSi}
          </p>
        </div>

        {/* Pricing & Add to Cart button */}
        <div className="pt-2 border-t border-slate-100">
          <div className="flex items-start justify-between mb-2">
            <div>
              {/* Strikethrough Original Price & Direct Rupee Discount */}
              {hasDiscount && (
                <div className="flex items-center gap-1.5 leading-none mb-0.5">
                  <span className="text-xs text-slate-400 line-through font-semibold">
                    Rs. {product.originalPrice?.toLocaleString()}
                  </span>
                  <span className="text-[10px] font-black text-rose-600 bg-rose-50 border border-rose-200 px-1.5 py-0.2 rounded">
                    -Rs. {saveAmount} {isSi ? 'අඩුයි' : 'OFF'}
                  </span>
                </div>
              )}
              <div className="flex items-baseline gap-1">
                <span className="text-xs text-emerald-600 font-bold">Rs. </span>
                <span className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                  {product.price.toLocaleString()}
                </span>
              </div>
              {hasDiscount && (
                <p className="text-[11px] font-bold text-emerald-600 leading-tight mt-0.5">
                  {isSi ? `රු. ${saveAmount}ක් ඉතිරි වේ!` : `Save Rs. ${saveAmount}!`}
                </p>
              )}
            </div>

            {product.wholesalePrice && (
              <div className="text-right" title="Wholesale discount price">
                <span className="text-[10px] text-slate-400 block leading-none">{t.wholesaleDiscount}</span>
                <span className="text-xs font-bold text-emerald-700">
                  Rs. {product.wholesalePrice.toLocaleString()}
                </span>
                <span className="text-[9px] text-emerald-600/80 block leading-none mt-0.5">
                  ({product.wholesaleMinQty}+ {isSi ? 'ගන්නා විට' : 'qty'})
                </span>
              </div>
            )}
          </div>

          {/* Action: Add to cart or quantity stepper */}
          {isOutOfStock ? (
            <button
              disabled
              className="w-full py-2 bg-slate-100 text-slate-400 text-xs font-semibold rounded-xl cursor-not-allowed text-center"
            >
              {t.outOfStock}
            </button>
          ) : cartQuantity > 0 ? (
            <div className="flex items-center justify-between bg-emerald-50 border border-emerald-300 rounded-xl p-1">
              <button
                onClick={() => onUpdateCartQty(product.id, cartQuantity - 1)}
                className="w-7 h-7 flex items-center justify-center rounded-lg bg-white text-emerald-800 shadow-xs hover:bg-emerald-100 cursor-pointer transition-colors"
                title="Decrease"
              >
                <Minus className="w-3.5 h-3.5" />
              </button>
              <span className="text-xs font-bold text-emerald-950 px-2">
                {cartQuantity} in cart
              </span>
              <button
                onClick={() => onUpdateCartQty(product.id, cartQuantity + 1)}
                disabled={cartQuantity >= product.stock}
                className={`w-7 h-7 flex items-center justify-center rounded-lg bg-emerald-600 text-white shadow-xs transition-colors ${
                  cartQuantity >= product.stock
                    ? 'opacity-40 cursor-not-allowed'
                    : 'hover:bg-emerald-700 cursor-pointer'
                }`}
                title={cartQuantity >= product.stock ? 'Max stock reached' : 'Increase'}
              >
                <Plus className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => onAddToCart(product, 1)}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs shadow-emerald-600/20 flex items-center justify-center gap-1.5 transition-all active:scale-[0.98] cursor-pointer"
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span>{t.addToCart}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
