import React from 'react';
import {
  ShoppingCart, Heart, Package, Store, ArrowRightLeft, Search, PhoneCall,
  ShieldCheck, Bell, User, Share2, LogOut, Sparkles
} from 'lucide-react';
import { CustomerProfile, Language } from '../types';
import { TRANSLATIONS } from '../translations';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  isAdminMode: boolean;
  onToggleAdmin: () => void;
  cartCount: number;
  cartTotal: number;
  favCount: number;
  onOpenCart: () => void;
  onOpenFavs: () => void;
  onOpenTracker: () => void;
  onOpenContact: () => void;
  onOpenStep7?: () => void;
  onOpenShareStore?: () => void;
  onOpenAuth?: () => void;
  currentCustomer?: CustomerProfile | null;
  onLogoutCustomer?: () => void;
  searchTerm: string;
  onSearchChange: (val: string) => void;
  lowStockCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  isAdminMode,
  onToggleAdmin,
  cartCount,
  cartTotal,
  favCount,
  onOpenCart,
  onOpenFavs,
  onOpenTracker,
  onOpenContact,
  onOpenStep7,
  onOpenShareStore,
  onOpenAuth,
  currentCustomer,
  onLogoutCustomer,
  searchTerm,
  onSearchChange,
  lowStockCount,
}) => {
  const t = TRANSLATIONS[lang];

  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800 shadow-2xl text-slate-100">
      {/* Top micro bar: Omnichannel Live Badge & Hotlines */}
      <div className="bg-slate-900 border-b border-slate-800/80 text-white text-xs px-4 py-1.5 flex flex-wrap justify-between items-center gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-flex items-center gap-1.5 bg-emerald-950/80 text-emerald-300 px-2.5 py-0.5 rounded-full font-medium tracking-wide border border-emerald-800/60">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            {t.storeOmniBadge}
          </span>
          <span className="hidden md:inline text-slate-600">|</span>
          <span className="hidden md:inline text-slate-300">
            {lang === 'si' ? 'මහරගම, කොළඹ හා තදාසන්න ප්‍රදේශ සඳහා එදිනම ඩිලිවරි' : 'Same-day delivery across Colombo & suburbs'}
          </span>
        </div>

        <div className="flex items-center gap-3 sm:gap-4 flex-wrap">
          <button
            onClick={onOpenShareStore}
            className="flex items-center gap-1.5 bg-[#25D366]/20 hover:bg-[#25D366]/30 text-[#25D366] px-2.5 py-0.5 rounded-full font-bold border border-[#25D366]/40 cursor-pointer transition-colors text-[11px]"
            title="Share Store Link & QR Code with Customers"
          >
            <Share2 className="w-3 h-3" />
            <span>{lang === 'si' ? 'කඩේ Link එක Share කරන්න' : 'Share Store Link'}</span>
          </button>

          <button
            onClick={onOpenContact}
            className="flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
            <span>077 477 8190 / WhatsApp</span>
          </button>

          <button
            onClick={onToggleLang}
            className="flex items-center gap-1 bg-slate-800 hover:bg-slate-700 px-2 py-0.5 rounded text-white font-medium border border-slate-700 cursor-pointer transition-colors"
            title="Switch Language / භාෂාව මාරු කරන්න"
          >
            <span>{lang === 'en' ? '🇱🇰 සිංහල' : '🇬🇧 English'}</span>
          </button>
        </div>
      </div>

      {/* Main navigation row */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex items-center justify-between gap-3 md:gap-6">
          {/* Logo with White 'SMAPA' and Green '27' as requested */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-emerald-500/20">
              <Store className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl md:text-2xl font-black tracking-tight">
                  <span className="text-white">SMAPA </span>
                  <span className="text-emerald-400">27</span>
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 hidden sm:inline-block">
                  MEGA STORE
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium hidden sm:block leading-none mt-0.5">
                {t.storeTagline}
              </p>
            </div>
          </div>

          {/* Search bar */}
          <div className="flex-1 max-w-xl hidden md:block">
            <div className="relative">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder={t.searchPlaceholder}
                className="w-full pl-10 pr-4 py-2 bg-slate-900 hover:bg-slate-850 focus:bg-slate-900 text-sm rounded-xl border border-slate-750 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all outline-none text-white placeholder-slate-400"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              {searchTerm && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* View Switcher: Customer vs Admin / POS */}
            <button
              onClick={onToggleAdmin}
              className={`flex items-center gap-1.5 px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl text-xs font-bold transition-all border cursor-pointer shadow-md ${
                isAdminMode
                  ? 'bg-emerald-600 text-white border-emerald-400 shadow-emerald-600/30 ring-2 ring-emerald-400'
                  : 'bg-emerald-950/80 text-emerald-300 border-emerald-600 hover:bg-emerald-900 hover:text-white'
              }`}
              title="Open Store Admin Dashboard & POS / කඩේ පාලක පුවරුව"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="hidden sm:inline">
                {isAdminMode ? '🛒 Customer Shop' : '🛡️ Store Admin / පාලක පුවරුව'}
              </span>
              <span className="sm:hidden">
                {isAdminMode ? 'Shop' : 'Admin'}
              </span>
              {lowStockCount > 0 && !isAdminMode && (
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" title="Low stock alerts" />
              )}
            </button>

            {/* Step 7 Direct Button */}
            <button
              onClick={onOpenStep7}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all border cursor-pointer bg-amber-950/80 text-amber-300 border-amber-800/80 hover:bg-amber-900/60 shadow-xs active:scale-95"
              title="Open STEP 7: WhatsApp & SMS Order Notifications"
            >
              <Bell className="w-3.5 h-3.5 text-amber-400 animate-bounce" />
              <span className="hidden sm:inline">🔔 Step 7: SMS/WA</span>
              <span className="sm:hidden">Step 7</span>
            </button>

            {/* Track Orders */}
            <button
              onClick={onOpenTracker}
              className="flex items-center gap-1.5 px-3 py-1.5 text-slate-300 hover:text-white hover:bg-slate-900 rounded-xl text-xs font-medium transition-colors cursor-pointer border border-transparent hover:border-slate-800"
            >
              <Package className="w-4 h-4 text-slate-400" />
              <span className="hidden lg:inline">{t.trackOrder}</span>
            </button>

            {/* Favourites */}
            <button
              onClick={onOpenFavs}
              className="relative p-2 text-slate-300 hover:text-rose-400 hover:bg-slate-900 rounded-xl transition-colors cursor-pointer border border-transparent hover:border-slate-800"
              title={t.favourites}
            >
              <Heart className={`w-5 h-5 ${favCount > 0 ? 'fill-rose-500 text-rose-500' : 'text-slate-400'}`} />
              {favCount > 0 && (
                <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                  {favCount}
                </span>
              )}
            </button>

            {/* Customer Account / Login Widget */}
            {currentCustomer ? (
              <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-750 px-2.5 py-1.5 rounded-xl text-xs">
                <div className="flex items-center gap-1 text-white font-bold">
                  <User className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="max-w-[70px] sm:max-w-[90px] truncate">{currentCustomer.name}</span>
                </div>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 font-extrabold px-1.5 py-0.2 rounded-full hidden sm:inline">
                  🪙 {currentCustomer.loyaltyPoints}
                </span>
                <button
                  onClick={onLogoutCustomer}
                  className="text-slate-400 hover:text-rose-400 ml-0.5 p-0.5 cursor-pointer"
                  title={lang === 'si' ? 'ගිණුමෙන් ඉවත් වන්න (Logout)' : 'Logout'}
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-850 text-slate-200 hover:text-white border border-slate-750 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs active:scale-95"
                title="Customer Login with WhatsApp or Password"
              >
                <User className="w-3.5 h-3.5 text-emerald-400" />
                <span>{lang === 'si' ? 'Login' : 'Sign In'}</span>
              </button>
            )}

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-3.5 py-2 rounded-xl shadow-lg shadow-emerald-500/25 text-xs font-semibold transition-all cursor-pointer transform active:scale-95"
            >
              <div className="relative">
                <ShoppingCart className="w-4 h-4" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-amber-400 text-slate-950 font-extrabold text-[10px] w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-slate-950">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="hidden sm:inline font-bold">
                {cartTotal > 0 ? `Rs. ${cartTotal.toLocaleString()}` : t.cart}
              </span>
            </button>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="mt-3 md:hidden">
          <div className="relative">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder={t.searchPlaceholder}
              className="w-full pl-9 pr-4 py-2 bg-slate-900 text-sm rounded-xl border border-slate-750 focus:border-emerald-500 outline-none text-white placeholder-slate-400"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            {searchTerm && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
