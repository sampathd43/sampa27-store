import React, { useState } from 'react';
import { X, ShoppingCart, CheckCircle2, AlertCircle, Heart, Shield, RefreshCw } from 'lucide-react';
import { Language, Product } from '../types';
import { TRANSLATIONS } from '../translations';

interface ProductDetailsModalProps {
  product: Product | null;
  lang: Language;
  onClose: () => void;
  onAddToCart: (product: Product, qty: number) => void;
  isFavourite: boolean;
  onToggleFav: (productId: string) => void;
}

export const ProductDetailsModal: React.FC<ProductDetailsModalProps> = ({
  product,
  lang,
  onClose,
  onAddToCart,
  isFavourite,
  onToggleFav
}) => {
  const [quantity, setQuantity] = useState(1);

  if (!product) return null;

  const t = TRANSLATIONS[lang];
  const isSi = lang === 'si';

  const isOutOfStock = product.stock <= 0;
  const isLowStock = product.stock > 0 && product.stock <= product.minStockAlert;

  const handleAdd = () => {
    if (quantity > product.stock) return;
    onAddToCart(product, quantity);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 relative max-h-[90vh] flex flex-col">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-slate-500 hover:text-slate-800 shadow-md flex items-center justify-center cursor-pointer transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="overflow-y-auto p-6 sm:p-8 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-start">
            {/* Image */}
            <div className="rounded-2xl overflow-hidden bg-slate-100 aspect-square relative border border-slate-200/80">
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => onToggleFav(product.id)}
                className="absolute bottom-3 right-3 p-2.5 rounded-full bg-white/95 text-slate-500 hover:text-rose-500 shadow-md transition-colors"
              >
                <Heart className={`w-5 h-5 ${isFavourite ? 'fill-rose-500 text-rose-500' : ''}`} />
              </button>
            </div>

            {/* Product Meta */}
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="text-xs font-bold text-emerald-800 uppercase bg-emerald-100/80 px-2 py-0.5 rounded-md">
                    {product.brand}
                  </span>
                  <span className="text-xs text-slate-500 font-medium bg-slate-100 px-2 py-0.5 rounded-md">
                    {isSi ? product.unitSi : product.unit}
                  </span>
                </div>

                <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug">
                  {isSi ? product.nameSi : product.name}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isSi ? product.name : product.nameSi}
                </p>
              </div>

              {/* Price */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1.5">
                {product.originalPrice && product.originalPrice > product.price && (
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm text-slate-400 line-through font-semibold">
                      Rs. {product.originalPrice.toLocaleString()}
                    </span>
                    <span className="text-xs font-black bg-gradient-to-r from-rose-600 to-amber-500 text-white px-2.5 py-0.5 rounded-full shadow-xs">
                      🔥 {isSi ? `රු. ${(product.originalPrice - product.price).toLocaleString()}ක් අඩුයි!` : `SAVE Rs. ${(product.originalPrice - product.price).toLocaleString()}`}
                    </span>
                  </div>
                )}

                <div className="flex items-baseline gap-2">
                  <span className="text-sm font-semibold text-emerald-600">Rs.</span>
                  <span className="text-3xl font-black text-slate-950">
                    {product.price.toLocaleString()}
                  </span>
                  <span className="text-xs text-slate-500">/ {isSi ? product.unitSi : product.unit}</span>
                </div>

                {product.wholesalePrice && (
                  <p className="text-xs text-emerald-700 font-bold flex items-center gap-1.5 pt-1 border-t border-slate-200/60">
                    <span className="bg-emerald-600 text-white font-extrabold px-1.5 py-0.5 rounded text-[10px]">
                      {t.wholesaleDiscount}
                    </span>
                    <span>Rs. {product.wholesalePrice.toLocaleString()}</span>
                    <span className="text-slate-500 font-normal">
                      {isSi
                        ? `(${product.wholesaleMinQty}කට වඩා ගන්නා විට එකකට රු. ${product.price - product.wholesalePrice}ක් අමතර ලාභයි)`
                        : `(Buy ${product.wholesaleMinQty}+ units, save extra Rs. ${product.price - product.wholesalePrice} each)`}
                    </span>
                  </p>
                )}
              </div>

              {/* Live stock indicator */}
              <div className="flex items-center gap-2 text-xs">
                {isOutOfStock ? (
                  <div className="flex items-center gap-1.5 text-rose-600 font-semibold bg-rose-50 px-3 py-1.5 rounded-xl border border-rose-200">
                    <AlertCircle className="w-4 h-4" />
                    <span>{t.outOfStock}</span>
                  </div>
                ) : isLowStock ? (
                  <div className="flex items-center gap-1.5 text-amber-700 font-semibold bg-amber-50 px-3 py-1.5 rounded-xl border border-amber-200">
                    <AlertCircle className="w-4 h-4 text-amber-500" />
                    <span>{t.lowStock}: {product.stock} {isSi ? 'ක් පමණක් ඉතිරියි' : 'items remaining'}</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 text-emerald-800 font-semibold bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>{t.inStock}: {product.stock} {isSi ? 'ක් සූදානම්ව ඇත' : 'available right now'}</span>
                  </div>
                )}
              </div>

              {/* Quantity selector and Add */}
              {!isOutOfStock && (
                <div className="space-y-3 pt-2">
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-semibold text-slate-600">
                      {isSi ? 'ප්‍රමාණය:' : 'Quantity:'}
                    </span>
                    <div className="flex items-center border border-slate-200 rounded-xl overflow-hidden bg-white">
                      <button
                        onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                        className="px-3 py-1.5 hover:bg-slate-100 text-slate-700 font-bold transition-colors cursor-pointer"
                      >
                        -
                      </button>
                      <span className="px-3 py-1.5 text-sm font-bold text-slate-900 min-w-[2.5rem] text-center">
                        {quantity}
                      </span>
                      <button
                        onClick={() => setQuantity((q) => Math.min(product.stock, q + 1))}
                        disabled={quantity >= product.stock}
                        className={`px-3 py-1.5 text-slate-700 font-bold transition-colors ${
                          quantity >= product.stock ? 'opacity-40 cursor-not-allowed' : 'hover:bg-slate-100 cursor-pointer'
                        }`}
                      >
                        +
                      </button>
                    </div>
                    <span className="text-xs text-slate-400">
                      (Total: Rs. {(product.price * quantity).toLocaleString()})
                    </span>
                  </div>

                  <button
                    onClick={handleAdd}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.99]"
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>{t.addToCart}</span>
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Description */}
          <div className="border-t border-slate-100 pt-4 space-y-2">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
              {isSi ? 'විස්තර සහ ගුණාංග' : 'Product Information'}
            </h4>
            <p className="text-sm text-slate-600 leading-relaxed">
              {isSi ? product.descriptionSi : product.description}
            </p>
          </div>

          {/* Omnichannel sync assurance note */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3.5 flex items-start gap-3 text-xs text-slate-600">
            <RefreshCw className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-slate-800">
                {isSi ? 'සජීවී තොග ආරක්ෂණය:' : 'Unified Stock Protection:'}
              </span>{' '}
              {isSi
                ? 'කඩේ කවුන්ටරයෙන් හෝ වෙබ් එකෙන් විකුණන සැණින් තොගය එකවරම යාවත්කාලීන වේ. භාණ්ඩ නොමැතිව ඇණවුම් ගැනීමේ අපහසුතා ඇති නොවේ.'
                : 'Stock changes are deducted across the physical counter register and online store in real-time, preventing out-of-stock discrepancies.'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
