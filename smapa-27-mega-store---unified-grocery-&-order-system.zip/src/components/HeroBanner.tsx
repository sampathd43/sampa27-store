import React from 'react';
import { Truck, ShieldCheck, Zap, Sparkles, MessageCircle, RefreshCw } from 'lucide-react';
import { Category, Language } from '../types';

interface HeroBannerProps {
  lang: Language;
  categories: Category[];
  selectedCategory: string;
  onSelectCategory: (id: string) => void;
  onOpenQuickDemo?: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  lang,
  categories,
  selectedCategory,
  onSelectCategory,
  onOpenQuickDemo
}) => {
  const isSi = lang === 'si';

  return (
    <div className="bg-gradient-to-b from-emerald-50/70 via-teal-50/40 to-white pb-6 pt-5 border-b border-emerald-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Main Banner Hero */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-900 via-emerald-800 to-teal-900 text-white shadow-xl">
          {/* Subtle decorative circles */}
          <div className="absolute -right-20 -top-20 w-80 h-80 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none" />
          <div className="absolute -left-20 -bottom-20 w-80 h-80 rounded-full bg-teal-400/10 blur-3xl pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 p-6 sm:p-8 lg:p-10 items-center">
            <div className="lg:col-span-7 space-y-4">
              <div className="inline-flex items-center gap-2 bg-emerald-700/50 backdrop-blur-xs border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-semibold text-emerald-200">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>{isSi ? 'නැවුම් සිල්ලර බඩු එදිනම ඔබේ දොරකඩට' : 'Fresh Groceries Delivered Same-Day'}</span>
              </div>

              <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
                {isSi ? (
                  <>
                    කඩේ බඩු ලිස්ට් එක <br />
                    <span className="text-amber-300">වෙබ් එකෙන් පහසුවෙන්</span> ගෙදරටම!
                  </>
                ) : (
                  <>
                    Order Daily Groceries <br />
                    <span className="text-amber-300">Fast, Fresh & Reliable</span> to Your Doorstep
                  </>
                )}
              </h1>

              <p className="text-emerald-100/90 text-sm sm:text-base max-w-xl font-normal leading-relaxed">
                {isSi
                  ? 'කීරි සම්බා, රතු කැකුළු, පරිප්පු, සීනි, කිරිපිටි, තෙල් සහ නැවුම් එළවළු. භාණ්ඩ ලැබුණු පසු මුදල් ගෙවන්න (Cash on Delivery).'
                  : 'Keeri Samba, Dhal, Sugar, Tea, Dairy & Fresh Vegetables. Cash on Delivery and Wholesale savings available.'}
              </p>

              {/* Value highlights */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2">
                <div className="flex items-center gap-2 text-xs text-emerald-100 font-medium bg-emerald-950/40 px-3 py-2 rounded-xl border border-emerald-700/40">
                  <Truck className="w-4 h-4 text-amber-300 shrink-0" />
                  <span>{isSi ? 'අධිවේගී ඩිලිවරි' : 'Fast Delivery'}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-emerald-100 font-medium bg-emerald-950/40 px-3 py-2 rounded-xl border border-emerald-700/40">
                  <ShieldCheck className="w-4 h-4 text-emerald-300 shrink-0" />
                  <span>{isSi ? 'Cash on Delivery' : 'Cash on Delivery'}</span>
                </div>
                <div className="col-span-2 sm:col-span-1 flex items-center gap-2 text-xs text-emerald-100 font-medium bg-emerald-950/40 px-3 py-2 rounded-xl border border-emerald-700/40">
                  <Zap className="w-4 h-4 text-amber-300 shrink-0" />
                  <span>{isSi ? 'තොග මිල වාසි' : 'Wholesale Prices'}</span>
                </div>
              </div>
            </div>

            {/* Right Omnichannel Box Demonstration */}
            <div className="lg:col-span-5 bg-white/10 backdrop-blur-md border border-white/15 rounded-xl p-5 text-white shadow-inner">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <RefreshCw className="w-4 h-4 text-amber-300 animate-spin" style={{ animationDuration: '6s' }} />
                  <span className="font-bold text-xs uppercase tracking-wider text-amber-200">
                    {isSi ? 'Omnichannel සජීවී තොගය' : 'Omnichannel Unified Stock'}
                  </span>
                </div>
                <span className="text-[10px] bg-emerald-500/30 text-emerald-200 px-2 py-0.5 rounded-full font-mono">
                  Shop ↔ Web
                </span>
              </div>

              <div className="space-y-3 mt-3 text-xs text-emerald-100">
                <p className="leading-snug">
                  {isSi ? (
                    <>
                      <strong className="text-white">Shop එකේ customer කෙනෙක් Rice 5kg එකක් ගත්තා →</strong> තොගය 20 සිට 19 දක්වා අඩු වේ. වෙබ් අඩවියෙන් හා ඇප් එකෙන් එය ක්ෂණිකව යාවත්කාලීන වේ!
                    </>
                  ) : (
                    <>
                      <strong className="text-white">Customer buys Rice 5kg in shop →</strong> stock instantly drops from 20 to 19 across Online Shop, Counter POS & App!
                    </>
                  )}
                </p>

                <div className="bg-emerald-950/60 p-2.5 rounded-lg border border-emerald-600/30 text-[11px] font-mono flex items-center justify-between">
                  <span className="text-emerald-300">Araliya Keeri Samba (5kg)</span>
                  <span className="text-amber-300 font-bold">Auto-Sync ⚡</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Category Horizontal Filter Chips */}
        <div className="mt-6">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none pt-1">
            {categories.map((cat) => {
              const isSelected = selectedCategory === cat.id;
              const isDeals = cat.id === 'deals';
              return (
                <button
                  key={cat.id}
                  onClick={() => onSelectCategory(cat.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${
                    isSelected
                      ? isDeals
                        ? 'bg-rose-600 text-white border-rose-600 shadow-md shadow-rose-600/30 scale-[1.03]'
                        : 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-600/20 scale-[1.02]'
                      : isDeals
                      ? 'bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100 hover:border-rose-300'
                      : 'bg-white text-slate-700 border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/50'
                  }`}
                >
                  {cat.icon && <span className="text-sm">{cat.icon}</span>}
                  <span>{isSi ? cat.nameSi : cat.name}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
