import React, { useState } from 'react';
import { X, Search, Package, Clock, CheckCircle2, Truck, RefreshCw, ShoppingCart, AlertCircle, Printer } from 'lucide-react';
import { Language, Order, OrderStatus } from '../types';
import { TRANSLATIONS, getStatusBadge } from '../translations';
import { UnifiedStore } from '../services/store';

interface OrderTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  initialOrderNumber?: string;
  onReorderSuccess: () => void;
  onPayNow?: (order: Order) => void;
}

export const OrderTrackerModal: React.FC<OrderTrackerModalProps> = ({
  isOpen,
  onClose,
  lang,
  initialOrderNumber = '',
  onReorderSuccess,
  onPayNow
}) => {
  const [query, setQuery] = useState(initialOrderNumber);
  const [reorderMsg, setReorderMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const t = TRANSLATIONS[lang];
  const isSi = lang === 'si';

  const allOrders = UnifiedStore.getOrders();

  // Find matching order
  const activeOrder = query.trim()
    ? allOrders.find(
        (o) =>
          o.orderNumber.toLowerCase() === query.trim().toLowerCase() ||
          o.customer.phone.includes(query.trim())
      )
    : allOrders[0] || null;

  const steps: { key: OrderStatus; label: string; icon: any }[] = [
    { key: 'new', label: t.status_new, icon: Clock },
    { key: 'confirmed', label: t.status_confirmed, icon: CheckCircle2 },
    { key: 'packing', label: t.status_packing, icon: Package },
    { key: 'out_for_delivery', label: t.status_out_for_delivery, icon: Truck },
    { key: 'delivered', label: t.status_delivered, icon: CheckCircle2 }
  ];

  const getStepIndex = (status: OrderStatus) => {
    if (status === 'cancelled') return -1;
    return steps.findIndex((s) => s.key === status);
  };

  const handleReorder = (order: Order) => {
    let addedCount = 0;
    for (const item of order.items) {
      const res = UnifiedStore.addToCart(item.product, item.quantity);
      if (res.success) addedCount++;
    }

    if (addedCount > 0) {
      setReorderMsg(t.reorderSuccess);
      onReorderSuccess();
      setTimeout(() => setReorderMsg(null), 3500);
    } else {
      setReorderMsg(isSi ? 'සමාවන්න, මෙම භාණ්ඩ දැනට තොග අවසන්ව ඇත.' : 'Sorry, items from this order are currently out of stock.');
      setTimeout(() => setReorderMsg(null), 3500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 p-4 sm:p-6 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 relative max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-slate-900">{t.trackTitle}</h2>
            <p className="text-xs text-slate-500">{t.trackSubtitle}</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white text-slate-400 hover:text-slate-700 shadow-xs flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {/* Search Input */}
          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={isSi ? 'ඇණවුම් අංකය හෝ දුරකථනය (උදා: LK-8421)' : 'Enter Order # (e.g. LK-8421) or phone'}
                className="w-full pl-9 pr-3 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-emerald-500 outline-none"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          {reorderMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>{reorderMsg}</span>
            </div>
          )}

          {/* Active Order Details */}
          {activeOrder ? (
            <div className="space-y-6">
              {/* Order Card Header */}
              <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-black text-slate-900 font-mono">
                      #{activeOrder.orderNumber}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getStatusBadge(activeOrder.status, lang).color}`}>
                      {getStatusBadge(activeOrder.status, lang).label}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    {new Date(activeOrder.createdAt).toLocaleDateString()} {new Date(activeOrder.createdAt).toLocaleTimeString()}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {activeOrder.paymentStatus !== 'paid' && onPayNow && (
                    <button
                      onClick={() => onPayNow(activeOrder)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl text-xs font-black shadow-xs cursor-pointer transition-colors"
                    >
                      <span>💳 {isSi ? 'දැන් ගෙවන්න (Pay IPG)' : 'Pay via Gateway'}</span>
                    </button>
                  )}
                  <button
                    onClick={() => handleReorder(activeOrder)}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer transition-colors"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>{t.reorderBtn}</span>
                  </button>
                </div>
              </div>

              {/* Progress Pipeline Stepper */}
              {activeOrder.status !== 'cancelled' ? (
                <div className="py-2">
                  <div className="grid grid-cols-5 gap-1 relative">
                    {steps.map((step, idx) => {
                      const currentIdx = getStepIndex(activeOrder.status);
                      const isCompleted = idx <= currentIdx;
                      const isCurrent = idx === currentIdx;
                      const Icon = step.icon;

                      return (
                        <div key={step.key} className="flex flex-col items-center text-center">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold mb-1.5 transition-colors ${
                              isCompleted
                                ? isCurrent
                                  ? 'bg-emerald-600 text-white ring-4 ring-emerald-100 shadow-md'
                                  : 'bg-emerald-500 text-white'
                                : 'bg-slate-100 text-slate-400'
                            }`}
                          >
                            <Icon className="w-4 h-4" />
                          </div>
                          <span
                            className={`text-[10px] leading-tight font-medium ${
                              isCompleted ? 'text-slate-900 font-bold' : 'text-slate-400'
                            }`}
                          >
                            {step.label}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-2xl text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600" />
                  <span>
                    {isSi ? 'මෙම ඇණවුම අවලංගු කර ඇති අතර භාණ්ඩ තොගය නැවත ගබඩාවට යොමු කර ඇත.' : 'This order has been cancelled and its inventory items have been restored.'}
                  </span>
                </div>
              )}

              {/* Delivery & Items Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                {/* Customer / Delivery */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 space-y-1.5">
                  <span className="font-bold text-slate-700 block text-[11px] uppercase tracking-wider">
                    {isSi ? 'පාරිභෝගික සහ බෙදාහැරීමේ තොරතුරු' : 'Customer & Delivery Info'}
                  </span>
                  <p className="font-semibold text-slate-900">{activeOrder.customer.name}</p>
                  <p className="text-slate-600">{activeOrder.customer.phone}</p>
                  <p className="text-slate-500">
                    {activeOrder.customer.address}, {activeOrder.customer.city}
                  </p>
                  {activeOrder.customer.landmarkNotes && (
                    <p className="text-slate-400 italic">"{activeOrder.customer.landmarkNotes}"</p>
                  )}
                </div>

                {/* Items & Financial Bill Summary */}
                <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-1">
                    <span className="font-bold text-slate-700 block text-[11px] uppercase tracking-wider">
                      {isSi ? 'භාණ්ඩ සහ බිල්පත් සාරාංශය' : 'Items & Bill Breakdown'} ({activeOrder.items.length})
                    </span>
                    <button
                      onClick={() => window.print()}
                      className="flex items-center gap-1 text-[10px] text-slate-600 hover:text-slate-900 bg-white px-2 py-0.5 rounded border border-slate-200 cursor-pointer"
                    >
                      <Printer className="w-3 h-3 text-emerald-600" />
                      <span>{isSi ? 'Print' : 'Print Bill'}</span>
                    </button>
                  </div>

                  {(() => {
                    const totalRegularMRP = activeOrder.items.reduce((sum, item) => {
                      const orig = (item.product.originalPrice && item.product.originalPrice > (item.unitPrice || item.product.price))
                        ? item.product.originalPrice
                        : (item.unitPrice || item.product.price);
                      return sum + orig * item.quantity;
                    }, 0);
                    const netItems = activeOrder.items.reduce((sum, item) => sum + (item.unitPrice || item.product.price) * item.quantity, 0);
                    const savings = Math.max(activeOrder.discount || 0, Math.max(0, totalRegularMRP - netItems));

                    return (
                      <>
                        <div className="max-h-28 overflow-y-auto space-y-1.5 pr-1 divide-y divide-slate-100">
                          {activeOrder.items.map((item, i) => {
                            const effectivePrice = item.unitPrice || item.product.price;
                            const hasDiscount = item.product.originalPrice && item.product.originalPrice > effectivePrice;
                            return (
                              <div key={i} className="pt-1 first:pt-0 flex justify-between text-slate-600 text-[11px]">
                                <span className="truncate pr-2">
                                  {isSi ? item.product.nameSi : item.product.name} × {item.quantity}
                                  {hasDiscount && (
                                    <span className="line-through text-slate-400 ml-1 text-[10px]">
                                      Rs. {item.product.originalPrice?.toLocaleString()}
                                    </span>
                                  )}
                                </span>
                                <span className="font-semibold shrink-0 text-slate-800">
                                  Rs. {(effectivePrice * item.quantity).toLocaleString()}
                                </span>
                              </div>
                            );
                          })}
                        </div>

                        <div className="pt-1.5 border-t border-slate-200 space-y-1 text-[11px]">
                          {savings > 0 && (
                            <div className="flex justify-between text-slate-500">
                              <span>{isSi ? 'සාමාන්‍ය මුල් මිල (MRP):' : 'Original Total MRP:'}</span>
                              <span className="line-through">Rs. {totalRegularMRP.toLocaleString()}</span>
                            </div>
                          )}

                          {savings > 0 && (
                            <div className="flex justify-between text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
                              <span>🎉 {isSi ? 'ලැබුණු මුළු වට්ටම (Discount):' : 'Total Discount Saved:'}</span>
                              <span>-Rs. {savings.toLocaleString()}</span>
                            </div>
                          )}

                          <div className="flex justify-between text-slate-600">
                            <span>{t.subtotal}:</span>
                            <span className="font-semibold">Rs. {activeOrder.subtotal.toLocaleString()}</span>
                          </div>

                          <div className="flex justify-between text-slate-600">
                            <span>{t.deliveryFee}:</span>
                            <span className="font-semibold">
                              {activeOrder.deliveryFee === 0 ? t.free : `Rs. ${activeOrder.deliveryFee.toLocaleString()}`}
                            </span>
                          </div>

                          <div className="pt-1 border-t border-slate-200 flex justify-between font-extrabold text-slate-900 text-xs">
                            <span>{t.total}:</span>
                            <span className="text-emerald-700 font-black">Rs. {activeOrder.total.toLocaleString()}</span>
                          </div>
                        </div>
                      </>
                    );
                  })()}
                </div>
              </div>

              {/* Recent Status History Notes */}
              {activeOrder.statusHistory && activeOrder.statusHistory.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                    {isSi ? 'ඇණවුම් සටහන් සහ කාලසටහන' : 'Status Updates & Timeline'}
                  </h4>
                  <div className="space-y-1.5">
                    {activeOrder.statusHistory.map((h, i) => (
                      <div key={i} className="text-xs flex items-start gap-2 text-slate-600">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                        <div>
                          <span className="font-semibold text-slate-800 uppercase text-[10px] mr-1.5">
                            {h.status}:
                          </span>
                          <span>{h.note || 'Updated'}</span>
                          <span className="text-[10px] text-slate-400 ml-2">
                            ({new Date(h.timestamp).toLocaleTimeString()})
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400">
              <Package className="w-10 h-10 mx-auto text-slate-300 mb-2" />
              <p className="text-xs">{t.noOrdersFound}</p>
            </div>
          )}

          {/* Quick Recent Orders selection */}
          {allOrders.length > 1 && (
            <div className="border-t border-slate-100 pt-4">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
                {t.recentOrders}
              </span>
              <div className="flex flex-wrap gap-2">
                {allOrders.slice(0, 5).map((o) => (
                  <button
                    key={o.id}
                    onClick={() => setQuery(o.orderNumber)}
                    className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-xs font-mono font-medium text-slate-700 cursor-pointer transition-colors"
                  >
                    #{o.orderNumber}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
