import React, { useState, useMemo } from 'react';
import {
  Folder, FolderOpen, ArrowLeft, Search, Sparkles, Filter, ChevronRight,
  Package, Check, Tag, ShieldCheck, Flame, Layers, Eye
} from 'lucide-react';
import { Category, Language, Product } from '../types';
import { ProductCard } from './ProductCard';

interface FolderCatalogExplorerProps {
  lang: Language;
  categories: Category[];
  products: Product[];
  cart: { product: Product; quantity: number }[];
  favourites: string[];
  onAddToCart: (product: Product, quantity?: number) => void;
  onUpdateCartQty: (productId: string, quantity: number) => void;
  onToggleFav: (productId: string) => void;
  onViewDetails: (product: Product) => void;
  initialCategoryId?: string;
}

export const FolderCatalogExplorer: React.FC<FolderCatalogExplorerProps> = ({
  lang,
  categories,
  products,
  cart,
  favourites,
  onAddToCart,
  onUpdateCartQty,
  onToggleFav,
  onViewDetails,
  initialCategoryId
}) => {
  const isSi = lang === 'si';

  // Active Category Folder (null means at root / folder selection level)
  const [activeFolderId, setActiveFolderId] = useState<string | null>(
    initialCategoryId && initialCategoryId !== 'all' ? initialCategoryId : null
  );

  // Subcategory filter inside the active folder
  const [selectedSubcategory, setSelectedSubcategory] = useState<string>('all');

  // Brand filter inside the active folder
  const [selectedBrand, setSelectedBrand] = useState<string>('all');

  // Local Search inside folder or root
  const [folderSearch, setFolderSearch] = useState<string>('');

  // View Mode: 'folders' (Folder hierarchy) vs 'grid' (All items flat)
  const [viewMode, setViewMode] = useState<'folders' | 'grid'>('folders');

  // Find active category
  const activeCategory = useMemo(() => {
    return categories.find((c) => c.id === activeFolderId) || null;
  }, [categories, activeFolderId]);

  // Count items per category
  const categoryItemCounts = useMemo(() => {
    const counts: { [catId: string]: number } = {};
    categories.forEach((cat) => {
      counts[cat.id] = products.filter((p) => p.category === cat.id).length;
    });
    return counts;
  }, [categories, products]);

  // Filtered products inside active folder
  const productsInFolder = useMemo(() => {
    if (!activeFolderId) return products;

    return products.filter((p) => {
      const matchesCategory = p.category === activeFolderId;
      const matchesSubcategory =
        selectedSubcategory === 'all' ||
        p.subcategory?.toLowerCase().includes(selectedSubcategory.toLowerCase()) ||
        (selectedSubcategory === 'white-rice' && (p.name.toLowerCase().includes('white') || p.name.toLowerCase().includes('samba') || p.nameSi.includes('සුදු') || p.nameSi.includes('සම්බා'))) ||
        (selectedSubcategory === 'red-rice' && (p.name.toLowerCase().includes('red') || p.nameSi.includes('රතු'))) ||
        (selectedSubcategory === 'basmati' && (p.name.toLowerCase().includes('basmati') || p.nameSi.includes('බාස්මතී')));

      const matchesBrand = selectedBrand === 'all' || p.brand.toLowerCase() === selectedBrand.toLowerCase();

      const matchesSearch =
        folderSearch.trim() === '' ||
        p.name.toLowerCase().includes(folderSearch.toLowerCase()) ||
        p.nameSi.includes(folderSearch) ||
        p.brand.toLowerCase().includes(folderSearch.toLowerCase());

      return matchesCategory && matchesSubcategory && matchesBrand && matchesSearch;
    });
  }, [products, activeFolderId, selectedSubcategory, selectedBrand, folderSearch]);

  // Extract unique brands for active folder
  const folderBrands = useMemo(() => {
    if (!activeFolderId) return [];
    const brandsSet = new Set<string>();
    products
      .filter((p) => p.category === activeFolderId)
      .forEach((p) => {
        if (p.brand) brandsSet.add(p.brand);
      });
    return Array.from(brandsSet);
  }, [products, activeFolderId]);

  const handleOpenFolder = (categoryId: string) => {
    setActiveFolderId(categoryId);
    setSelectedSubcategory('all');
    setSelectedBrand('all');
    setFolderSearch('');
    // Smooth scroll to top of content
    window.scrollTo({ top: 380, behavior: 'smooth' });
  };

  const handleBackToFolders = () => {
    setActiveFolderId(null);
    setSelectedSubcategory('all');
    setSelectedBrand('all');
    setFolderSearch('');
    window.scrollTo({ top: 380, behavior: 'smooth' });
  };

  return (
    <div className="space-y-6">
      {/* Top View Mode Switcher */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-3xl border border-slate-200/90 shadow-xs">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            {isSi ? 'ගවේෂණ මාදිලිය:' : 'Browsing Mode:'}
          </span>
          <div className="inline-flex rounded-2xl bg-slate-100 p-1 border border-slate-200">
            <button
              onClick={() => {
                setViewMode('folders');
                setActiveFolderId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'folders'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Folder className="w-4 h-4" />
              <span>{isSi ? '📁 කාණ්ඩ ෆෝල්ඩර (Folders)' : '📁 Category Folders'}</span>
            </button>
            <button
              onClick={() => {
                setViewMode('grid');
                setActiveFolderId(null);
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'grid'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>{isSi ? '📋 සියලු භාණ්ඩ (All Products)' : '📋 All Products Flat'}</span>
            </button>
          </div>
        </div>

        {/* Directory Stats Badge */}
        <div className="text-xs font-medium text-slate-500 flex items-center gap-2">
          <span className="font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
            {categories.length} {isSi ? 'ප්‍රධාන කාණ්ඩ' : 'Folders'}
          </span>
          <span className="text-slate-300">•</span>
          <span className="font-bold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">
            {products.length} {isSi ? 'සජීවී භාණ්ඩ' : 'Live Products'}
          </span>
        </div>
      </div>

      {/* ================= SCENARIO A: INSIDE A SPECIFIC CATEGORY FOLDER ================= */}
      {viewMode === 'folders' && activeCategory ? (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* 🌟 1. PROMINENT BACK BUTTON BAR RIGHT ABOVE THE SECTION */}
          <div className="bg-white border-2 border-emerald-500/80 rounded-2xl p-3 sm:p-4 shadow-md flex flex-wrap items-center justify-between gap-3 sticky top-20 z-30 backdrop-blur-md">
            <button
              onClick={handleBackToFolders}
              className="flex items-center gap-2.5 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs sm:text-sm rounded-xl shadow-md shadow-emerald-600/25 cursor-pointer transition-all active:scale-95"
            >
              <ArrowLeft className="w-4 h-4 stroke-[3]" />
              <span>{isSi ? '⬅ සියලු කාණ්ඩ වෙත (Back to All Folders)' : '⬅ Back to All Folders'}</span>
            </button>

            <div className="flex items-center gap-2 text-xs font-mono">
              <span className="text-slate-500">📁 Directory /</span>
              <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200">
                {activeCategory.icon} {isSi ? activeCategory.nameSi : activeCategory.name}
              </span>
              <span className="text-slate-400">({productsInFolder.length} items)</span>
            </div>
          </div>

          {/* 🌟 2. CATEGORY COVER HERO BANNER WITH IMAGE */}
          <div className="relative overflow-hidden rounded-3xl bg-slate-900 border border-slate-800 text-white shadow-2xl">
            {/* Background Cover Photo with gradient overlay */}
            {activeCategory.image && (
              <div className="absolute inset-0 z-0">
                <img
                  src={activeCategory.image}
                  alt={activeCategory.name}
                  className="w-full h-full object-cover opacity-25 filter blur-xs scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-slate-950 via-slate-900/95 to-slate-950/80" />
              </div>
            )}

            <div className="relative z-10 p-6 sm:p-8 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  {/* Category Thumbnail / Cover Photo */}
                  <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border-2 border-emerald-400/80 shadow-xl shrink-0 bg-slate-800">
                    <img
                      src={activeCategory.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'}
                      alt={activeCategory.name}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">{activeCategory.icon}</span>
                      <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                        {isSi ? activeCategory.nameSi : activeCategory.name}
                      </h2>
                      <span className="text-[11px] bg-emerald-500 text-slate-950 font-black px-2.5 py-0.5 rounded-full shadow-xs">
                        {productsInFolder.length} {isSi ? 'භාණ්ඩ' : 'Products'}
                      </span>
                    </div>

                    <p className="text-xs sm:text-sm text-slate-200 mt-1 max-w-2xl leading-relaxed">
                      {isSi ? activeCategory.subcategoriesSummarySi : activeCategory.subcategoriesSummary}
                    </p>
                  </div>
                </div>

                {/* In-Folder Search Box */}
                <div className="relative max-w-xs w-full">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={folderSearch}
                    onChange={(e) => setFolderSearch(e.target.value)}
                    placeholder={isSi ? `${activeCategory.nameSi} තුළ සොයන්න...` : `Search in ${activeCategory.name}...`}
                    className="w-full pl-9 pr-3 py-2.5 bg-slate-800/90 border border-slate-700 focus:border-emerald-400 rounded-xl text-xs text-white placeholder-slate-400 outline-none shadow-inner"
                  />
                </div>
              </div>

              {/* Subcategories (Varieties) Filter Tabs */}
              {activeCategory.subcategories && activeCategory.subcategories.length > 0 && (
                <div className="pt-3 border-t border-slate-800/80 space-y-2">
                  <span className="text-[11px] uppercase tracking-wider font-bold text-slate-400 block">
                    {isSi ? 'උප-වර්ග (Subcategories & Varieties):' : 'Subcategories & Varieties:'}
                  </span>
                  <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                    <button
                      onClick={() => setSelectedSubcategory('all')}
                      className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                        selectedSubcategory === 'all'
                          ? 'bg-emerald-500 text-slate-950 shadow-md font-black scale-105'
                          : 'bg-slate-800 text-slate-200 hover:text-white border border-slate-700 hover:bg-slate-750'
                      }`}
                    >
                      <FolderOpen className="w-3.5 h-3.5" />
                      <span>{isSi ? 'සියලු වර්ග (All Varieties)' : 'All Varieties'}</span>
                    </button>

                    {activeCategory.subcategories.map((sub) => (
                      <button
                        key={sub.id}
                        onClick={() => setSelectedSubcategory(sub.id)}
                        className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                          selectedSubcategory === sub.id
                            ? 'bg-emerald-500 text-slate-950 shadow-md font-black scale-105'
                            : 'bg-slate-800 text-slate-200 hover:text-white border border-slate-700 hover:bg-slate-750'
                        }`}
                      >
                        <Folder className="w-3.5 h-3.5" />
                        <span>{isSi ? sub.nameSi : sub.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Brand Filter Pills */}
              {folderBrands.length > 0 && (
                <div className="pt-2 border-t border-slate-800/60 flex items-center gap-2 overflow-x-auto scrollbar-none text-xs">
                  <span className="text-slate-400 font-bold shrink-0">{isSi ? '🏷️ Brands:' : '🏷️ Brands:'}</span>
                  <button
                    onClick={() => setSelectedBrand('all')}
                    className={`px-3 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                      selectedBrand === 'all'
                        ? 'bg-amber-400 text-slate-950 font-black'
                        : 'bg-slate-800 text-slate-300 hover:text-white border border-slate-700'
                    }`}
                  >
                    All Brands
                  </button>
                  {folderBrands.map((b) => (
                    <button
                      key={b}
                      onClick={() => setSelectedBrand(b)}
                      className={`px-3 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer whitespace-nowrap ${
                        selectedBrand === b
                          ? 'bg-amber-400 text-slate-950 font-black'
                          : 'bg-slate-800 text-slate-300 hover:text-white border border-slate-700'
                      }`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Product Items in This Folder */}
          {productsInFolder.length === 0 ? (
            <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 space-y-3">
              <Package className="w-12 h-12 mx-auto text-slate-300" />
              <h3 className="text-base font-bold text-slate-700">
                {isSi ? 'මෙම වර්ගය හෝ Brand එක යටතේ භාණ්ඩ හමු නොවීය' : 'No products found in this variety'}
              </h3>
              <p className="text-xs text-slate-400">
                {isSi ? 'වෙනත් Brand එකක් හෝ සියලු වර්ග තෝරා බලන්න.' : 'Try changing your brand filter or search term.'}
              </p>
              <button
                onClick={() => {
                  setSelectedSubcategory('all');
                  setSelectedBrand('all');
                  setFolderSearch('');
                }}
                className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                {isSi ? 'සියලු භාණ්ඩ පෙන්වන්න' : 'Reset Filters'}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
              {productsInFolder.map((product) => {
                const cartItem = cart.find((i) => i.product.id === product.id);
                const isFav = favourites.includes(product.id);

                return (
                  <ProductCard
                    key={product.id}
                    product={product}
                    lang={lang}
                    cartQuantity={cartItem?.quantity || 0}
                    isFavourite={isFav}
                    onAddToCart={onAddToCart}
                    onUpdateCartQty={onUpdateCartQty}
                    onToggleFav={onToggleFav}
                    onViewDetails={onViewDetails}
                  />
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* ================= SCENARIO B: ROOT FOLDER EXPLORER (STUNNING PHOTO FOLDER CARDS) ================= */
        <div className="space-y-6">
          {/* Visual Introduction Banner */}
          <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border-2 border-emerald-500/80 rounded-3xl p-5 sm:p-7 text-white shadow-xl space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40">
                <FolderOpen className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-black text-lg sm:text-xl text-white tracking-tight">
                  {isSi ? 'භාණ්ඩ කාණ්ඩ ෆෝල්ඩර (Category Folder Explorer)' : 'Explore Store by Category Folders'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300">
                  {isSi
                    ? 'කැමති කාණ්ඩය මත ක්ලික් කර එම ෆෝල්ඩරය විවෘත කරන්න. සහල්, එළවළු, කිරිපිටි ආදී සියලු වර්ග සහ Brands පහසුවෙන් සොයාගත හැක.'
                    : 'Click any folder (e.g. Rice, Vegetables, Dairy) to view varieties grouped by type and brand for easy finding.'}
                </p>
              </div>
            </div>
          </div>

          {/* 🌟 20 STUNNING CATEGORY FOLDER CARDS WITH GORGEOUS COVER PHOTOS 🌟 */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {categories.map((cat) => {
              const count = categoryItemCounts[cat.id] || 0;

              return (
                <div
                  key={cat.id}
                  onClick={() => handleOpenFolder(cat.id)}
                  className="bg-white hover:bg-emerald-50/20 border-2 border-slate-200/90 hover:border-emerald-500 rounded-3xl overflow-hidden cursor-pointer transition-all duration-300 shadow-sm hover:shadow-2xl hover:-translate-y-1.5 group flex flex-col justify-between"
                >
                  {/* 📷 GORGEOUS CATEGORY COVER PHOTO */}
                  <div className="relative h-44 sm:h-48 w-full overflow-hidden bg-slate-100">
                    <img
                      src={cat.image || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=600&q=80'}
                      alt={cat.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-108"
                    />

                    {/* Gradient Overlay for Text Readability */}
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/25 to-transparent" />

                    {/* Top Floating Badge with Icon */}
                    <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-md text-slate-900 text-xs font-bold px-2.5 py-1 rounded-xl shadow-md flex items-center gap-1.5">
                      <span className="text-base">{cat.icon}</span>
                      <span>{cat.badge || cat.name}</span>
                    </div>

                    {/* Top Right Items Counter Pill */}
                    <div className="absolute top-3 right-3 bg-emerald-600/90 backdrop-blur-md text-white text-[11px] font-black px-2.5 py-1 rounded-xl shadow-md font-mono">
                      {count} {isSi ? 'වර්ග' : 'Items'}
                    </div>

                    {/* Bottom Title on Image */}
                    <div className="absolute bottom-3 inset-x-3 text-white">
                      <h4 className="font-black text-lg sm:text-xl drop-shadow-md group-hover:text-emerald-300 transition-colors">
                        {isSi ? cat.nameSi : cat.name}
                      </h4>
                      <span className="text-[11px] text-slate-200 font-medium block drop-shadow-xs">
                        {cat.name}
                      </span>
                    </div>
                  </div>

                  {/* Card Body with Summary from User's Image */}
                  <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                    <div className="space-y-2">
                      {cat.subcategoriesSummary && (
                        <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed bg-slate-50 p-2.5 rounded-xl border border-slate-150">
                          {isSi ? cat.subcategoriesSummarySi : cat.subcategoriesSummary}
                        </p>
                      )}

                      {/* Brand Tags */}
                      {cat.popularBrands && cat.popularBrands.length > 0 && (
                        <div className="flex flex-wrap gap-1 pt-0.5">
                          {cat.popularBrands.slice(0, 3).map((brand, i) => (
                            <span
                              key={i}
                              className="text-[10px] bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md font-semibold border border-slate-200/60"
                            >
                              {brand}
                            </span>
                          ))}
                          {cat.popularBrands.length > 3 && (
                            <span className="text-[10px] text-slate-400 font-bold self-center">
                              +{cat.popularBrands.length - 3} more
                            </span>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Bottom Action Button */}
                    <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-black text-emerald-700 group-hover:text-emerald-800">
                      <span className="flex items-center gap-1.5">
                        <Folder className="w-4 h-4 text-emerald-600 group-hover:text-emerald-700" />
                        <span>{isSi ? 'ෆෝල්ඩරය විවෘත කරන්න' : 'Open Folder'}</span>
                      </span>
                      <ChevronRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
