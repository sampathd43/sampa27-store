import React from 'react';
import { CheckCircle2, MessageCircle, Package, Printer, Tag, Sparkles } from 'lucide-react';
import { Language, Order } from '../types';
import { TRANSLATIONS, formatWhatsAppMessage } from '../translations';

interface OrderSuccessModalProps {
  order: Order | null;
  lang: Language;
  onClose: () => void;
  onTrackOrder: (orderNumber: string) => void;
}

export const OrderSuccessModal: React.FC<OrderSuccessModalProps> = ({
  order,
  lang,
  onClose,
  onTrackOrder
}) => {
  if (!order) return null;

  const t = TRANSLATIONS[lang];
  const isSi = lang === 'si';

  const encodedWhatsApp = formatWhatsAppMessage(order, lang);
  const whatsappUrl = `https://wa.me/94774778190?text=${encodedWhatsApp}`;

  // Calculate detailed financial and discount breakdown
  const totalRegularMRP = order.items.reduce((sum, item) => {
    const orig = (item.product.originalPrice && item.product.originalPrice > (item.unitPrice || item.product.price))
      ? item.product.originalPrice
      : (item.unitPrice || item.product.price);
    return sum + orig * item.quantity;
  }, 0);

  const netItemsSubtotal = order.items.reduce((sum, item) => {
    const effectivePrice = item.unitPrice || item.product.price;
    return sum + effectivePrice * item.quantity;
  }, 0);

  const itemLevelSavings = Math.max(0, totalRegularMRP - netItemsSubtotal);
  const totalSavings = Math.max(order.discount || 0, itemLevelSavings);
  const percentSaved = totalRegularMRP > 0 && totalSavings > 0
    ? Math.round((totalSavings / totalRegularMRP) * 100)
    : 0;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 p-4 sm:p-6 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center animate-in fade-in duration-150 overflow-y-auto">
      <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-100 relative p-6 sm:p-7 space-y-4 max-h-[92vh] flex flex-col">
        {/* Celebration header */}
        <div className="text-center space-y-1.5 shrink-0">
          <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md shadow-emerald-500/10">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h2 className="text-lg sm:text-xl font-black text-slate-900">
            {t.orderSuccessTitle}
          </h2>
          <p className="text-xs text-slate-500">
            {t.orderSuccessSubtitle}
          </p>
        </div>

        {/* Order ID Badge */}
        <div className="bg-emerald-50 border border-emerald-200 rounded-2xl p-3.5 text-center shrink-0">
          <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider block">
            {t.orderIdText}
          </span>
          <span className="text-2xl font-black text-emerald-950 font-mono tracking-tight">
            #{order.orderNumber}
          </span>
          <p className="text-[11px] text-emerald-700/90 mt-0.5">
            {isSi
              ? 'කඩේ සජීවී තොගයෙන් භාණ්ඩ අඩු කර තහවුරු කර ගන්නා ලදී'
              : 'Deducted from live inventory & confirmed in store system'}
          </p>
        </div>

        {/* PROMINENT DISCOUNT SAVINGS CELEBRATION BADGE (Requirement 6) */}
        {totalSavings > 0 && (
          <div className="bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white rounded-2xl p-3.5 shadow-md flex items-center justify-between shrink-0 animate-in fade-in">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center text-lg shadow-inner">
                🎉
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-100 block">
                  {isSi ? 'ඔබට හිමිවූ මුළු වට්ටම' : 'Total Discount Received'}
                </span>
                <span className="text-xs font-semibold text-white/95">
                  {isSi ? 'මෙම ඇණවුමෙන් ඔබ ඉතිරි කරගත් මුදල' : 'You saved on purchased goods'}
                </span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-base sm:text-lg font-black tracking-tight text-white block">
                -Rs. {totalSavings.toLocaleString()}
              </span>
              {percentSaved > 0 && (
                <span className="inline-block text-[10px] bg-white text-emerald-800 font-extrabold px-2 py-0.5 rounded-full shadow-xs">
                  {percentSaved}% OFF
                </span>
              )}
            </div>
          </div>
        )}

        {/* Items Summary & Customer Bill Breakdown */}
        <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 space-y-2.5 text-xs overflow-y-auto flex-1">
          <div className="font-bold text-slate-800 border-b border-slate-200 pb-2 flex justify-between items-center">
            <span className="flex items-center gap-1.5">
              <Tag className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isSi ? 'බිල්පත සහ භාණ්ඩ ලැයිස්තුව' : 'Customer Bill & Items'} ({order.items.length})</span>
            </span>
            <span className="text-[11px] font-mono font-semibold text-slate-500">
              {new Date(order.createdAt).toLocaleDateString()}
            </span>
          </div>

          {/* Line items with individual discount callouts */}
          <div className="max-h-36 overflow-y-auto space-y-2 pr-1 divide-y divide-slate-100">
            {order.items.map((item, idx) => {
              const effectivePrice = item.unitPrice || item.product.price;
              const hasDiscount = item.product.originalPrice && item.product.originalPrice > effectivePrice;
              const itemDiscount = hasDiscount ? (item.product.originalPrice! - effectivePrice) * item.quantity : 0;

              return (
                <div key={idx} className="pt-1.5 first:pt-0 flex items-start justify-between text-slate-700 gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="font-semibold truncate">
                      {isSi ? item.product.nameSi : item.product.name}
                    </div>
                    <div className="flex items-center gap-1.5 flex-wrap text-[11px] text-slate-500">
                      <span>{item.product.unit} × {item.quantity}</span>
                      {hasDiscount && (
                        <span className="line-through text-slate-400 text-[10px]">
                          Rs. {item.product.originalPrice?.toLocaleString()}
                        </span>
                      )}
                      <span className="font-semibold text-slate-900">
                        @ Rs. {effectivePrice.toLocaleString()}
                      </span>
                      {item.isWholesaleApplied && (
                        <span className="px-1 py-0.2 rounded bg-amber-100 text-amber-800 text-[9px] font-bold">
                          Wholesale
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="font-bold text-slate-900 block">
                      Rs. {(effectivePrice * item.quantity).toLocaleString()}
                    </span>
                    {itemDiscount > 0 && (
                      <span className="text-[10px] text-emerald-600 font-bold block">
                        Saved -Rs. {itemDiscount.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Transparent Financial Totals Box on the Bill */}
          <div className="pt-2.5 border-t border-slate-200 space-y-1.5 text-xs">
            {totalSavings > 0 && (
              <div className="flex justify-between text-slate-500 text-[11px]">
                <span>{isSi ? 'සාමාන්‍ය මුල් මිල (Original MRP):' : 'Regular Total MRP:'}</span>
                <span className="line-through">
                  Rs. {totalRegularMRP.toLocaleString()}
                </span>
              </div>
            )}

            {totalSavings > 0 && (
              <div className="flex justify-between text-emerald-700 font-bold bg-emerald-50 px-2 py-1 rounded-lg">
                <span className="flex items-center gap-1">
                  <span>🎉</span>
                  <span>{isSi ? 'ලැබුණු මුළු වට්ටම (Total Discount):' : 'Total Discount Saved:'}</span>
                </span>
                <span>-Rs. {totalSavings.toLocaleString()}</span>
              </div>
            )}

            <div className="flex justify-between text-slate-600">
              <span>{t.subtotal}:</span>
              <span className="font-semibold">Rs. {order.subtotal.toLocaleString()}</span>
            </div>

            <div className="flex justify-between text-slate-600">
              <span>{t.deliveryFee} ({order.deliveryZone ? order.deliveryZone.replace('_', ' ') : 'Standard'}):</span>
              <span className="font-semibold">
                {order.deliveryFee === 0 ? t.free : `Rs. ${order.deliveryFee.toLocaleString()}`}
              </span>
            </div>

            <div className="pt-1.5 border-t border-slate-200 flex justify-between text-sm font-extrabold text-slate-900">
              <span>{isSi ? 'ගෙවිය යුතු අවසාන මුදල (Net Total):' : 'Grand Total Payable:'}</span>
              <span className="text-emerald-700 text-base font-black">
                Rs. {order.total.toLocaleString()}
              </span>
            </div>

            <div className="pt-1 flex justify-between text-slate-500 text-[11px]">
              <span>{isSi ? 'බෙදාහැරීම' : 'Delivery Destination'}: {order.customer.city}</span>
              <span className="uppercase font-bold text-slate-700">{order.paymentMethod}</span>
            </div>
          </div>
        </div>

        {/* WhatsApp & Actions */}
        <div className="space-y-2 pt-1 shrink-0">
          {/* Send via WhatsApp */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2.5 bg-[#25D366] hover:bg-[#20ba59] text-white font-bold rounded-xl shadow-md flex items-center justify-center gap-2 cursor-pointer transition-colors text-xs"
          >
            <MessageCircle className="w-4 h-4" />
            <span>{t.sendWhatsAppBtn}</span>
          </a>

          <div className="grid grid-cols-2 gap-2">
            {/* Print Receipt */}
            <button
              onClick={handlePrint}
              className="py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors text-xs"
            >
              <Printer className="w-3.5 h-3.5 text-slate-600" />
              <span>{isSi ? 'බිල Print කරන්න' : 'Print Receipt'}</span>
            </button>

            {/* Track Order */}
            <button
              onClick={() => {
                onTrackOrder(order.orderNumber);
                onClose();
              }}
              className="py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-colors text-xs"
            >
              <Package className="w-3.5 h-3.5 text-emerald-400" />
              <span>{t.trackOrderBtn}</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className="w-full py-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 cursor-pointer"
          >
            {t.continueShopping}
          </button>
        </div>
      </div>
    </div>
  );
};
