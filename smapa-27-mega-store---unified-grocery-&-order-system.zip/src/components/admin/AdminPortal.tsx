import React, { useState } from 'react';
import {
  Package, ShoppingBag, Users, BarChart3, Plus, Search, CheckCircle2,
  AlertTriangle, RefreshCw, Eye, Edit, Trash2, Store, ShoppingCart,
  Phone, MapPin, Printer, RotateCcw, Truck, DollarSign, ArrowRight,
  TrendingUp, ShieldCheck, Zap, Layers, Sparkles, Send, Check, Box, Bell, Folder
} from 'lucide-react';
import {
  DeliveryRider, DeliveryZoneConfig, Language, Order, OrderStatus, Product, ReorderItem, StockLog, CustomerProfile, Category
} from '../../types';
import { TRANSLATIONS, getStatusBadge } from '../../translations';
import { UnifiedStore } from '../../services/store';
import { PosTerminalTab } from './PosTerminalTab';
import { NotificationsTab } from './NotificationsTab';
import { DeliveryZonesManager } from './DeliveryZonesManager';
import { SalesReportsTab } from './SalesReportsTab';
import { ProductImageStudioUploader } from './ProductImageStudioUploader';

export interface AdminPortalProps {
  lang: Language;
  onCloseAdmin: () => void;
  initialTab?: AdminTab;
}

export type AdminTab =
  | 'dashboard'
  | 'sales-reports'
  | 'sync-flow'
  | 'pos-terminal'
  | 'products'
  | 'pricing'
  | 'orders'
  | 'inventory'
  | 'reorder'
  | 'customers'
  | 'delivery'
  | 'notifications';

export const AdminPortal: React.FC<AdminPortalProps> = ({
  lang,
  onCloseAdmin,
  initialTab = 'dashboard'
}) => {
  const isSi = lang === 'si';
  const t = TRANSLATIONS[lang];

  const [activeTab, setActiveTab] = useState<AdminTab>(initialTab);
  const [searchTerm, setSearchTerm] = useState('');
  const [orderStatusFilter, setOrderStatusFilter] = useState<string>('all');

  // Reactive data
  const products = UnifiedStore.getProducts();
  const orders = UnifiedStore.getOrders();
  const stockLogs = UnifiedStore.getStockLogs();
  const categories = UnifiedStore.getCategories();
  const customers = UnifiedStore.getCustomers();
  const riders = UnifiedStore.getRiders();
  const deliveryZones = UnifiedStore.getDeliveryZones();
  const reorderList = UnifiedStore.getReorderRecommendations();

  // POS Cashier State
  const [posSelectedProductId, setPosSelectedProductId] = useState<string>(products[0]?.id || '');
  const [posQuantity, setPosQuantity] = useState<number>(1);
  const [posCustomerName, setPosCustomerName] = useState<string>('Walk-in Cash Customer');
  const [posFeedback, setPosFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Triple Sync Simulator State
  const [syncSimulationResult, setSyncSimulationResult] = useState<{
    initialStock: number;
    afterShop: number;
    afterWeb: number;
    afterApp: number;
    running: boolean;
  } | null>(null);

  // Product Add / Edit Modal State
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [productForm, setProductForm] = useState<Partial<Product>>({
    sku: '',
    barcode: '',
    name: '',
    nameSi: '',
    brand: '',
    category: 'rice-grains',
    categorySi: 'සහල් සහ ධාන්‍ය',
    subcategory: 'Essentials',
    price: 500,
    wholesalePrice: 460,
    wholesaleMinQty: 3,
    costPrice: 400,
    stock: 20,
    shelfStock: 8,
    backstoreStock: 12,
    minStockAlert: 5,
    reorderQuantity: 30,
    unit: '1 kg pack',
    unitSi: 'කි.ග්‍රෑ. 1 පැකට්ටුව',
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
    isActive: true,
    supplier: {
      name: 'Lanka Wholesale Distributors',
      phone: '011 234 5678',
      leadTimeDays: 2
    },
    description: '',
    descriptionSi: ''
  });

  // State for creating new category inside product modal
  const [isCreatingNewCat, setIsCreatingNewCat] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatNameSi, setNewCatNameSi] = useState('');
  const [newCatIcon, setNewCatIcon] = useState('📦');
  const [newCatImage, setNewCatImage] = useState('');

  // Selected Order for Receipt / Packing Slip Modal
  const [viewingOrder, setViewingOrder] = useState<Order | null>(null);
  const [selectedRiderForOrder, setSelectedRiderForOrder] = useState<string>('');

  // Restock feedback
  const [restockNotice, setRestockNotice] = useState<string | null>(null);

  // Financial & Inventory KPIs
  const totalRevenue = orders.reduce((sum, o) => sum + (o.paymentStatus === 'paid' || o.status !== 'cancelled' ? o.total : 0), 0);
  const posSalesRevenue = orders.filter((o) => o.channel === 'shop_pos').reduce((sum, o) => sum + o.total, 0);
  const onlineWebRevenue = orders.filter((o) => o.channel === 'online_web' || o.channel === 'mobile_app').reduce((sum, o) => sum + o.total, 0);
  const pendingOrdersCount = orders.filter((o) => o.status === 'new' || o.status === 'confirmed' || o.status === 'packing').length;
  const outForDeliveryCount = orders.filter((o) => o.status === 'out_for_delivery').length;

  const totalStockCount = products.reduce((sum, p) => sum + p.stock, 0);
  const totalShelfStock = products.reduce((sum, p) => sum + (p.shelfStock || 0), 0);
  const totalBackstoreStock = products.reduce((sum, p) => sum + (p.backstoreStock || 0), 0);
  const totalCostValuation = products.reduce((sum, p) => sum + p.costPrice * p.stock, 0);
  const totalRetailValuation = products.reduce((sum, p) => sum + p.price * p.stock, 0);
  const potentialProfitValuation = totalRetailValuation - totalCostValuation;

  // Handle POS Sale
  const handlePerformPosSale = (e: React.FormEvent) => {
    e.preventDefault();
    setPosFeedback(null);

    const prod = products.find((p) => p.id === posSelectedProductId);
    if (!prod) return;

    if (posQuantity > prod.stock) {
      setPosFeedback({
        type: 'error',
        message: isSi ? `තොග මදි! පවතින්නේ ${prod.stock} ක් පමණි.` : `Insufficient stock! Only ${prod.stock} items available.`
      });
      return;
    }

    const previousStock = prod.stock;
    const res = UnifiedStore.performShopCounterSale(
      [{ productId: prod.id, quantity: posQuantity }],
      posCustomerName.trim() || 'Counter Walk-in'
    );

    if (res.success) {
      setPosFeedback({
        type: 'success',
        message: isSi
          ? `සාර්ථකයි! ${prod.nameSi} (${posQuantity}) කඩේ කවුන්ටරයෙන් විකුණන ලදී. තොගය ${previousStock} ➔ ${previousStock - posQuantity} දක්වා ක්ෂණිකව අඩු විය!`
          : `Success! Sold ${posQuantity}x ${prod.name}. Stock updated ${previousStock} ➔ ${previousStock - posQuantity} across Web, POS & App!`
      });
      setPosQuantity(1);
    } else {
      setPosFeedback({ type: 'error', message: res.error || 'Sale failed' });
    }
  };

  // Run Triple Sync Simulation
  const handleRunTripleSync = () => {
    setSyncSimulationResult({ initialStock: 0, afterShop: 0, afterWeb: 0, afterApp: 0, running: true });

    setTimeout(() => {
      const res = UnifiedStore.simulateOmnichannelTripleSync('prod-rice-keeri-5kg');
      if (res.success) {
        setSyncSimulationResult({
          initialStock: res.initialStock,
          afterShop: res.afterShop,
          afterWeb: res.afterWeb,
          afterApp: res.afterApp,
          running: false
        });
      } else {
        setSyncSimulationResult(null);
      }
    }, 700);
  };

  // Quick Restock Item
  const handleQuickRestock = (productId: string, qty: number) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;
    UnifiedStore.restockProduct(productId, qty, `Supplier Delivery PO-${Math.floor(1000 + Math.random() * 9000)}`);
    setRestockNotice(
      isSi
        ? `${prod.nameSi} තොගය සාර්ථකව +${qty} කින් නැවත පිරවුණි!`
        : `Successfully restocked ${qty} units of ${prod.name}!`
    );
    setTimeout(() => setRestockNotice(null), 3500);
  };

  // Open Edit Product Modal
  const openEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setProductForm({ ...prod });
    setIsCreatingNewCat(false);
    setIsProductModalOpen(true);
  };

  // Open New Product Modal
  const openNewProduct = () => {
    const defaultCat = categories[0] || { id: 'rice', nameSi: 'සහල් වර්ග' };
    setEditingProduct(null);
    setProductForm({
      id: `prod-${Date.now()}`,
      sku: `PROD-${Math.floor(100 + Math.random() * 900)}`,
      barcode: `4795${Math.floor(10000000 + Math.random() * 90000000)}`,
      name: '',
      nameSi: '',
      brand: defaultCat.popularBrands?.[0] || 'Lanka Fresh',
      category: defaultCat.id,
      categorySi: defaultCat.nameSi,
      subcategory: defaultCat.subcategories?.[0]?.id || 'General',
      price: 500,
      originalPrice: 580,
      wholesalePrice: 460,
      wholesaleMinQty: 3,
      costPrice: 400,
      stock: 20,
      shelfStock: 8,
      backstoreStock: 12,
      minStockAlert: 5,
      reorderQuantity: 30,
      unit: '1 kg pack',
      unitSi: 'කි.ග්‍රෑ. 1 පැකට්ටුව',
      image: defaultCat.image || 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
      isActive: true,
      supplier: {
        name: 'Colombo Wholesale Suppliers',
        phone: '011 234 5678',
        leadTimeDays: 2
      },
      description: '',
      descriptionSi: ''
    });
    setIsCreatingNewCat(false);
    setIsProductModalOpen(true);
  };

  // Create & Save New Category from inside product modal
  const handleAddNewCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName.trim()) return;

    const catId = newCatName.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-');
    const newCategory: Category = {
      id: catId,
      name: newCatName.trim(),
      nameSi: newCatNameSi.trim() || newCatName.trim(),
      icon: newCatIcon.trim() || '📦',
      image: newCatImage.trim() || 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
      badge: 'Custom',
      subcategoriesSummary: `${newCatName.trim()} variety items.`,
      subcategoriesSummarySi: `${newCatNameSi.trim()} වර්ග.`,
      popularBrands: []
    };

    UnifiedStore.saveCategory(newCategory);

    // Auto-select this newly created category for the current product!
    setProductForm((prev) => ({
      ...prev,
      category: newCategory.id,
      categorySi: newCategory.nameSi
    }));

    setIsCreatingNewCat(false);
    setNewCatName('');
    setNewCatNameSi('');
    setNewCatIcon('📦');
    setNewCatImage('');
  };

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.name || !productForm.price) return;

    const chosenCat = categories.find((c) => c.id === productForm.category);
    const catId = productForm.category || categories[0]?.id || 'rice';
    const catNameSi = chosenCat?.nameSi || productForm.categorySi || 'සාමාන්‍ය භාණ්ඩ';

    const finalProduct: Product = {
      id: editingProduct ? editingProduct.id : `prod-${Date.now()}`,
      sku: productForm.sku || `SKU-${Date.now()}`,
      barcode: productForm.barcode || '479000000000',
      name: productForm.name || 'New Item',
      nameSi: productForm.nameSi || productForm.name || 'නව භාණ්ඩය',
      brand: productForm.brand || chosenCat?.popularBrands?.[0] || 'Lanka Brand',
      category: catId,
      categorySi: catNameSi,
      subcategory: productForm.subcategory || chosenCat?.subcategories?.[0]?.id || 'General',
      price: Number(productForm.price) || 0,
      originalPrice: productForm.originalPrice && Number(productForm.originalPrice) > (Number(productForm.price) || 0)
        ? Number(productForm.originalPrice)
        : undefined,
      isHotDeal: Boolean(productForm.originalPrice && Number(productForm.originalPrice) > (Number(productForm.price) || 0)),
      wholesalePrice: Number(productForm.wholesalePrice) || Number(productForm.price) || 0,
      wholesaleMinQty: Number(productForm.wholesaleMinQty) || 3,
      costPrice: Number(productForm.costPrice) || 0,
      stock: Number(productForm.stock) || 0,
      shelfStock: Number(productForm.shelfStock) || Math.floor((Number(productForm.stock) || 0) * 0.4),
      backstoreStock: Number(productForm.backstoreStock) || Math.ceil((Number(productForm.stock) || 0) * 0.6),
      reservedOnlineStock: 0,
      minStockAlert: Number(productForm.minStockAlert) || 5,
      reorderQuantity: Number(productForm.reorderQuantity) || 25,
      unit: productForm.unit || '1 unit',
      unitSi: productForm.unitSi || '1ක්',
      image: productForm.image || chosenCat?.image || 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=600&q=80',
      isActive: productForm.isActive ?? true,
      soldCount: editingProduct ? editingProduct.soldCount : 0,
      supplier: productForm.supplier || {
        name: 'General Distributor',
        phone: '011 234 5678',
        leadTimeDays: 2
      },
      description: productForm.description || '',
      descriptionSi: productForm.descriptionSi || ''
    };

    UnifiedStore.saveProduct(finalProduct);
    setIsProductModalOpen(false);
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm(isSi ? 'මෙම භාණ්ඩය ඉවත් කිරීමට ඔබට විශ්වාසද?' : 'Are you sure you want to delete this product?')) {
      UnifiedStore.deleteProduct(id);
    }
  };

  // Filtered lists
  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.nameSi.includes(searchTerm) ||
      p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.barcode.includes(searchTerm) ||
      p.brand.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredOrders = orders.filter((o) => {
    if (orderStatusFilter !== 'all' && o.status !== orderStatusFilter) return false;
    if (!searchTerm) return true;
    const term = searchTerm.toLowerCase();
    return (
      o.orderNumber.toLowerCase().includes(term) ||
      o.customer.name.toLowerCase().includes(term) ||
      o.customer.phone.includes(term)
    );
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Top Bar */}
      <div className="bg-slate-900 border-b border-slate-800 px-4 sm:px-8 py-3 flex flex-wrap items-center justify-between gap-4 sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Store className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-black tracking-tight text-white">
                {isSi ? 'SMAPA 27 Mega Store - V1 පාලක පුවරුව' : 'SMAPA 27 Mega Store - Unified ERP Dashboard V1'}
              </h1>
              <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Live Single DB
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {isSi
                ? 'Shop ↔ Website ↔ App එකම product, stock, customer & order database එකට සබැඳිව ක්‍රියා කරයි'
                : 'Unified single-database system flow connecting Physical POS, Web Store & Mobile App'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Direct Step Jump Buttons */}
          <button
            onClick={() => setActiveTab('notifications')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
              activeTab === 'notifications'
                ? 'bg-amber-500 text-slate-950 border-amber-300 font-black shadow-md ring-2 ring-amber-400/50'
                : 'bg-amber-950/70 text-amber-300 border-amber-700/80 hover:bg-amber-900'
            }`}
          >
            <Bell className="w-3.5 h-3.5 text-amber-400" />
            <span>🔔 STEP 7: SMS & WhatsApp</span>
          </button>

          <button
            onClick={() => setActiveTab('pos-terminal')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
              activeTab === 'pos-terminal'
                ? 'bg-emerald-500 text-slate-950 border-emerald-300 font-black shadow-md ring-2 ring-emerald-400/50'
                : 'bg-emerald-950/70 text-emerald-300 border-emerald-700/80 hover:bg-emerald-900'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            <span>🏪 STEP 8: Shop POS</span>
          </button>

          <button
            onClick={() => setActiveTab('delivery')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
              activeTab === 'delivery'
                ? 'bg-indigo-600 text-white border-indigo-400 font-black shadow-md ring-2 ring-indigo-400/50'
                : 'bg-indigo-950/70 text-indigo-300 border-indigo-700/80 hover:bg-indigo-900'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            <span>🚚 STEP 6: Delivery</span>
          </button>

          <button
            onClick={() => {
              if (window.confirm(isSi ? 'දත්ත නැවත මුල් තත්වයට පත් කරන්නද?' : 'Reset products & stock to initial state?')) {
                UnifiedStore.resetToDefault();
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold border border-slate-700 cursor-pointer transition-colors"
            title="Reset Stock to Default"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isSi ? 'මුල් තත්වයට' : 'Reset Stock'}</span>
          </button>

          {/* Quick Direct Add Product Button in Header */}
          <button
            onClick={() => {
              setActiveTab('products');
              openNewProduct();
            }}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 text-xs font-black shadow-lg shadow-emerald-500/20 cursor-pointer transition-all active:scale-95"
            title="Add a new product to store"
          >
            <Plus className="w-4 h-4 text-slate-950" />
            <span>{isSi ? '+ නව භාණ්ඩයක්' : '+ Add Product'}</span>
          </button>

          <button
            onClick={onCloseAdmin}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md cursor-pointer transition-colors"
          >
            <Eye className="w-4 h-4" />
            <span>{isSi ? 'පාරිභෝගික කඩයට යන්න' : 'Customer Shop'}</span>
          </button>
        </div>
      </div>

      {/* Nav Tabs for the Modules */}
      <div className="bg-slate-900/60 border-b border-slate-800 px-4 sm:px-8">
        <div className="max-w-7xl mx-auto flex items-center gap-1.5 overflow-x-auto scrollbar-none py-2.5">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'dashboard' ? 'bg-slate-700 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>📊 Dashboard</span>
          </button>

          {/* 1. SALES REPORTS & DAY-END CASH BALANCE TAB */}
          <button
            onClick={() => setActiveTab('sales-reports')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-black transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'sales-reports'
                ? 'bg-gradient-to-r from-amber-500 to-emerald-500 text-slate-950 font-black shadow-lg ring-2 ring-amber-400/50'
                : 'bg-amber-950/70 text-amber-300 hover:text-white hover:bg-amber-900/80 border border-amber-600/70'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>📑 Sales & Cash Reports (දවසේ මුදල් හා විකුණුම්)</span>
          </button>

          {/* 2. PRODUCTS & DISCOUNTS TAB (POSITION #3) */}
          <button
            onClick={() => setActiveTab('products')}
            className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-extrabold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'products'
                ? 'bg-emerald-600 text-white shadow-lg ring-2 ring-emerald-400/50'
                : 'bg-emerald-950/70 text-emerald-300 hover:text-white hover:bg-emerald-900/80 border border-emerald-600/70'
            }`}
          >
            <Package className="w-3.5 h-3.5 text-emerald-400" />
            <span>📦 Products & Discounts (භාණ්ඩ හා මිල)</span>
            <span className="text-[10px] bg-emerald-900 text-emerald-200 px-1.5 py-0.2 rounded-full font-bold">{products.length}</span>
          </button>

          {/* 2. INVENTORY / STOCK MANAGEMENT TAB (POSITION #3) */}
          <button
            onClick={() => setActiveTab('inventory')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'inventory' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-teal-400" />
            <span>📈 Stock & Inventory (තොග)</span>
          </button>

          {/* 3. PRICING STRUCTURE */}
          <button
            onClick={() => setActiveTab('pricing')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'pricing' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
            <span>💰 Pricing & Margins</span>
          </button>

          {/* 4. ORDERS TAB */}
          <button
            onClick={() => setActiveTab('orders')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'orders' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>🛒 Order Management</span>
            <span className="text-[10px] bg-slate-800 px-1.5 py-0.2 rounded-full text-slate-300">{orders.length}</span>
          </button>

          {/* STEP 7 */}
          <button
            onClick={() => setActiveTab('notifications')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'notifications'
                ? 'bg-amber-500 text-slate-950 font-black shadow-md ring-2 ring-amber-400/50'
                : 'bg-amber-950/70 text-amber-300 hover:text-white hover:bg-amber-900 border border-amber-700/80 font-bold'
            }`}
          >
            <Bell className="w-3.5 h-3.5 text-amber-400" />
            <span>🔔 STEP 7: SMS & WhatsApp</span>
          </button>

          {/* STEP 8 */}
          <button
            onClick={() => setActiveTab('pos-terminal')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'pos-terminal'
                ? 'bg-emerald-500 text-slate-950 font-black shadow-md ring-2 ring-emerald-400/50'
                : 'bg-emerald-950/70 text-emerald-300 hover:text-white hover:bg-emerald-900 border border-emerald-700/80 font-bold'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            <span>🏪 STEP 8: Shop POS</span>
          </button>

          {/* STEP 6 */}
          <button
            onClick={() => setActiveTab('delivery')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'delivery'
                ? 'bg-indigo-600 text-white font-black shadow-md ring-2 ring-indigo-400/50'
                : 'bg-indigo-950/70 text-indigo-300 hover:text-white hover:bg-indigo-900 border border-indigo-700/80 font-bold'
            }`}
          >
            <Truck className="w-3.5 h-3.5 text-indigo-400" />
            <span>🚚 STEP 6: Delivery</span>
          </button>

          <button
            onClick={() => setActiveTab('sync-flow')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'sync-flow' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5 text-amber-300" />
            <span>🔄 Sync Engine</span>
          </button>

          <button
            onClick={() => setActiveTab('reorder')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'reorder' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>⚠️ Low Stock</span>
            {reorderList.length > 0 && (
              <span className="text-[10px] bg-amber-500 text-slate-950 font-extrabold px-1.5 py-0.2 rounded-full">
                {reorderList.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('customers')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              activeTab === 'customers' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>👥 Customers</span>
            <span className="text-[10px] bg-slate-800 px-1.5 py-0.2 rounded-full text-slate-300">{customers.length}</span>
          </button>
        </div>
      </div>

      {/* Main Content Body */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-8 space-y-6">
        {restockNotice && (
          <div className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-200 text-xs flex items-center gap-2 font-bold animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{restockNotice}</span>
          </div>
        )}

        {/* ================= 1. ADMIN DASHBOARD V1 ================= */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            {/* Products, Stock & Discounts Main Action Card */}
            <div className="bg-gradient-to-r from-emerald-950/90 via-slate-900 to-teal-950/90 border-2 border-emerald-500 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/50 shadow-inner">
                    <Package className="w-7 h-7" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-black text-base sm:text-lg text-white">
                        {isSi ? 'භාණ්ඩ, තොග හා මිල කළමනාකරණය' : 'Product & Stock Management'}
                      </h3>
                      <span className="text-[10px] bg-emerald-500 text-slate-950 font-black px-2 py-0.5 rounded-full">
                        {products.length} Products Active
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-0.5">
                      {isSi
                        ? 'අලුතින් භාණ්ඩ එක්කරන්න, මිල වෙනස් කරන්න, Discounts (රුපියල් අඩු කිරීම්) දමන්න සහ Stock කළමනාකරණය කරන්න.'
                        : 'Add new items, change selling prices, apply rupee discounts, and manage real-time inventory.'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5 flex-wrap">
                  <button
                    onClick={() => {
                      setActiveTab('products');
                      openNewProduct();
                    }}
                    className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black text-xs sm:text-sm rounded-xl shadow-lg shadow-emerald-500/25 cursor-pointer transition-all active:scale-95"
                  >
                    <Plus className="w-4 h-4 text-slate-950" />
                    <span>{isSi ? '+ නව භාණ්ඩයක් එක්කරන්න' : '+ Add New Product'}</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('products')}
                    className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-750 text-emerald-300 font-bold text-xs sm:text-sm rounded-xl border border-emerald-700/80 cursor-pointer transition-colors"
                  >
                    <Package className="w-4 h-4" />
                    <span>{isSi ? 'භාණ්ඩ හා Discounts කළමනාකරණය ➔' : 'Manage Products & Discounts ➔'}</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('inventory')}
                    className="flex items-center gap-2 px-3.5 py-2.5 bg-slate-800 hover:bg-slate-750 text-teal-300 font-bold text-xs rounded-xl border border-teal-700/80 cursor-pointer transition-colors"
                  >
                    <Layers className="w-4 h-4" />
                    <span>{isSi ? 'තොග බලන්න (Stock) ➔' : 'Stock Breakdown ➔'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Sales Reports & Day-End Cash Balance Quick Launch Card */}
            <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border-2 border-amber-500/70 rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/40">
                    <BarChart3 className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-black text-base sm:text-lg text-white">
                        {isSi ? 'දවසේ අවසාන මුදල් ශේෂය සහ විකුණුම් වාර්තා (Sales & Cash Reports)' : 'Day-End Cash Balance & Sales Reports (Z-Report)'}
                      </h3>
                      <span className="text-[10px] bg-amber-500 text-slate-950 font-black px-2 py-0.5 rounded-full">
                        Automated Z-Report
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 mt-0.5">
                      {isSi
                        ? 'දවස අවසානයේ ලාච්චුවේ තිබිය යුතු Cash Balance එක, අද දවසේ මුළු විකිණුම, මාසික විකුණුම් හා මුදල් නෝට්ටු ගණනය කිරීම.'
                        : 'Day-end drawer cash reconciliation, daily gross sales, monthly analytics & physical denomination counting.'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <button
                    onClick={() => setActiveTab('sales-reports')}
                    className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-xs sm:text-sm rounded-xl shadow-lg shadow-amber-500/20 cursor-pointer transition-all active:scale-95"
                  >
                    <BarChart3 className="w-4 h-4 text-slate-950" />
                    <span>{isSi ? '📑 වාර්තා සහ Z-Report බලන්න ➔' : '📑 View Sales & Cash Reports ➔'}</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Steps 6, 7, 8 Prominent Quick Launch Cards */}
            <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-amber-500/40 rounded-3xl p-5 shadow-xl space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <h3 className="font-extrabold text-sm text-white">
                    {isSi ? 'ප්‍රධාන මොඩියුල වෙත සෘජු ප්‍රවේශය (Steps 6, 7 & 8 Direct Access)' : 'Core Project Modules (Steps 6, 7 & 8)'}
                  </h3>
                </div>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-mono font-bold">
                  Click any card to open
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {/* Step 7 Card */}
                <div
                  onClick={() => setActiveTab('notifications')}
                  className="bg-slate-900 hover:bg-slate-800 border-2 border-amber-500 hover:border-amber-400 p-4 rounded-2xl cursor-pointer transition-all space-y-1.5 group shadow-lg shadow-amber-500/10"
                >
                  <div className="flex items-center justify-between text-amber-300">
                    <div className="flex items-center gap-2 font-black text-xs">
                      <Bell className="w-4 h-4 animate-bounce" />
                      <span>🔔 STEP 7</span>
                    </div>
                    <span className="text-xs group-hover:translate-x-1 transition-transform font-bold text-amber-400">Open Tab ➔</span>
                  </div>
                  <h4 className="font-bold text-white text-xs">WhatsApp & SMS Order Notifications</h4>
                  <p className="text-[11px] text-slate-300">
                    {isSi ? 'පාරිභෝගිකයාට සහ Hotline 0774778190 වෙත ක්ෂණික Alert Dispatcher සහ Live Stream.' : 'Live alert stream, test dispatcher to 0774778190 & templates.'}
                  </p>
                </div>

                {/* Step 8 Card */}
                <div
                  onClick={() => setActiveTab('pos-terminal')}
                  className="bg-slate-900 hover:bg-slate-800 border-2 border-emerald-500/70 hover:border-emerald-400 p-4 rounded-2xl cursor-pointer transition-all space-y-1.5 group shadow-lg shadow-emerald-500/10"
                >
                  <div className="flex items-center justify-between text-emerald-400">
                    <div className="flex items-center gap-2 font-black text-xs">
                      <Store className="w-4 h-4" />
                      <span>🏪 STEP 8</span>
                    </div>
                    <span className="text-xs group-hover:translate-x-1 transition-transform font-bold text-emerald-400">Open Tab ➔</span>
                  </div>
                  <h4 className="font-bold text-white text-xs">Physical Shop POS Register</h4>
                  <p className="text-[11px] text-slate-300">
                    {isSi ? 'Barcode Scanner, කවුන්ටර මුදල් කැල්කියුලේටරය සහ Thermal Receipt.' : 'Barcode scanner simulator, cash change calculator & ESC/POS receipts.'}
                  </p>
                </div>

                {/* Step 6 Card */}
                <div
                  onClick={() => setActiveTab('delivery')}
                  className="bg-slate-900 hover:bg-slate-800 border-2 border-indigo-500/70 hover:border-indigo-400 p-4 rounded-2xl cursor-pointer transition-all space-y-1.5 group shadow-lg shadow-indigo-500/10"
                >
                  <div className="flex items-center justify-between text-indigo-400">
                    <div className="flex items-center gap-2 font-black text-xs">
                      <Truck className="w-4 h-4" />
                      <span>🚚 STEP 6</span>
                    </div>
                    <span className="text-xs group-hover:translate-x-1 transition-transform font-bold text-indigo-400">Open Tab ➔</span>
                  </div>
                  <h4 className="font-bold text-white text-xs">Delivery Areas & Fee System</h4>
                  <p className="text-[11px] text-slate-300">
                    {isSi ? 'ප්‍රදේශ අනුව ගාස්තු, Free Delivery සීමාවන් සහ නගර පාලනය.' : 'Zones, delivery fees, free delivery rules & covered towns.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Top KPI Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div
                onClick={() => setActiveTab('sales-reports')}
                className="bg-slate-900/90 hover:bg-slate-850 border border-slate-800 hover:border-emerald-500/60 rounded-3xl p-5 space-y-2 cursor-pointer transition-all group"
                title="Click to view full sales reports & cash reconciliation"
              >
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
                  <span>TOTAL SALES REVENUE</span>
                  <div className="flex items-center gap-1 text-emerald-400 group-hover:translate-x-0.5 transition-transform">
                    <span className="text-[10px] font-bold">Reports ➔</span>
                    <DollarSign className="w-4 h-4 text-emerald-400" />
                  </div>
                </div>
                <div className="text-2xl font-black text-white">
                  Rs. {totalRevenue.toLocaleString()}
                </div>
                <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800">
                  <span>Shop POS: Rs. {posSalesRevenue.toLocaleString()}</span>
                  <span>Online: Rs. {onlineWebRevenue.toLocaleString()}</span>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-2">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
                  <span>PENDING ORDERS</span>
                  <ShoppingBag className="w-4 h-4 text-amber-400" />
                </div>
                <div className="text-2xl font-black text-amber-300">
                  {pendingOrdersCount} orders
                </div>
                <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800">
                  <span>Out for Delivery: {outForDeliveryCount}</span>
                  <span>Total: {orders.length}</span>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-2">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
                  <span>INVENTORY ASSET VALUE</span>
                  <Package className="w-4 h-4 text-teal-400" />
                </div>
                <div className="text-2xl font-black text-white">
                  Rs. {totalRetailValuation.toLocaleString()}
                </div>
                <div className="text-[11px] text-emerald-400 flex items-center justify-between pt-1 border-t border-slate-800">
                  <span>Est. Cost: Rs. {totalCostValuation.toLocaleString()}</span>
                  <span>Margin: +Rs. {potentialProfitValuation.toLocaleString()}</span>
                </div>
              </div>

              <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-2">
                <div className="flex items-center justify-between text-slate-400 text-xs font-semibold">
                  <span>LOW-STOCK WARNINGS</span>
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                </div>
                <div className="text-2xl font-black text-rose-400">
                  {reorderList.length} items
                </div>
                <div className="text-[11px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800">
                  <span>Total SKU count: {products.length}</span>
                  <button onClick={() => setActiveTab('reorder')} className="text-amber-400 hover:underline">
                    View POs ➔
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Actions & Fast-Moving Items Section */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              {/* Fast-Moving Items Ranking */}
              <div className="lg:col-span-7 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-emerald-400" />
                    <h3 className="font-bold text-white text-sm">
                      {isSi ? 'වැඩිපුරම අලෙවි වන භාණ්ඩ (Fast-Moving Essentials)' : 'Top Fast-Moving Groceries'}
                    </h3>
                  </div>
                  <span className="text-xs text-slate-400 font-mono">By Units Sold</span>
                </div>

                <div className="space-y-3">
                  {[...products]
                    .sort((a, b) => (b.soldCount || 0) - (a.soldCount || 0))
                    .slice(0, 5)
                    .map((item, idx) => {
                      const maxSold = 120;
                      const percentage = Math.min(100, Math.round(((item.soldCount || 0) / maxSold) * 100));

                      return (
                        <div key={item.id} className="p-3 bg-slate-800/60 rounded-2xl border border-slate-700/60 space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2.5">
                              <span className="w-6 h-6 rounded-full bg-slate-700 text-slate-300 font-bold flex items-center justify-center text-[10px]">
                                #{idx + 1}
                              </span>
                              <span className="font-bold text-white">{isSi ? item.nameSi : item.name}</span>
                              <span className="text-[10px] text-slate-400">({item.unit})</span>
                            </div>
                            <div className="text-right">
                              <span className="font-extrabold text-emerald-400">{item.soldCount || 0} sold</span>
                              <span className="text-[10px] text-slate-400 block">Stock: {item.stock}</span>
                            </div>
                          </div>
                          <div className="w-full bg-slate-700/50 rounded-full h-1.5 overflow-hidden">
                            <div
                              className="bg-gradient-to-r from-emerald-500 to-teal-400 h-1.5 rounded-full"
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>

              {/* Omnichannel POS Quick Launcher & Status */}
              <div className="lg:col-span-5 bg-slate-900/80 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-amber-300">
                    <Zap className="w-5 h-5" />
                    <h3 className="font-bold text-white text-sm">
                      {isSi ? 'කඩේ සජීවී POS කවුන්ටරය' : 'Physical Shop POS Quick Register'}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    {isSi
                      ? 'කඩේ කවුන්ටරයෙන් සෘජුවම Walk-in පාරිභෝගිකයින්ට භාණ්ඩ විකිණීම සිදුකරන්න. තොගය ක්ෂණිකව වෙබ් එකේ හා ඇප් එකේ අඩු වේ.'
                      : 'Process in-store walk-in cash sales directly from this counter register. Live stock syncs across online channels immediately.'}
                  </p>

                  <div className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 space-y-3 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300 font-semibold">Araliya Keeri Samba (5kg)</span>
                      <span className="font-black text-emerald-400 text-sm">
                        {products.find((p) => p.id === 'prod-rice-keeri-5kg')?.stock ?? 20} in stock
                      </span>
                    </div>

                    <button
                      onClick={() => setActiveTab('sync-flow')}
                      className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>{isSi ? 'සජීවී Sync Simulator එක බලන්න' : 'Open Sync Architecture Simulator'}</span>
                    </button>
                  </div>
                </div>

                <div className="p-3 bg-emerald-950/40 rounded-2xl border border-emerald-800/60 text-xs text-emerald-300 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Real-time ACID lock active: prevents overselling between in-store & web.</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ================= 2. SHOP ➔ WEB ➔ APP SINGLE DB SYSTEM FLOW ================= */}
        {activeTab === 'sync-flow' && (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-xl">
              <div className="max-w-3xl space-y-2">
                <div className="inline-flex items-center gap-2 bg-amber-950/80 border border-amber-600/40 text-amber-300 text-xs font-bold px-3 py-1 rounded-full">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{isSi ? 'අපේ පද්ධතියේ වැදගත්ම Point එක' : 'Unified Omnichannel Database Core'}</span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  Physical Shop ↔ Website ↔ Mobile App: 1 Single Database
                </h2>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {isSi ? (
                    <>
                      අපි website එක වෙනම system එකක් කරන්නේ නැහැ.
                      Shop එකේ customer කෙනෙක් Rice 5kg එකක් ගත්තා → <strong className="text-amber-300">stock 20 → 19</strong>.
                      Website order එකක් ආවා → <strong className="text-amber-300">stock 19 → 18</strong>.
                      App එකෙන් order එකක් ආවා → <strong className="text-amber-300">stock 18 → 17</strong>.
                    </>
                  ) : (
                    <>
                      All 3 sales channels share one centralized inventory table. Walk-in cashier checkout, web cart checkout, and mobile app ordering decrement the exact same live inventory lock simultaneously.
                    </>
                  )}
                </p>
              </div>

              {/* Interactive Architecture Flow Diagram */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative pt-2">
                {/* Channel 1: Physical Shop POS */}
                <div className="bg-slate-800/90 border border-amber-500/40 rounded-2xl p-4 text-center space-y-2 shadow-lg">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 mx-auto flex items-center justify-center">
                    <Store className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-white text-sm">1. Physical Shop POS</h4>
                  <p className="text-[11px] text-slate-400">Cashier Counter Register (Maharagama)</p>
                  <span className="text-[10px] bg-amber-950 text-amber-300 font-bold px-2 py-0.5 rounded-full border border-amber-800 block">
                    Cash on Counter Sale
                  </span>
                </div>

                {/* Channel 2: Online Website */}
                <div className="bg-slate-800/90 border border-emerald-500/40 rounded-2xl p-4 text-center space-y-2 shadow-lg">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center">
                    <ShoppingBag className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-white text-sm">2. Online Website</h4>
                  <p className="text-[11px] text-slate-400">LankaMart Customer Web Portal</p>
                  <span className="text-[10px] bg-emerald-950 text-emerald-300 font-bold px-2 py-0.5 rounded-full border border-emerald-800 block">
                    Web Cart & COD Order
                  </span>
                </div>

                {/* Channel 3: Mobile App */}
                <div className="bg-slate-800/90 border border-teal-500/40 rounded-2xl p-4 text-center space-y-2 shadow-lg">
                  <div className="w-12 h-12 rounded-2xl bg-teal-500/20 text-teal-400 mx-auto flex items-center justify-center">
                    <Zap className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-white text-sm">3. Mobile App Client</h4>
                  <p className="text-[11px] text-slate-400">Android / iOS App Notifications</p>
                  <span className="text-[10px] bg-teal-950 text-teal-300 font-bold px-2 py-0.5 rounded-full border border-teal-800 block">
                    App 1-Click Checkout
                  </span>
                </div>
              </div>

              {/* Center Core Database Box */}
              <div className="bg-slate-900 border-2 border-emerald-500/80 rounded-3xl p-6 text-center space-y-4 shadow-2xl relative overflow-hidden">
                <div className="flex items-center justify-center gap-2 text-emerald-400">
                  <Layers className="w-5 h-5 animate-pulse" />
                  <span className="font-black text-sm uppercase tracking-wider">
                    CENTRAL UNIFIED ENGINE: `lankamart_products_v2`
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-2xl mx-auto text-left">
                  <div className="bg-slate-800 p-3 rounded-xl border border-slate-700">
                    <span className="text-[10px] text-slate-400 block uppercase">Target Product</span>
                    <span className="font-bold text-white text-xs">Araliya Keeri Samba (5kg)</span>
                  </div>
                  <div className="bg-slate-800 p-3 rounded-xl border border-slate-700">
                    <span className="text-[10px] text-slate-400 block uppercase">Current Stock</span>
                    <span className="font-black text-emerald-400 text-base">
                      {products.find((p) => p.id === 'prod-rice-keeri-5kg')?.stock ?? 20} units
                    </span>
                  </div>
                  <div className="bg-slate-800 p-3 rounded-xl border border-slate-700">
                    <span className="text-[10px] text-slate-400 block uppercase">Lock Status</span>
                    <span className="font-bold text-amber-300 text-xs">Atomic Auto-Sync ⚡</span>
                  </div>
                </div>

                {/* 1-Click Interactive Test Button */}
                <div className="pt-2">
                  <button
                    onClick={handleRunTripleSync}
                    className="px-6 py-3 bg-gradient-to-r from-amber-500 via-emerald-600 to-teal-500 hover:from-amber-400 hover:to-teal-400 text-slate-950 font-black text-xs sm:text-sm rounded-2xl shadow-xl shadow-emerald-500/20 cursor-pointer transition-all active:scale-[0.98] inline-flex items-center gap-2"
                  >
                    <RefreshCw className="w-4 h-4 text-slate-950" />
                    <span>🔥 {isSi ? '3-Channel Simultaneous Order Test එක Run කරන්න' : 'Run 3-Channel Simultaneous Order Simulation'}</span>
                  </button>
                </div>

                {/* Live Simulation Output Card */}
                {syncSimulationResult && (
                  <div className="mt-4 p-4 bg-slate-950 border border-emerald-500/60 rounded-2xl text-left text-xs space-y-2 animate-in fade-in">
                    <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                      <span className="font-bold text-emerald-400">Simulation Run Result (Araliya Keeri Samba 5kg):</span>
                      <span className="text-slate-400 text-[10px] font-mono">Timestamp: {new Date().toLocaleTimeString()}</span>
                    </div>
                    <div className="grid grid-cols-4 gap-2 text-center pt-1 font-mono">
                      <div className="bg-slate-900 p-2 rounded-lg">
                        <span className="text-slate-500 text-[10px] block">Initial</span>
                        <span className="font-bold text-white text-base">{syncSimulationResult.initialStock}</span>
                      </div>
                      <div className="bg-amber-950/60 p-2 rounded-lg border border-amber-800/60">
                        <span className="text-amber-400 text-[10px] block">1. Shop POS</span>
                        <span className="font-bold text-amber-300 text-base">{syncSimulationResult.afterShop}</span>
                      </div>
                      <div className="bg-emerald-950/60 p-2 rounded-lg border border-emerald-800/60">
                        <span className="text-emerald-400 text-[10px] block">2. Web Order</span>
                        <span className="font-bold text-emerald-300 text-base">{syncSimulationResult.afterWeb}</span>
                      </div>
                      <div className="bg-teal-950/60 p-2 rounded-lg border border-teal-800/60">
                        <span className="text-teal-400 text-[10px] block">3. Mobile App</span>
                        <span className="font-bold text-teal-300 text-base">{syncSimulationResult.afterApp}</span>
                      </div>
                    </div>
                    <p className="text-[11px] text-emerald-300 text-center pt-1 font-semibold">
                      ✅ Exactly matched: {syncSimulationResult.initialStock} ➔ {syncSimulationResult.afterShop} ➔ {syncSimulationResult.afterWeb} ➔ {syncSimulationResult.afterApp}. Out-of-stock discrepancies completely prevented!
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* POS Cashier Register Panel */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-4">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <Store className="w-4 h-4 text-emerald-400" />
                <span>{isSi ? 'භෞතික කවුන්ටරයෙන් සෘජු විකිණීම (Counter Cashier)' : 'Physical Counter Cash Sale Simulator'}</span>
              </h3>

              {posFeedback && (
                <div
                  className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                    posFeedback.type === 'success'
                      ? 'bg-emerald-950 border border-emerald-600 text-emerald-200'
                      : 'bg-rose-950 border border-rose-600 text-rose-200'
                  }`}
                >
                  {posFeedback.type === 'success' ? <CheckCircle2 className="w-4 h-4" /> : <AlertTriangle className="w-4 h-4" />}
                  <span>{posFeedback.message}</span>
                </div>
              )}

              <form onSubmit={handlePerformPosSale} className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <div className="sm:col-span-2">
                  <label className="block text-slate-400 mb-1">Product</label>
                  <select
                    value={posSelectedProductId}
                    onChange={(e) => setPosSelectedProductId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none"
                  >
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} (Stock: {p.stock} | Rs. {p.price})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">Qty</label>
                  <input
                    type="number"
                    min={1}
                    value={posQuantity}
                    onChange={(e) => setPosQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none font-bold"
                  />
                </div>

                <div className="flex items-end">
                  <button
                    type="submit"
                    className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl cursor-pointer shadow-md"
                  >
                    Complete POS Sale
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ================= 3. PRODUCT MANAGEMENT STRUCTURE ================= */}
        {activeTab === 'products' && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by SKU, Barcode, Name, Brand..."
                  className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:border-emerald-500 outline-none"
                />
              </div>

              <button
                onClick={openNewProduct}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>{isSi ? 'නව භාණ්ඩයක් එක්කරන්න' : 'Add New Product'}</span>
              </button>
            </div>

            {/* Products Data Grid */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-bold tracking-wider">
                    <tr>
                      <th className="p-3.5">SKU & Photo</th>
                      <th className="p-3.5">Product Name</th>
                      <th className="p-3.5">Category & Brand</th>
                      <th className="p-3.5">Retail / Wholesale</th>
                      <th className="p-3.5">Cost Price</th>
                      <th className="p-3.5">Margin %</th>
                      <th className="p-3.5">Total Stock</th>
                      <th className="p-3.5">Shelf / Backstore</th>
                      <th className="p-3.5 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {filteredProducts.map((p) => {
                      const isLow = p.stock <= p.minStockAlert;
                      return (
                        <tr key={p.id} className="hover:bg-slate-850 transition-colors">
                          <td className="p-3.5">
                            <div className="flex items-center gap-2.5">
                              <img src={p.image} alt={p.name} className="w-10 h-10 rounded-xl object-cover shrink-0" />
                              <div>
                                <span className="font-mono text-[10px] text-emerald-400 font-bold block">{p.sku}</span>
                                <span className="text-[10px] text-slate-500 font-mono">{p.barcode}</span>
                              </div>
                            </div>
                          </td>
                          <td className="p-3.5">
                            <p className="font-bold text-white line-clamp-1">{p.name}</p>
                            <p className="text-[11px] text-slate-400">{p.nameSi} • ({p.unit})</p>
                          </td>
                          <td className="p-3.5">
                            <span className="font-semibold text-slate-200 block">{p.brand}</span>
                            <span className="text-[10px] text-slate-400">{p.category}</span>
                          </td>
                          <td className="p-3.5">
                            {p.originalPrice && p.originalPrice > p.price && (
                              <span className="text-[10px] text-slate-400 line-through block">
                                MRP: Rs. {p.originalPrice.toLocaleString()} (-{Math.round(((p.originalPrice - p.price) / p.originalPrice) * 100)}%)
                              </span>
                            )}
                            <span className="font-bold text-white block">Rs. {p.price.toLocaleString()}</span>
                            <span className="text-[10px] text-emerald-400 font-semibold">
                              Bulk: Rs. {p.wholesalePrice.toLocaleString()} ({p.wholesaleMinQty}+)
                            </span>
                          </td>
                          <td className="p-3.5 text-slate-300 font-mono">
                            Rs. {p.costPrice.toLocaleString()}
                          </td>
                          <td className="p-3.5 font-bold text-emerald-400">
                            {p.profitMarginPercent ?? (((p.price - p.costPrice) / p.price) * 100).toFixed(1)}%
                          </td>
                          <td className="p-3.5">
                            <span className={`font-black text-sm ${isLow ? 'text-amber-400' : 'text-emerald-400'}`}>
                              {p.stock}
                            </span>
                            {isLow && (
                              <span className="text-[9px] bg-amber-950 text-amber-300 px-1.5 py-0.2 rounded ml-1.5 font-bold">
                                Low
                              </span>
                            )}
                          </td>
                          <td className="p-3.5 text-[11px] text-slate-400">
                            <span>Shelf: <strong className="text-white">{p.shelfStock || 0}</strong></span>
                            <span className="mx-1">•</span>
                            <span>Back: <strong className="text-white">{p.backstoreStock || 0}</strong></span>
                          </td>
                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => openEditProduct(p)}
                                className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white cursor-pointer"
                                title="Edit"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteProduct(p.id)}
                                className="p-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900 text-rose-300 cursor-pointer"
                                title="Delete"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ================= 4. PRICING STRUCTURE ================= */}
        {activeTab === 'pricing' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-3">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>Multi-Tier Pricing Engine: Retail, Wholesale & Margin Breakdown</span>
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                {isSi
                  ? 'පාරිභෝගිකයාට තනි අයිතමයක් (Retail Price) ලෙස හෝ බහුල ප්‍රමාණයක් මිලදී ගැනීමේදී තොග මිල (Wholesale Price) ස්වයංක්‍රීයව කරත්තයේදී සක්‍රීය වේ.'
                  : 'Automated wholesale tier rule: Whenever a customer adds items equal to or greater than the Wholesale Threshold (e.g. 3 or 5 units), the bulk discounted price activates immediately.'}
              </p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-bold tracking-wider">
                    <tr>
                      <th className="p-3.5">Product SKU & Name</th>
                      <th className="p-3.5">Procurement Cost</th>
                      <th className="p-3.5">Standard Retail Price</th>
                      <th className="p-3.5">Wholesale Price (Tier 1)</th>
                      <th className="p-3.5">Wholesale Min Qty</th>
                      <th className="p-3.5">Retail Gross Margin</th>
                      <th className="p-3.5">Wholesale Margin</th>
                      <th className="p-3.5 text-right">Quick Edit</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {products.map((p) => {
                      const retailProfit = p.price - p.costPrice;
                      const retailMargin = Number(((retailProfit / p.price) * 100).toFixed(1));
                      const wholesaleProfit = p.wholesalePrice - p.costPrice;
                      const wholesaleMargin = Number(((wholesaleProfit / p.wholesalePrice) * 100).toFixed(1));

                      return (
                        <tr key={p.id} className="hover:bg-slate-850">
                          <td className="p-3.5">
                            <span className="font-bold text-white block">{p.name}</span>
                            <span className="font-mono text-[10px] text-slate-500">{p.sku}</span>
                          </td>
                          <td className="p-3.5 font-mono text-slate-300">
                            Rs. {p.costPrice.toLocaleString()}
                          </td>
                          <td className="p-3.5 font-bold text-white">
                            Rs. {p.price.toLocaleString()}
                          </td>
                          <td className="p-3.5 font-bold text-emerald-400">
                            Rs. {p.wholesalePrice.toLocaleString()}
                          </td>
                          <td className="p-3.5">
                            <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-bold text-[10px]">
                              {p.wholesaleMinQty} {p.unit}
                            </span>
                          </td>
                          <td className="p-3.5">
                            <span className="font-bold text-emerald-400">+{retailMargin}%</span>
                            <span className="text-[10px] text-slate-400 block">(Rs. {retailProfit})</span>
                          </td>
                          <td className="p-3.5">
                            <span className="font-bold text-teal-400">+{wholesaleMargin}%</span>
                            <span className="text-[10px] text-slate-400 block">(Rs. {wholesaleProfit})</span>
                          </td>
                          <td className="p-3.5 text-right">
                            <button
                              onClick={() => openEditProduct(p)}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-[11px] cursor-pointer"
                            >
                              Edit Price
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ================= 5. ORDER MANAGEMENT STRUCTURE ================= */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                {['all', 'new', 'confirmed', 'packing', 'out_for_delivery', 'delivered', 'cancelled'].map((st) => (
                  <button
                    key={st}
                    onClick={() => setOrderStatusFilter(st)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap cursor-pointer transition-colors ${
                      orderStatusFilter === st
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    {st === 'all' ? 'All Orders' : st.replace('_', ' ').toUpperCase()}
                  </button>
                ))}
              </div>

              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Filter by Order # or Customer..."
                  className="pl-8 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:border-emerald-500 outline-none"
                />
              </div>
            </div>

            {/* Orders Table */}
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-bold tracking-wider">
                    <tr>
                      <th className="p-3.5">Order # & Date</th>
                      <th className="p-3.5">Channel</th>
                      <th className="p-3.5">Customer & City</th>
                      <th className="p-3.5">Items Ordered</th>
                      <th className="p-3.5">Assigned Rider</th>
                      <th className="p-3.5">Total & Payment</th>
                      <th className="p-3.5">Status Pipeline</th>
                      <th className="p-3.5 text-right">Invoice</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {filteredOrders.map((o) => {
                      const badge = getStatusBadge(o.status, lang);
                      return (
                        <tr key={o.id} className="hover:bg-slate-850 transition-colors">
                          <td className="p-3.5 font-mono font-bold text-white">
                            #{o.orderNumber}
                            <span className="block text-[10px] font-sans text-slate-500 font-normal">
                              {new Date(o.createdAt).toLocaleDateString()} {new Date(o.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </td>
                          <td className="p-3.5">
                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                                o.channel === 'shop_pos'
                                  ? 'bg-amber-950 text-amber-300 border-amber-800'
                                  : o.channel === 'mobile_app'
                                  ? 'bg-teal-950 text-teal-300 border-teal-800'
                                  : 'bg-emerald-950 text-emerald-300 border-emerald-800'
                              }`}
                            >
                              {o.channel === 'shop_pos' ? 'Shop POS' : o.channel === 'mobile_app' ? 'Mobile App' : 'Online Web'}
                            </span>
                          </td>
                          <td className="p-3.5">
                            <span className="font-semibold text-white block">{o.customer.name}</span>
                            <span className="text-[11px] text-slate-400 block">{o.customer.phone}</span>
                            <span className="text-[10px] text-slate-500 block truncate max-w-[150px]">
                              {o.customer.city}
                            </span>
                          </td>
                          <td className="p-3.5">
                            <span className="font-bold text-slate-200">
                              {o.items.reduce((s, i) => s + i.quantity, 0)} items
                            </span>
                            <span className="text-[10px] text-slate-400 block truncate max-w-[170px]">
                              {o.items.map((i) => `${i.product.name} (x${i.quantity})`).join(', ')}
                            </span>
                          </td>
                          <td className="p-3.5">
                            {o.assignedRider ? (
                              <div className="text-[11px]">
                                <span className="font-bold text-white block">{o.assignedRider.name}</span>
                                <span className="text-[10px] text-slate-400">{o.assignedRider.vehicleNumber}</span>
                              </div>
                            ) : (
                              <select
                                onChange={(e) => {
                                  const rider = riders.find((r) => r.id === e.target.value);
                                  if (rider) {
                                    UnifiedStore.updateOrderStatus(o.id, o.status, `Assigned to ${rider.name}`, rider);
                                  }
                                }}
                                className="px-2 py-1 bg-slate-800 border border-slate-700 text-[10px] rounded-lg text-slate-300 outline-none"
                              >
                                <option value="">Assign Rider...</option>
                                {riders.map((r) => (
                                  <option key={r.id} value={r.id}>{r.name} ({r.agency})</option>
                                ))}
                              </select>
                            )}
                          </td>
                          <td className="p-3.5">
                            <span className="font-bold text-emerald-400 block">
                              Rs. {o.total.toLocaleString()}
                            </span>
                            <span className="text-[10px] uppercase font-semibold text-slate-400">
                              {o.paymentMethod} • <span className={o.paymentStatus === 'paid' ? 'text-emerald-400' : 'text-amber-400'}>{o.paymentStatus}</span>
                            </span>
                          </td>
                          <td className="p-3.5">
                            <select
                              value={o.status}
                              onChange={(e) => {
                                const newSt = e.target.value as OrderStatus;
                                UnifiedStore.updateOrderStatus(o.id, newSt, `Status updated to ${newSt}`);
                              }}
                              className="px-2 py-1 bg-slate-950 border border-slate-700 text-[11px] rounded-lg text-white font-semibold outline-none cursor-pointer focus:border-emerald-500"
                            >
                              <option value="new">New Order</option>
                              <option value="confirmed">Confirmed</option>
                              <option value="packing">Packing</option>
                              <option value="out_for_delivery">Out for Delivery</option>
                              <option value="delivered">Delivered</option>
                              <option value="cancelled">Cancelled (Restore Stock)</option>
                            </select>
                          </td>
                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {o.customer.phone && !o.customer.phone.includes('Counter') && (
                                <>
                                  <button
                                    onClick={() => {
                                      UnifiedStore.sendSmsNotification(
                                        o.customer.phone,
                                        o.orderNumber,
                                        `Status: ${o.status.toUpperCase()}`,
                                        `[LankaMart] Order #${o.orderNumber} update: Status is currently ${o.status.toUpperCase()}. Total: Rs. ${o.total.toLocaleString()}.`
                                      );
                                      alert(isSi ? `SMS යවන ලදී: ${o.customer.phone}` : `SMS dispatched to ${o.customer.phone}`);
                                    }}
                                    className="px-2 py-1 bg-blue-950 hover:bg-blue-900 text-blue-300 border border-blue-800 rounded-lg text-[10px] font-bold cursor-pointer"
                                    title="Send SMS"
                                  >
                                    SMS
                                  </button>
                                  <a
                                    href={`https://wa.me/94${o.customer.phone.replace(/[^0-9]/g, '').slice(-9)}?text=${encodeURIComponent(
                                      `*LankaMart Order #${o.orderNumber}*\nHello ${o.customer.name}, your order status is: *${o.status.toUpperCase()}*.\nTotal: Rs. ${o.total.toLocaleString()}`
                                    )}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="px-2 py-1 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-800 rounded-lg text-[10px] font-bold"
                                    title="Open WhatsApp"
                                  >
                                    WA
                                  </a>
                                </>
                              )}
                              <button
                                onClick={() => setViewingOrder(o)}
                                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-[11px] font-medium cursor-pointer"
                              >
                                Invoice
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ================= 6. STOCK / INVENTORY STRUCTURE ================= */}
        {activeTab === 'inventory' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5">
                <span className="text-xs text-slate-400 font-semibold block uppercase">TOTAL STORE STOCK</span>
                <span className="text-2xl font-black text-white">{totalStockCount} units</span>
                <p className="text-[11px] text-slate-500 mt-1">Available across display & stockrooms</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5">
                <span className="text-xs text-slate-400 font-semibold block uppercase">SHOP SHELF DISPLAY STOCK</span>
                <span className="text-2xl font-black text-amber-400">{totalShelfStock} units</span>
                <p className="text-[11px] text-slate-500 mt-1">Ready for walk-in grocery shoppers</p>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5">
                <span className="text-xs text-slate-400 font-semibold block uppercase">WAREHOUSE BACKSTORE</span>
                <span className="text-2xl font-black text-teal-400">{totalBackstoreStock} units</span>
                <p className="text-[11px] text-slate-500 mt-1">Buffer stock for web & app orders</p>
              </div>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl overflow-hidden shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] font-bold tracking-wider">
                    <tr>
                      <th className="p-3.5">SKU & Item</th>
                      <th className="p-3.5">Total Live Stock</th>
                      <th className="p-3.5">Shelf Display Stock</th>
                      <th className="p-3.5">Backstore Stock</th>
                      <th className="p-3.5">Safety Reorder Point</th>
                      <th className="p-3.5">Status Indicator</th>
                      <th className="p-3.5 text-right">Stock Calibration</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {products.map((p) => {
                      const isLow = p.stock <= p.minStockAlert;
                      return (
                        <tr key={p.id} className="hover:bg-slate-850">
                          <td className="p-3.5">
                            <span className="font-bold text-white block">{p.name}</span>
                            <span className="font-mono text-[10px] text-slate-400">{p.sku} • {p.unit}</span>
                          </td>
                          <td className="p-3.5 font-black text-sm text-white">
                            {p.stock} units
                          </td>
                          <td className="p-3.5 font-bold text-amber-300">
                            {p.shelfStock || 0}
                          </td>
                          <td className="p-3.5 font-bold text-teal-300">
                            {p.backstoreStock || 0}
                          </td>
                          <td className="p-3.5 text-slate-400 font-mono">
                            {p.minStockAlert} units
                          </td>
                          <td className="p-3.5">
                            {p.stock <= 0 ? (
                              <span className="px-2 py-0.5 rounded-full bg-rose-950 text-rose-300 border border-rose-800 text-[10px] font-bold">
                                Out of Stock
                              </span>
                            ) : isLow ? (
                              <span className="px-2 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-800 text-[10px] font-bold">
                                Low Stock ({p.stock} left)
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold">
                                Healthy Stock
                              </span>
                            )}
                          </td>
                          <td className="p-3.5 text-right">
                            <div className="flex items-center justify-end gap-1">
                              <button
                                onClick={() => UnifiedStore.updateStock(p.id, -1, 'manual_edit', 'Admin Inventory', 'Shelf check deduct (-1)')}
                                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-bold"
                                title="Minus 1"
                              >
                                -1
                              </button>
                              <button
                                onClick={() => UnifiedStore.updateStock(p.id, 5, 'restock', 'Admin Inventory', 'Restock (+5)')}
                                className="px-2 py-1 bg-emerald-900 hover:bg-emerald-800 text-emerald-200 rounded font-bold"
                                title="Restock +5"
                              >
                                +5
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ================= 7. LOW-STOCK & REORDER CONCEPT ================= */}
        {activeTab === 'reorder' && (
          <div className="space-y-6">
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-amber-400">
                  <AlertTriangle className="w-5 h-5" />
                  <h3 className="font-bold text-white text-sm">
                    {isSi ? 'ස්වයංක්‍රීය ප්‍රති-ඇණවුම් පද්ධතිය (Automated Reorder PO Sheet)' : 'Automated Reorder Purchase Order Engine'}
                  </h3>
                </div>
                <span className="text-xs bg-amber-950 text-amber-300 px-2.5 py-0.5 rounded-full font-bold border border-amber-800">
                  {reorderList.length} items needing restock
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {isSi
                  ? 'භාණ්ඩයක් නියමිත අවම සීමාවට (Reorder Point) ලඟා වූ විට සැපයුම්කරුට යැවීමට අවශ්‍ය Purchase Order පත්‍රිකාව හා WhatsApp පණිවිඩය මෙතැනින් ක්ෂණිකව සකස් වේ.'
                  : 'Whenever stock drops at or below its safe threshold, automated purchase orders are calculated using supplier lead days and standard batch sizes.'}
              </p>
            </div>

            {reorderList.length === 0 ? (
              <div className="p-12 text-center bg-slate-900/80 rounded-3xl border border-slate-800 space-y-2">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                <h4 className="font-bold text-white text-sm">All Stock Levels Healthy!</h4>
                <p className="text-xs text-slate-400">No items are currently below their minimum reorder point.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {reorderList.map((item) => {
                  const supplierMsg = encodeURIComponent(
                    `*🛒 LankaMart Purchase Order (PO)*\nTo: ${item.supplier.name}\n\nPlease dispatch restock batch:\n• Product: ${item.product.name} (${item.product.sku})\n• Quantity Needed: ${item.recommendedOrderQty} ${item.product.unit}\n• Expected Delivery: within ${item.supplier.leadTimeDays} days.\n\nThank you!\nLankaMart Maharagama Central Store`
                  );
                  const whatsappUrl = `https://wa.me/94${item.supplier.phone.replace(/[^0-9]/g, '').slice(-9)}?text=${supplierMsg}`;

                  return (
                    <div
                      key={item.product.id}
                      className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-lg hover:border-amber-500/50 transition-colors"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">
                            SKU: {item.product.sku}
                          </span>
                          <h4 className="font-bold text-white text-sm mt-0.5">{item.product.name}</h4>
                          <p className="text-[11px] text-slate-400">{item.product.nameSi}</p>
                        </div>
                        <span className="text-xs font-black text-rose-400 bg-rose-950/80 px-2 py-1 rounded-xl border border-rose-800">
                          {item.currentStock} left (Alert: &lt;{item.reorderLevel})
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-3 text-xs bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/80">
                        <div>
                          <span className="text-[10px] text-slate-400 block uppercase">Supplier Distributor</span>
                          <span className="font-bold text-white">{item.supplier.name}</span>
                          <span className="text-[10px] text-slate-400 block font-mono">{item.supplier.phone}</span>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block uppercase">Recommended PO</span>
                          <span className="font-bold text-emerald-400">+{item.recommendedOrderQty} {item.product.unit}</span>
                          <span className="text-[10px] text-slate-400 block">Est: Rs. {item.estimatedCost.toLocaleString()}</span>
                        </div>
                      </div>

                      <div className="flex gap-2">
                        {/* Direct WhatsApp PO link */}
                        <a
                          href={whatsappUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>Send PO via WhatsApp</span>
                        </a>

                        {/* 1-Click Fast Restock */}
                        <button
                          onClick={() => handleQuickRestock(item.product.id, item.recommendedOrderQty)}
                          className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-semibold cursor-pointer transition-colors"
                          title="Instant Restock"
                        >
                          + Receive Batch
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ================= 8. CUSTOMER DATABASE STRUCTURE ================= */}
        {activeTab === 'customers' && (
          <div className="space-y-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 space-y-2">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                <span>Customer Database & CRM Intelligence</span>
              </h3>
              <p className="text-xs text-slate-400">
                Tracks customer purchase history, delivery notes, loyalty points, and tier status.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {customers.map((c) => (
                <div key={c.id} className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-lg">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-bold text-white text-sm">{c.name}</h4>
                      <p className="text-xs text-slate-400 font-mono mt-0.5">{c.phone}</p>
                    </div>
                    <span
                      className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full border ${
                        c.tier === 'VIP'
                          ? 'bg-amber-950 text-amber-300 border-amber-600'
                          : c.tier === 'Gold'
                          ? 'bg-yellow-950 text-yellow-300 border-yellow-600'
                          : 'bg-slate-800 text-slate-300 border-slate-700'
                      }`}
                    >
                      {c.tier} Member
                    </span>
                  </div>

                  <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700 space-y-1 text-xs">
                    <div className="flex justify-between text-slate-300">
                      <span>Total Spent:</span>
                      <span className="font-black text-emerald-400">Rs. {c.totalSpent.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Orders Count:</span>
                      <span className="font-bold text-white">{c.ordersCount}</span>
                    </div>
                    <div className="flex justify-between text-slate-300">
                      <span>Loyalty Points:</span>
                      <span className="font-bold text-amber-400">{c.loyaltyPoints} pts</span>
                    </div>
                  </div>

                  <div className="text-xs space-y-1 text-slate-400">
                    <p className="flex items-start gap-1">
                      <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0 mt-0.5" />
                      <span>{c.address}, {c.city}</span>
                    </p>
                    {c.notes && <p className="italic text-slate-500 text-[11px]">Note: "{c.notes}"</p>}
                  </div>

                  {c.frequentItems && c.frequentItems.length > 0 && (
                    <div className="pt-2 border-t border-slate-800">
                      <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">Frequent Basket</span>
                      <div className="flex flex-wrap gap-1">
                        {c.frequentItems.map((fi, idx) => (
                          <span key={idx} className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md">
                            {fi}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ================= 9. DELIVERY STRUCTURE (STEP 6) ================= */}
        {activeTab === 'delivery' && (
          <DeliveryZonesManager lang={lang} zones={deliveryZones} riders={riders} />
        )}

        {/* ================= 10. NOTIFICATIONS DISPATCHER (STEP 7) ================= */}
        {activeTab === 'notifications' && (
          <NotificationsTab lang={lang} />
        )}

        {/* ================= 11. PHYSICAL SHOP POS TERMINAL (STEP 8) ================= */}
        {activeTab === 'pos-terminal' && (
          <PosTerminalTab lang={lang} products={products} />
        )}

        {/* ================= 12. AUTOMATED SALES & DAY-END CASH REPORTS ================= */}
        {activeTab === 'sales-reports' && (
          <SalesReportsTab lang={lang} orders={orders} products={products} />
        )}
      </div>

      {/* Product Add / Edit Modal */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-50 p-4 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-xl w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-base font-bold text-white">
              {editingProduct ? 'Edit Grocery Product' : 'Add New Grocery Product'}
            </h3>

            <form onSubmit={handleSaveProduct} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">SKU Code *</label>
                  <input
                    type="text"
                    required
                    value={productForm.sku || ''}
                    onChange={(e) => setProductForm({ ...productForm, sku: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none font-mono"
                    placeholder="e.g. RICE-ARA-5KG"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Barcode</label>
                  <input
                    type="text"
                    value={productForm.barcode || ''}
                    onChange={(e) => setProductForm({ ...productForm, barcode: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none font-mono"
                    placeholder="e.g. 479200100101"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Product Name (EN) *</label>
                  <input
                    type="text"
                    required
                    value={productForm.name || ''}
                    onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none"
                    placeholder="Araliya Keeri Samba (5kg)"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Product Name (SI) *</label>
                  <input
                    type="text"
                    required
                    value={productForm.nameSi || ''}
                    onChange={(e) => setProductForm({ ...productForm, nameSi: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none"
                    placeholder="අරලිය කීරි සම්බා සහල් (5kg)"
                  />
                </div>
              </div>

              {/* CATEGORY & FOLDER ASSIGNMENT BLOCK */}
              <div className="bg-slate-850 p-4 rounded-2xl border-2 border-emerald-500/50 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-black text-emerald-400 flex items-center gap-1.5">
                    <Folder className="w-4 h-4" />
                    <span>{isSi ? 'භාණ්ඩයේ කාණ්ඩය (Category Folder) *' : 'Category Folder *'}</span>
                  </label>
                  
                  <button
                    type="button"
                    onClick={() => setIsCreatingNewCat(!isCreatingNewCat)}
                    className="text-[11px] font-bold text-amber-300 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 px-2.5 py-1 rounded-lg border border-amber-500/30 flex items-center gap-1 cursor-pointer transition-colors"
                  >
                    <span>{isCreatingNewCat ? '✕ Cancel' : '+ අලුත් Category එකක් හදන්න'}</span>
                  </button>
                </div>

                {/* Inline New Category Creator Form */}
                {isCreatingNewCat ? (
                  <div className="p-3 bg-slate-900 rounded-xl border border-amber-500/60 space-y-2.5 animate-in fade-in">
                    <div className="flex items-center gap-2 text-amber-300 font-bold text-xs pb-1 border-b border-slate-800">
                      <span>✨ නව කාණ්ඩයක් (New Category Folder) එක්කරන්න:</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Name (English) *</label>
                        <input
                          type="text"
                          required
                          value={newCatName}
                          onChange={(e) => setNewCatName(e.target.value)}
                          placeholder="e.g. Frozen Foods"
                          className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs outline-none focus:border-amber-400"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Name (සිංහල) *</label>
                        <input
                          type="text"
                          required
                          value={newCatNameSi}
                          onChange={(e) => setNewCatNameSi(e.target.value)}
                          placeholder="e.g. ශීතකළ ආහාර"
                          className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs outline-none focus:border-amber-400"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] text-slate-400 block mb-0.5">Icon / Emoji</label>
                        <input
                          type="text"
                          value={newCatIcon}
                          onChange={(e) => setNewCatIcon(e.target.value)}
                          placeholder="e.g. 🧊"
                          className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs outline-none"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 block mb-0.5">Cover Image URL (Optional)</label>
                      <input
                        type="text"
                        value={newCatImage}
                        onChange={(e) => setNewCatImage(e.target.value)}
                        placeholder="https://images.unsplash.com/..."
                        className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs outline-none font-mono"
                      />
                    </div>
                    <div className="flex justify-end gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => setIsCreatingNewCat(false)}
                        className="px-3 py-1 bg-slate-800 text-slate-300 rounded-lg text-xs hover:bg-slate-700 cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="button"
                        onClick={handleAddNewCategory}
                        className="px-3.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs cursor-pointer shadow-md"
                      >
                        ✓ Add Category & Select
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Standard Category Selector Dropdown */
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] text-slate-300 font-bold mb-1">
                        {isSi ? 'පවතින Category එක තෝරන්න:' : 'Select Existing Category:'}
                      </label>
                      <select
                        required
                        value={productForm.category || ''}
                        onChange={(e) => {
                          const chosen = categories.find((c) => c.id === e.target.value);
                          setProductForm({
                            ...productForm,
                            category: e.target.value,
                            categorySi: chosen?.nameSi || '',
                            brand: chosen?.popularBrands?.[0] || productForm.brand || '',
                            subcategory: chosen?.subcategories?.[0]?.id || 'General'
                          });
                        }}
                        className="w-full px-3 py-2 bg-slate-800 border border-emerald-500 rounded-xl text-white outline-none font-bold text-xs shadow-inner"
                      >
                        {categories.map((c) => (
                          <option key={c.id} value={c.id}>
                            {c.icon} {c.nameSi} ({c.name})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] text-slate-400 mb-1">
                        {isSi ? 'වෙළඳ නාමය (Brand):' : 'Brand Name:'}
                      </label>
                      <input
                        type="text"
                        value={productForm.brand || ''}
                        onChange={(e) => setProductForm({ ...productForm, brand: e.target.value })}
                        className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none text-xs"
                        placeholder="e.g. Araliya, Nipuna, Anchor, Munchee"
                      />
                    </div>
                  </div>
                )}

                {/* Subcategory & Unit Selection */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      {isSi ? 'උප-වර්ගය (Subcategory / Variety):' : 'Subcategory / Variety:'}
                    </label>
                    {(() => {
                      const activeCatObj = categories.find((c) => c.id === productForm.category);
                      if (activeCatObj?.subcategories && activeCatObj.subcategories.length > 0) {
                        return (
                          <select
                            value={productForm.subcategory || ''}
                            onChange={(e) => setProductForm({ ...productForm, subcategory: e.target.value })}
                            className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none text-xs"
                          >
                            {activeCatObj.subcategories.map((sub) => (
                              <option key={sub.id} value={sub.id}>
                                {sub.nameSi} ({sub.name})
                              </option>
                            ))}
                            <option value="General">General / සාමාන්‍ය</option>
                          </select>
                        );
                      }
                      return (
                        <input
                          type="text"
                          value={productForm.subcategory || ''}
                          onChange={(e) => setProductForm({ ...productForm, subcategory: e.target.value })}
                          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none text-xs"
                          placeholder="e.g. White Rice, Powder, 1kg pack"
                        />
                      );
                    })()}
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      {isSi ? 'ඇසුරුමේ ප්‍රමාණය (Unit / Pack Size):' : 'Unit / Pack Size:'}
                    </label>
                    <input
                      type="text"
                      value={productForm.unit || ''}
                      onChange={(e) => setProductForm({ ...productForm, unit: e.target.value, unitSi: e.target.value })}
                      className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none text-xs"
                      placeholder="e.g. 5 kg bag, 1 kg pack, 400 g, 750 ml"
                    />
                  </div>
                </div>

                {/* Popular Brand Fast-Selection Chips if category has them */}
                {(() => {
                  const activeCatObj = categories.find((c) => c.id === productForm.category);
                  if (activeCatObj?.popularBrands && activeCatObj.popularBrands.length > 0) {
                    return (
                      <div className="flex items-center gap-1.5 flex-wrap pt-1 text-[11px] text-slate-400">
                        <span>🏷️ Fast Brands:</span>
                        {activeCatObj.popularBrands.map((b) => (
                          <button
                            key={b}
                            type="button"
                            onClick={() => setProductForm({ ...productForm, brand: b })}
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold border cursor-pointer transition-colors ${
                              productForm.brand === b
                                ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                                : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
                            }`}
                          >
                            {b}
                          </button>
                        ))}
                      </div>
                    );
                  }
                  return null;
                })()}
              </div>

              <div className="grid grid-cols-4 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Selling Price (Rs.) *</label>
                  <input
                    type="number"
                    required
                    value={productForm.price || ''}
                    onChange={(e) => setProductForm({ ...productForm, price: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">MRP / Strikethrough (Rs.)</label>
                  <input
                    type="number"
                    value={productForm.originalPrice || ''}
                    onChange={(e) => setProductForm({ ...productForm, originalPrice: e.target.value ? Number(e.target.value) : undefined })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-amber-300 outline-none"
                    placeholder="e.g. 1750"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Wholesale Price (Rs.)</label>
                  <input
                    type="number"
                    value={productForm.wholesalePrice || ''}
                    onChange={(e) => setProductForm({ ...productForm, wholesalePrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Cost Price (Rs.)</label>
                  <input
                    type="number"
                    value={productForm.costPrice || ''}
                    onChange={(e) => setProductForm({ ...productForm, costPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Total Stock *</label>
                  <input
                    type="number"
                    required
                    value={productForm.stock ?? ''}
                    onChange={(e) => setProductForm({ ...productForm, stock: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none font-bold text-emerald-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Shelf Display Stock</label>
                  <input
                    type="number"
                    value={productForm.shelfStock ?? ''}
                    onChange={(e) => setProductForm({ ...productForm, shelfStock: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Reorder Alert Point</label>
                  <input
                    type="number"
                    value={productForm.minStockAlert ?? ''}
                    onChange={(e) => setProductForm({ ...productForm, minStockAlert: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none"
                  />
                </div>
              </div>

              {/* Product Photo Uploader & Studio Background Remover */}
              <ProductImageStudioUploader
                lang={lang}
                imageUrl={productForm.image || ''}
                onChange={(newUrl) => setProductForm({ ...productForm, image: newUrl })}
                productName={productForm.name}
                category={productForm.category}
              />

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl cursor-pointer"
                >
                  Save Product
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Invoice Receipt Modal */}
      {viewingOrder && (
        <div className="fixed inset-0 z-50 p-4 bg-slate-950/80 backdrop-blur-xs flex items-center justify-center animate-in fade-in">
          <div className="bg-white text-slate-900 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="text-center border-b pb-3">
              <h3 className="font-black text-lg">LANKAMART SUPERSTORE</h3>
              <p className="text-xs text-slate-500">No. 128, High Level Road, Maharagama</p>
              <p className="text-xs text-slate-500">Tel: 077 477 8190 | orders@lankamart.lk</p>
            </div>

            <div className="text-xs space-y-1">
              <div className="flex justify-between">
                <span className="text-slate-500">Order ID:</span>
                <span className="font-mono font-bold">#{viewingOrder.orderNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date:</span>
                <span>{new Date(viewingOrder.createdAt).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Channel:</span>
                <span className="font-semibold uppercase">{viewingOrder.channel}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Customer:</span>
                <span className="font-semibold">{viewingOrder.customer.name} ({viewingOrder.customer.phone})</span>
              </div>
            </div>

            {(() => {
              const invoiceMRP = viewingOrder.items.reduce((sum, item) => {
                const orig = (item.product.originalPrice && item.product.originalPrice > item.unitPrice)
                  ? item.product.originalPrice
                  : item.unitPrice;
                return sum + orig * item.quantity;
              }, 0);
              const invoiceDiscount = Math.max(viewingOrder.discount || 0, Math.max(0, invoiceMRP - viewingOrder.subtotal));

              return (
                <>
                  <div className="border-t border-b py-2 text-xs space-y-1.5 max-h-48 overflow-y-auto">
                    {viewingOrder.items.map((item, idx) => {
                      const hasDiscount = item.product.originalPrice && item.product.originalPrice > item.unitPrice;
                      return (
                        <div key={idx} className="flex justify-between items-start">
                          <div>
                            <span className="font-medium text-slate-800">{item.product.name} × {item.quantity}</span>
                            {hasDiscount && (
                              <span className="block text-[10px] text-slate-500">
                                MRP <span className="line-through">Rs. {item.product.originalPrice?.toLocaleString()}</span> ➔ Rs. {item.unitPrice.toLocaleString()}
                              </span>
                            )}
                          </div>
                          <span className="font-semibold text-slate-900">Rs. {(item.unitPrice * item.quantity).toLocaleString()}</span>
                        </div>
                      );
                    })}
                  </div>

                  <div className="text-xs space-y-1.5 pt-1">
                    {invoiceDiscount > 0 && (
                      <div className="flex justify-between text-slate-500">
                        <span>Items Regular Total:</span>
                        <span className="line-through">Rs. {invoiceMRP.toLocaleString()}</span>
                      </div>
                    )}

                    {invoiceDiscount > 0 && (
                      <div className="flex justify-between text-emerald-700 font-bold bg-emerald-50 px-2 py-1 rounded-lg">
                        <span>🎉 Total Discount Received (වට්ටම):</span>
                        <span>-Rs. {invoiceDiscount.toLocaleString()}</span>
                      </div>
                    )}

                    <div className="flex justify-between text-slate-600">
                      <span>Subtotal:</span>
                      <span className="font-semibold">Rs. {viewingOrder.subtotal.toLocaleString()}</span>
                    </div>

                    <div className="flex justify-between text-slate-600">
                      <span>Delivery Fee:</span>
                      <span className="font-semibold">
                        {viewingOrder.deliveryFee === 0 ? 'FREE' : `Rs. ${viewingOrder.deliveryFee.toLocaleString()}`}
                      </span>
                    </div>

                    <div className="flex justify-between text-sm font-black pt-1.5 border-t">
                      <span>Grand Total:</span>
                      <span className="text-emerald-700 text-base">Rs. {viewingOrder.total.toLocaleString()}</span>
                    </div>

                    {invoiceDiscount > 0 && (
                      <div className="text-center py-1 bg-amber-50 border border-amber-200 rounded text-[11px] font-bold text-amber-800">
                        ⭐ Customer Saved Rs. {invoiceDiscount.toLocaleString()} on this bill!
                      </div>
                    )}
                  </div>
                </>
              );
            })()}

            <div className="pt-2 flex gap-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                🖨️ Print Invoice
              </button>
              <button
                onClick={() => setViewingOrder(null)}
                className="flex-1 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
