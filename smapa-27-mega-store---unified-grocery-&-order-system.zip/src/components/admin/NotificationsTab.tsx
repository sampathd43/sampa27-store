import React, { useState } from 'react';
import {
  Bell, MessageSquare, Send, CheckCircle2, Phone, ExternalLink,
  Smartphone, Clock, ShieldCheck, Sparkles, RefreshCw
} from 'lucide-react';
import { Language, NotificationLog } from '../../types';
import { UnifiedStore } from '../../services/store';

interface NotificationsTabProps {
  lang: Language;
}

export const NotificationsTab: React.FC<NotificationsTabProps> = ({ lang }) => {
  const isSi = lang === 'si';

  const [notifications, setNotifications] = useState<NotificationLog[]>(UnifiedStore.getNotifications());
  const [recipient, setRecipient] = useState('0774778190');
  const [notifType, setNotifType] = useState<'sms' | 'whatsapp'>('sms');
  const [selectedTemplate, setSelectedTemplate] = useState('confirmed');
  const [customMessage, setCustomMessage] = useState('');
  const [notice, setNotice] = useState<string | null>(null);

  const orders = UnifiedStore.getOrders();
  const sampleOrderNumber = orders[0]?.orderNumber || 'LK-8421';

  // Templates
  const templates: Record<string, { title: string; text: string }> = {
    confirmed: {
      title: 'Order Confirmed',
      text: `[SMAPA 27] Order #${sampleOrderNumber} confirmed! Total: Rs. 3,550. Our packaging team is packing your groceries fresh. Thank you for ordering with SMAPA 27 Mega Store.`
    },
    dispatched: {
      title: 'Out for Delivery',
      text: `[SMAPA 27] Rider Kasun Wickrama (077 345 6789, WP BCL-4821) is Out for Delivery with your order #${sampleOrderNumber}! Expected arrival: within 30-45 mins.`
    },
    delivered: {
      title: 'Delivered Successfully',
      text: `[SMAPA 27] Order #${sampleOrderNumber} has been delivered. Thank you for choosing SMAPA 27 Mega Store! Hotline: 077 477 8190.`
    },
    promotional: {
      title: 'Special Restock Offer',
      text: `[SMAPA 27] Fresh Araliya Keeri Samba 5kg & Nuwara Eliya Potatoes now restocked! Order today on SMAPA 27 Mega Store for same-day delivery.`
    }
  };

  const handleSendNotification = (e: React.FormEvent) => {
    e.preventDefault();
    const finalMsg = customMessage.trim() || templates[selectedTemplate].text;
    const title = templates[selectedTemplate]?.title || 'Order Update';

    if (notifType === 'sms') {
      UnifiedStore.sendSmsNotification(recipient, sampleOrderNumber, title, finalMsg);
      setNotice(isSi ? `SMS පණිවිඩය සාර්ථකව ${recipient} වෙත යවන ලදී!` : `SMS dispatched successfully to ${recipient}!`);
    } else {
      UnifiedStore.sendWhatsAppNotification(recipient, sampleOrderNumber, title, finalMsg);
      setNotice(isSi ? `WhatsApp පණිවිඩය සාර්ථකව ${recipient} වෙත යවන ලදී!` : `WhatsApp notification sent to ${recipient}!`);
      const waUrl = `https://wa.me/94${recipient.replace(/[^0-9]/g, '').slice(-9)}?text=${encodeURIComponent(finalMsg)}`;
      window.open(waUrl, '_blank');
    }

    setNotifications(UnifiedStore.getNotifications());
    setTimeout(() => setNotice(null), 3500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            <Bell className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white">
                {isSi ? 'ස්වයංක්‍රීය WhatsApp / SMS නිවේදන පද්ධතිය (Step 7)' : 'Automated WhatsApp & SMS Order Notification Engine'}
              </h2>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-800 font-bold">
                Gateway Connected
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {isSi
                ? 'ඇණවුම් තහවුරු වීම, රයිඩර් පිටත්වීම සහ භාණ්ඩ ලැබීම පිළිබඳව පාරිභෝගිකයාට සහ කඩේ WhatsApp අංක 0774778190 වෙත ක්ෂණික දැනුම්දීම්.'
                : 'Instant 2-way real-time alerts dispatched to customer and merchant WhatsApp (0774778190).'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-400">Total Alerts Dispatched:</span>
          <span className="font-mono font-bold text-emerald-400 text-sm">{notifications.length}</span>
        </div>
      </div>

      {notice && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-200 text-xs flex items-center gap-2 font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Grid: Dispatcher Form & Notification Logs Stream */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Test Dispatcher Form (Col 5) */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-800">
            <Smartphone className="w-4 h-4 text-emerald-400" />
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Send Manual / Test Notification
            </h3>
          </div>

          <form onSubmit={handleSendNotification} className="space-y-3 text-xs">
            <div>
              <label className="block text-slate-400 mb-1">Recipient Mobile Number *</label>
              <input
                type="tel"
                required
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder="0774778190"
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none font-mono"
              />
              <span className="text-[10px] text-slate-500 mt-0.5 block">Default: Shop Hotline (0774778190)</span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setNotifType('sms')}
                className={`py-2 rounded-xl font-bold cursor-pointer transition-all border ${
                  notifType === 'sms'
                    ? 'bg-emerald-600 text-white border-emerald-500 shadow-md'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                SMS Text Alert
              </button>
              <button
                type="button"
                onClick={() => setNotifType('whatsapp')}
                className={`py-2 rounded-xl font-bold cursor-pointer transition-all border ${
                  notifType === 'whatsapp'
                    ? 'bg-[#25D366] text-slate-950 border-[#25D366] shadow-md'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                WhatsApp Message
              </button>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Notification Template</label>
              <select
                value={selectedTemplate}
                onChange={(e) => setSelectedTemplate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none"
              >
                <option value="confirmed">1. Order Confirmed & Packing</option>
                <option value="dispatched">2. Out for Delivery (Rider Assigned)</option>
                <option value="delivered">3. Order Delivered Successfully</option>
                <option value="promotional">4. Grocery Restock Announcement</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-400 mb-1">Message Preview</label>
              <textarea
                rows={3}
                value={customMessage || templates[selectedTemplate]?.text}
                onChange={(e) => setCustomMessage(e.target.value)}
                className="w-full p-2.5 bg-slate-800 border border-slate-700 rounded-xl text-slate-200 outline-none text-xs leading-relaxed"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-md cursor-pointer flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              <span>Dispatch {notifType.toUpperCase()} Alert</span>
            </button>
          </form>
        </div>

        {/* Right: Live Stream of Dispatched Notifications (Col 7) */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                Live Notification Dispatch Stream
              </h3>
            </div>
            <button
              onClick={() => setNotifications(UnifiedStore.getNotifications())}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Refresh</span>
            </button>
          </div>

          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="py-12 text-center text-slate-500 text-xs">
                No notifications logged yet. Place an order or send a test alert!
              </div>
            ) : (
              notifications.map((n) => (
                <div
                  key={n.id}
                  className="p-3.5 bg-slate-800/80 rounded-2xl border border-slate-700/80 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase ${
                          n.type === 'sms'
                            ? 'bg-blue-950 text-blue-300 border border-blue-800'
                            : 'bg-[#25D366]/20 text-[#25D366] border border-[#25D366]/40'
                        }`}
                      >
                        {n.type}
                      </span>
                      <span className="font-bold text-white">{n.title}</span>
                      <span className="text-[10px] text-slate-400 font-mono">#{n.orderNumber}</span>
                    </div>

                    <span className="text-[10px] text-slate-400 font-mono">
                      {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <p className="text-slate-300 leading-relaxed bg-slate-900 p-2.5 rounded-xl border border-slate-800 font-mono text-[11px]">
                    {n.message}
                  </p>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                    <span>To: <strong className="text-white font-mono">{n.recipient}</strong></span>
                    <span className="text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                      <span>Delivered to Cellular Network</span>
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
