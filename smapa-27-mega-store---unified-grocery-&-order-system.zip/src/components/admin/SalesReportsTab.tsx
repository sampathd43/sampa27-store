import React, { useState, useMemo } from 'react';
import {
  TrendingUp, Calendar, DollarSign, CreditCard, ShoppingBag, Store,
  Printer, Download, Plus, Minus, CheckCircle2, AlertTriangle, ArrowUpRight,
  ArrowDownRight, Layers, FileText, Clock, RefreshCw, X, ShieldCheck,
  Eye, Search, ExternalLink
} from 'lucide-react';
import { Language, Order, Product } from '../../types';
import { UnifiedStore } from '../../services/store';

interface SalesReportsTabProps {
  lang: Language;
  orders: Order[];
  products: Product[];
  onViewOrder?: (order: Order) => void;
}

interface PettyExpense {
  id: string;
  timestamp: string;
  category: string;
  description: string;
  amount: number;
}

export const SalesReportsTab: React.FC<SalesReportsTabProps> = ({ lang, orders, products, onViewOrder }) => {
  const isSi = lang === 'si';

  // Selected Invoice to Review in Modal
  const [selectedInvoiceForReview, setSelectedInvoiceForReview] = useState<Order | null>(null);
  const [invoiceSearchQuery, setInvoiceSearchQuery] = useState<string>('');

  // Report Period Filter: 'today' | 'yesterday' | 'month' | 'last_month' | 'custom'
  const [reportPeriod, setReportPeriod] = useState<'today' | 'yesterday' | 'month' | 'last_month' | 'custom'>('today');
  const [customDate, setCustomDate] = useState<string>(new Date().toISOString().slice(0, 10));

  // Cash Drawer Settlement State
  const [openingFloat, setOpeningFloat] = useState<number>(() => {
    const saved = localStorage.getItem('smapa_opening_float');
    return saved ? Number(saved) : 5000;
  });

  // Physical Cash Denominations Counted
  const [denominations, setDenominations] = useState<{ [key: string]: number }>({
    5000: 0,
    1000: 0,
    500: 0,
    100: 0,
    50: 0,
    20: 0,
    coins: 0
  });

  // Petty Cash Expenses
  const [pettyExpenses, setPettyExpenses] = useState<PettyExpense[]>(() => {
    try {
      const data = localStorage.getItem('smapa_petty_expenses');
      return data ? JSON.parse(data) : [
        {
          id: 'exp-1',
          timestamp: new Date().toISOString(),
          category: 'Meals & Tea',
          description: 'Staff tea & morning snacks',
          amount: 450
        },
        {
          id: 'exp-2',
          timestamp: new Date().toISOString(),
          category: 'Transport',
          description: 'Local market transport',
          amount: 600
        }
      ];
    } catch {
      return [];
    }
  });

  // New Petty Expense Modal
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [expenseForm, setExpenseForm] = useState({
    category: 'Meals & Tea',
    description: '',
    amount: ''
  });

  // Save Opening Float
  const handleSaveOpeningFloat = (val: number) => {
    setOpeningFloat(val);
    localStorage.setItem('smapa_opening_float', val.toString());
  };

  // Add Petty Expense
  const handleAddPettyExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseForm.amount || Number(expenseForm.amount) <= 0) return;

    const newExp: PettyExpense = {
      id: `exp-${Date.now()}`,
      timestamp: new Date().toISOString(),
      category: expenseForm.category,
      description: expenseForm.description.trim() || expenseForm.category,
      amount: Number(expenseForm.amount)
    };

    const updated = [newExp, ...pettyExpenses];
    setPettyExpenses(updated);
    localStorage.setItem('smapa_petty_expenses', JSON.stringify(updated));
    setExpenseForm({ category: 'Meals & Tea', description: '', amount: '' });
    setIsExpenseModalOpen(false);
  };

  const handleDeletePettyExpense = (id: string) => {
    const updated = pettyExpenses.filter((e) => e.id !== id);
    setPettyExpenses(updated);
    localStorage.setItem('smapa_petty_expenses', JSON.stringify(updated));
  };

  // Filter Orders based on selected period - ALWAYS sorted with latest/last bill at the TOP
  const filteredOrders = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().slice(0, 10);

    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayStr = yesterday.toISOString().slice(0, 10);

    const currentYearMonth = now.toISOString().slice(0, 7); // 'YYYY-MM'

    const lastMonthDate = new Date();
    lastMonthDate.setMonth(lastMonthDate.getMonth() - 1);
    const lastYearMonth = lastMonthDate.toISOString().slice(0, 7);

    return orders
      .filter((order) => {
        const orderDate = new Date(order.createdAt).toISOString().slice(0, 10);
        const orderYearMonth = orderDate.slice(0, 7);

        if (reportPeriod === 'today') return orderDate === todayStr;
        if (reportPeriod === 'yesterday') return orderDate === yesterdayStr;
        if (reportPeriod === 'month') return orderYearMonth === currentYearMonth;
        if (reportPeriod === 'last_month') return orderYearMonth === lastYearMonth;
        if (reportPeriod === 'custom') return orderDate === customDate;
        return true;
      })
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()); // Latest bill on top!
  }, [orders, reportPeriod, customDate]);

  // Search filtered invoices for quick finding
  const displayedInvoices = useMemo(() => {
    if (!invoiceSearchQuery.trim()) return filteredOrders;
    const q = invoiceSearchQuery.toLowerCase().trim();
    return filteredOrders.filter(
      (o) =>
        o.orderNumber.toLowerCase().includes(q) ||
        o.customer.name.toLowerCase().includes(q) ||
        (o.customer.phone && o.customer.phone.includes(q))
    );
  }, [filteredOrders, invoiceSearchQuery]);

  // Today specific orders for cash drawer
  const todayOrders = useMemo(() => {
    const todayStr = new Date().toISOString().slice(0, 10);
    return orders.filter((o) => new Date(o.createdAt).toISOString().slice(0, 10) === todayStr);
  }, [orders]);

  // Calculations for Filtered Period
  const totalSales = filteredOrders.reduce((sum, o) => sum + o.total, 0);
  const totalOrdersCount = filteredOrders.length;
  const avgOrderValue = totalOrdersCount > 0 ? Math.round(totalSales / totalOrdersCount) : 0;

  // Channel breakdown
  const posSales = filteredOrders.filter((o) => o.channel === 'shop_pos').reduce((s, o) => s + o.total, 0);
  const posCount = filteredOrders.filter((o) => o.channel === 'shop_pos').length;

  const onlineSales = filteredOrders.filter((o) => o.channel !== 'shop_pos').reduce((s, o) => s + o.total, 0);
  const onlineCount = filteredOrders.filter((o) => o.channel !== 'shop_pos').length;

  // Estimated Cost & Profit
  const estimatedCost = useMemo(() => {
    let cost = 0;
    filteredOrders.forEach((o) => {
      o.items.forEach((it) => {
        const prod = products.find((p) => p.id === it.product.id);
        const unitCost = prod?.costPrice || (it.unitPrice * 0.8);
        cost += unitCost * it.quantity;
      });
    });
    return Math.round(cost);
  }, [filteredOrders, products]);

  const estimatedProfit = totalSales - estimatedCost;
  const profitMargin = totalSales > 0 ? ((estimatedProfit / totalSales) * 100).toFixed(1) : '0';

  // --- DAY-END CASH DRAWER BALANCING (TODAY) ---
  const todayPosCashSales = todayOrders
    .filter((o) => o.channel === 'shop_pos' && (o.paymentMethod === 'cod' || !o.paymentMethod))
    .reduce((s, o) => s + o.total, 0);

  const todayCodDeliveryCash = todayOrders
    .filter((o) => o.channel !== 'shop_pos' && o.paymentMethod === 'cod' && o.status === 'delivered')
    .reduce((s, o) => s + o.total, 0);

  const totalCashCollectedToday = todayPosCashSales + todayCodDeliveryCash;

  const todayPettyExpensesTotal = pettyExpenses.reduce((sum, e) => sum + e.amount, 0);

  // Theoretical / Expected Cash in Drawer
  const expectedCashInDrawer = openingFloat + totalCashCollectedToday - todayPettyExpensesTotal;

  // Physical Cash Counted
  const actualCountedCash =
    (denominations[5000] || 0) * 5000 +
    (denominations[1000] || 0) * 1000 +
    (denominations[500] || 0) * 500 +
    (denominations[100] || 0) * 100 +
    (denominations[50] || 0) * 50 +
    (denominations[20] || 0) * 20 +
    (denominations.coins || 0);

  const cashDiscrepancy = actualCountedCash - expectedCashInDrawer;

  // Top Selling Items in filtered period
  const topSellingItems = useMemo(() => {
    const map = new Map<string, { name: string; nameSi: string; qty: number; revenue: number }>();
    filteredOrders.forEach((o) => {
      o.items.forEach((it) => {
        const curr = map.get(it.product.id) || {
          name: it.product.name,
          nameSi: it.product.nameSi,
          qty: 0,
          revenue: 0
        };
        curr.qty += it.quantity;
        curr.revenue += it.unitPrice * it.quantity;
        map.set(it.product.id, curr);
      });
    });
    return Array.from(map.values())
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [filteredOrders]);

  // Monthly Overview for Current Month
  const currentMonthSales = useMemo(() => {
    const currentYearMonth = new Date().toISOString().slice(0, 7);
    return orders
      .filter((o) => new Date(o.createdAt).toISOString().slice(0, 7) === currentYearMonth)
      .reduce((sum, o) => sum + o.total, 0);
  }, [orders]);

  const currentMonthOrdersCount = useMemo(() => {
    const currentYearMonth = new Date().toISOString().slice(0, 7);
    return orders.filter((o) => new Date(o.createdAt).toISOString().slice(0, 7) === currentYearMonth).length;
  }, [orders]);

  // Export to CSV
  const handleExportCSV = () => {
    const headers = ['Order Number', 'Date', 'Customer Name', 'Channel', 'Payment Method', 'Items Count', 'Total (Rs.)', 'Status'];
    const rows = filteredOrders.map((o) => [
      o.orderNumber,
      new Date(o.createdAt).toLocaleString(),
      `"${o.customer.name.replace(/"/g, '""')}"`,
      o.channel === 'shop_pos' ? 'POS Counter' : 'Online Web',
      o.paymentMethod || 'cash',
      o.items.reduce((s, i) => s + i.quantity, 0),
      o.total,
      o.status
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `smapa_sales_report_${reportPeriod}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner & Title */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-3xl p-5 sm:p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-black text-white tracking-tight">
                {isSi ? 'ස්වයංක්‍රීය විකුණුම් හා මුදල් වාර්තා (Sales & Cash Reports)' : 'Automated Sales & Cash Reports'}
              </h2>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-800 px-2 py-0.5 rounded-full font-bold">
                Live Auto-Generated
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {isSi
                ? 'දවසේ අවසාන මුදල් ශේෂය (Day End Cash Balance), දෛනික හා මාසික විකුණුම් වාර්තා සහ Z-Report පද්ධතියෙන් සැනින් බලාගන්න.'
                : 'Real-time Day-End Cash Drawer Reconciliation (Z-Report), daily & monthly sales analytics.'}
            </p>
          </div>
        </div>

        {/* Global Export & Print Actions */}
        <div className="flex items-center gap-2.5 flex-wrap">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800 hover:bg-slate-750 text-slate-200 rounded-xl text-xs font-bold border border-slate-700 cursor-pointer transition-colors"
          >
            <Printer className="w-4 h-4 text-amber-400" />
            <span>{isSi ? 'වාර්තාව Print කරන්න' : 'Print Report'}</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold shadow-md cursor-pointer transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>{isSi ? 'Excel / CSV බාගන්න' : 'Export CSV'}</span>
          </button>
        </div>
      </div>

      {/* Date Period Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {[
            { id: 'today', labelEn: "Today's Sales", labelSi: 'අද දවසේ විකුණුම්' },
            { id: 'yesterday', labelEn: "Yesterday", labelSi: 'ඊයේ දවස' },
            { id: 'month', labelEn: 'This Month', labelSi: 'මේ මාසය (MTD)' },
            { id: 'last_month', labelEn: 'Last Month', labelSi: 'පසුගිය මාසය' },
            { id: 'custom', labelEn: 'Custom Date', labelSi: 'වෙනත් දිනයක්' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setReportPeriod(tab.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                reportPeriod === tab.id
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`}
            >
              {isSi ? tab.labelSi : tab.labelEn}
            </button>
          ))}
        </div>

        {reportPeriod === 'custom' && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Select:</span>
            <input
              type="date"
              value={customDate}
              onChange={(e) => setCustomDate(e.target.value)}
              className="bg-slate-800 border border-slate-700 text-white text-xs px-2.5 py-1 rounded-lg outline-none"
            />
          </div>
        )}

        <div className="text-xs text-slate-400 font-mono">
          Showing: <strong className="text-white">{filteredOrders.length} transactions</strong>
        </div>
      </div>

      {/* ================= 1. DAY-END CASH BALANCE & DRAWER RECONCILIATION ================= */}
      {/* This directly answers: "day eka awasane case balance eka keeyak thiyenna oni da" */}
      <div className="bg-slate-900 border-2 border-emerald-500/80 rounded-3xl p-5 sm:p-6 shadow-2xl space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
              <Store className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-base flex items-center gap-2">
                <span>{isSi ? 'දවසේ අවසාන මුදල් ශේෂය (Day-End Cash Drawer Balance)' : 'Day-End Cash Drawer Balance (Z-Report)'}</span>
                <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-bold">
                  Daily Closing
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                {isSi
                  ? 'අද දවසේ අවසානයේ කවුන්ටර මුදල් ලාච්චුවේ තිබිය යුතු නියමිත මුදල් ශේෂය සහ භෞතික මුදල් සමථකරණය.'
                  : 'Exact theoretical cash balance required in cash drawer after POS cash sales & petty expenses.'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsExpenseModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-750 text-amber-300 font-bold text-xs rounded-xl border border-amber-700/60 cursor-pointer transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-amber-400" />
            <span>{isSi ? '+ කඩේ වියදමක් එක්කරන්න' : '+ Add Petty Expense'}</span>
          </button>
        </div>

        {/* 4 Key Drawer Settlement Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* 1. Opening Cash Float */}
          <div className="bg-slate-850 p-4 rounded-2xl border border-slate-750 space-y-2">
            <div className="flex justify-between items-center text-xs text-slate-400">
              <span>{isSi ? 'උදෑසන ආරම්භක මුදල (Float):' : 'Opening Cash Float:'}</span>
              <span className="text-[10px] text-emerald-400 font-mono">Morning Start</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-xs text-emerald-500 font-bold">Rs.</span>
              <input
                type="number"
                value={openingFloat}
                onChange={(e) => handleSaveOpeningFloat(Number(e.target.value))}
                className="w-full text-xl sm:text-2xl font-black text-white bg-transparent outline-none font-mono focus:bg-slate-800 px-1 rounded"
                title="Click to edit Opening Cash Float"
              />
            </div>
            <p className="text-[11px] text-slate-500">
              {isSi ? 'උදෑසන මාරු කාසි සඳහා ලාච්චුවට දැමූ මුදල' : 'Initial change float given to cashier'}
            </p>
          </div>

          {/* 2. Total Cash Sales Today */}
          <div className="bg-slate-850 p-4 rounded-2xl border border-slate-750 space-y-2">
            <div className="flex justify-between items-center text-xs text-slate-400">
              <span>{isSi ? '+ අද මුදල් විකුණුම් (POS Cash):' : '+ Total Cash Sales Today:'}</span>
              <span className="text-[10px] bg-emerald-950 text-emerald-300 px-1.5 py-0.2 rounded font-mono">
                {todayOrders.filter((o) => o.channel === 'shop_pos').length} bills
              </span>
            </div>
            <div className="flex items-baseline gap-1 text-emerald-400 font-black text-xl sm:text-2xl font-mono">
              <span className="text-xs font-bold">Rs.</span>
              <span>{totalCashCollectedToday.toLocaleString()}</span>
            </div>
            <p className="text-[11px] text-slate-500">
              {isSi ? 'POS කවුන්ටරයෙන් අද ලැබුණු මුදල්' : 'Direct cash receipts collected in store'}
            </p>
          </div>

          {/* 3. Petty Cash Expenses Today */}
          <div className="bg-slate-850 p-4 rounded-2xl border border-slate-750 space-y-2">
            <div className="flex justify-between items-center text-xs text-slate-400">
              <span>{isSi ? '- අද කඩේ වියදම් (Expenses):' : '- Petty Cash Expenses:'}</span>
              <span className="text-[10px] bg-rose-950 text-rose-300 px-1.5 py-0.2 rounded font-mono">
                {pettyExpenses.length} entries
              </span>
            </div>
            <div className="flex items-baseline gap-1 text-rose-400 font-black text-xl sm:text-2xl font-mono">
              <span className="text-xs font-bold">Rs.</span>
              <span>{todayPettyExpensesTotal.toLocaleString()}</span>
            </div>
            <p className="text-[11px] text-slate-500">
              {isSi ? 'තේ, ප්‍රවාහන හා දෛනික වියදම්' : 'Cash paid out from drawer for daily store expenses'}
            </p>
          </div>

          {/* 4. THE GOLDEN FIGURE: EXPECTED CASH IN DRAWER */}
          <div className="bg-gradient-to-br from-emerald-900 to-teal-950 p-4 rounded-2xl border-2 border-emerald-400 shadow-xl space-y-2">
            <div className="flex justify-between items-center text-xs text-emerald-200 font-bold">
              <span>{isSi ? 'ලාච්චුවේ තිබිය යුතු ශේෂය:' : 'EXPECTED CASH IN DRAWER:'}</span>
              <span className="text-[10px] bg-emerald-400 text-slate-950 px-1.5 py-0.5 rounded font-black">
                DAY END
              </span>
            </div>
            <div className="flex items-baseline gap-1 text-white font-black text-2xl sm:text-3xl font-mono">
              <span className="text-sm font-bold text-emerald-300">Rs.</span>
              <span>{expectedCashInDrawer.toLocaleString()}</span>
            </div>
            <p className="text-[11px] text-emerald-200/80 leading-tight">
              {isSi ? '= ආරම්භක මුදල + විකුණුම් - වියදම්' : '= Float + Cash Sales - Expenses'}
            </p>
          </div>
        </div>

        {/* Physical Cash Denomination Counter & Discrepancy Checker */}
        <div className="bg-slate-850 border border-slate-750 rounded-2xl p-4 sm:p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h4 className="font-bold text-white text-xs sm:text-sm flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>{isSi ? 'භෞතික මුදල් නෝට්ටු ගණනය කිරීම (Physical Cash Count)' : 'Physical Cash Denomination Counter'}</span>
              </h4>
              <p className="text-[11px] text-slate-400">
                {isSi
                  ? 'දවස අවසානයේ ලාච්චුවේ ඇති මුදල් නෝට්ටු ගණන මෙහි සටහන් කර නිවැරදිදැයි බලන්න.'
                  : 'Enter note counts to verify if counted cash matches the expected balance.'}
              </p>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block">{isSi ? 'ගණන් කළ මුළු මුදල:' : 'Total Counted:'}</span>
                <span className="text-base sm:text-lg font-black text-white font-mono">
                  Rs. {actualCountedCash.toLocaleString()}
                </span>
              </div>

              {/* Match or Discrepancy Badge */}
              <div
                className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 border shadow-md ${
                  actualCountedCash === 0
                    ? 'bg-slate-800 text-slate-400 border-slate-700'
                    : cashDiscrepancy === 0
                    ? 'bg-emerald-600 text-white border-emerald-400 animate-in zoom-in-95'
                    : cashDiscrepancy > 0
                    ? 'bg-amber-500 text-slate-950 border-amber-300 font-black'
                    : 'bg-rose-600 text-white border-rose-400'
                }`}
              >
                {actualCountedCash === 0 ? (
                  <span>Count Cash</span>
                ) : cashDiscrepancy === 0 ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{isSi ? 'ශේෂය 100% නිවැරදියි (Balanced)' : 'Exact Match! Balanced'}</span>
                  </>
                ) : cashDiscrepancy > 0 ? (
                  <>
                    <ArrowUpRight className="w-4 h-4" />
                    <span>{isSi ? `+Rs. ${cashDiscrepancy.toLocaleString()} අතිරික්තයක්` : `+Rs. ${cashDiscrepancy.toLocaleString()} Surplus`}</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-4 h-4" />
                    <span>{isSi ? `-Rs. ${Math.abs(cashDiscrepancy).toLocaleString()} හිඟයක්!` : `-Rs. ${Math.abs(cashDiscrepancy).toLocaleString()} Shortage!`}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          {/* Quick Denominations Inputs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5 pt-2">
            {[5000, 1000, 500, 100, 50, 20].map((denom) => (
              <div key={denom} className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 text-center space-y-1">
                <span className="text-[10px] text-slate-400 font-bold block">Rs. {denom} ×</span>
                <input
                  type="number"
                  min="0"
                  value={denominations[denom] || ''}
                  placeholder="0"
                  onChange={(e) =>
                    setDenominations({
                      ...denominations,
                      [denom]: Math.max(0, Number(e.target.value) || 0)
                    })
                  }
                  className="w-full text-center py-1 bg-slate-800 text-white font-mono font-bold text-sm rounded-lg border border-slate-700 outline-none focus:border-emerald-500"
                />
                <span className="text-[10px] text-emerald-400 font-mono block">
                  Rs. {((denominations[denom] || 0) * denom).toLocaleString()}
                </span>
              </div>
            ))}

            <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800 text-center space-y-1">
              <span className="text-[10px] text-slate-400 font-bold block">Coins (කාසි)</span>
              <input
                type="number"
                min="0"
                value={denominations.coins || ''}
                placeholder="0"
                onChange={(e) =>
                  setDenominations({
                    ...denominations,
                    coins: Math.max(0, Number(e.target.value) || 0)
                  })
                }
                className="w-full text-center py-1 bg-slate-800 text-white font-mono font-bold text-sm rounded-lg border border-slate-700 outline-none focus:border-emerald-500"
              />
              <span className="text-[10px] text-emerald-400 font-mono block">
                Rs. {(denominations.coins || 0).toLocaleString()}
              </span>
            </div>
          </div>
        </div>

        {/* Petty Expenses Today List */}
        {pettyExpenses.length > 0 && (
          <div className="space-y-2 pt-2 border-t border-slate-800">
            <span className="text-xs font-bold text-slate-400 block">
              {isSi ? 'අද දවසේ සිදුකළ කඩේ වියදම් සටහන (Petty Cash Log):' : 'Today’s Petty Cash Expense Log:'}
            </span>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {pettyExpenses.map((exp) => (
                <div
                  key={exp.id}
                  className="p-2.5 bg-slate-800/80 rounded-xl border border-slate-700 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] bg-slate-700 text-slate-300 px-2 py-0.5 rounded font-medium">
                      {exp.category}
                    </span>
                    <span className="text-slate-200 font-medium">{exp.description}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-rose-400">Rs. {exp.amount.toLocaleString()}</span>
                    <button
                      onClick={() => handleDeletePettyExpense(exp.id)}
                      className="text-slate-500 hover:text-rose-400 p-1 cursor-pointer"
                      title="Delete expense"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ================= 2. SALES PERFORMANCE & SUMMARY ================= */}
      {/* Answers: "day eka awasane total sale eka keeyada" & "monthly sale eka keeyada" */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Sales in Selected Period */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>
              {reportPeriod === 'today'
                ? (isSi ? 'අද දවසේ මුළු විකිණුම:' : 'Today Total Sale:')
                : reportPeriod === 'month'
                ? (isSi ? 'මේ මාසයේ මුළු විකිණුම:' : 'This Month Total Sale:')
                : (isSi ? 'තෝරාගත් කාලයේ මුළු විකිණුම:' : 'Selected Total Sales:')}
            </span>
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <DollarSign className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono">
            Rs. {totalSales.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800">
            <span>{filteredOrders.length} Completed Orders</span>
            <span className="text-emerald-400 font-bold">AOV: Rs. {avgOrderValue.toLocaleString()}</span>
          </div>
        </div>

        {/* Counter POS vs Online Breakdown */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>{isSi ? 'නාලිකා අනුව විකුණුම් (Channel):' : 'Channel Split (POS vs Web):'}</span>
            <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
              <Store className="w-4 h-4" />
            </span>
          </div>
          <div className="space-y-1.5 pt-1">
            <div className="flex justify-between items-center text-xs">
              <span className="text-amber-300 font-bold flex items-center gap-1">
                <span>🏪 Shop POS:</span>
              </span>
              <span className="font-mono font-bold text-white">Rs. {posSales.toLocaleString()} ({posCount})</span>
            </div>
            <div className="flex justify-between items-center text-xs">
              <span className="text-teal-300 font-bold flex items-center gap-1">
                <span>🌐 Online Web:</span>
              </span>
              <span className="font-mono font-bold text-white">Rs. {onlineSales.toLocaleString()} ({onlineCount})</span>
            </div>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden flex mt-2">
            <div
              className="bg-amber-500 h-full"
              style={{ width: `${totalSales > 0 ? (posSales / totalSales) * 100 : 50}%` }}
              title="Shop POS Share"
            />
            <div
              className="bg-teal-500 h-full"
              style={{ width: `${totalSales > 0 ? (onlineSales / totalSales) * 100 : 50}%` }}
              title="Online Web Share"
            />
          </div>
        </div>

        {/* Estimated Profit & Margin */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>{isSi ? 'දළ ලාභය (Estimated Profit):' : 'Gross Profit & Margin:'}</span>
            <span className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
              <TrendingUp className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-emerald-400 font-mono">
            Rs. {estimatedProfit.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800">
            <span>Margin: <strong className="text-white">{profitMargin}%</strong></span>
            <span>Cost: Rs. {estimatedCost.toLocaleString()}</span>
          </div>
        </div>

        {/* Month-to-Date (MTD) Snapshot */}
        <div className="bg-slate-900 border border-slate-800 p-5 rounded-3xl space-y-2">
          <div className="flex justify-between items-center text-xs text-slate-400">
            <span>{isSi ? 'මේ මාසයේ මුළු විකුණුම් (MTD):' : 'Monthly Sales Snapshot:'}</span>
            <span className="p-1.5 rounded-lg bg-teal-500/10 text-teal-400">
              <Calendar className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-white font-mono">
            Rs. {currentMonthSales.toLocaleString()}
          </div>
          <div className="text-xs text-slate-400 flex items-center justify-between pt-1 border-t border-slate-800">
            <span>{currentMonthOrdersCount} orders this month</span>
            <span className="text-emerald-400 font-bold">Active Month</span>
          </div>
        </div>
      </div>

      {/* Top Selling Items & Transaction Log */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Top 5 Selling Products (Col 5) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <h3 className="font-bold text-white text-xs sm:text-sm flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-emerald-400" />
              <span>{isSi ? 'වැඩිපුරම අලෙවි වූ භාණ්ඩ (Top Selling)' : 'Top Selling Items'}</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-mono">By Revenue</span>
          </div>

          <div className="space-y-2">
            {topSellingItems.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-500">
                No product sales recorded for this period.
              </div>
            ) : (
              topSellingItems.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-850 rounded-2xl border border-slate-800 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 font-mono font-bold text-[10px] flex items-center justify-center shrink-0">
                      #{idx + 1}
                    </span>
                    <div className="truncate">
                      <span className="font-bold text-white block truncate">{isSi ? item.nameSi : item.name}</span>
                      <span className="text-[10px] text-slate-400">{item.qty} units sold</span>
                    </div>
                  </div>
                  <span className="font-mono font-bold text-emerald-400 shrink-0">
                    Rs. {item.revenue.toLocaleString()}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Detailed Transactions List (Col 7) */}
        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-3.5">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
            <div>
              <h3 className="font-bold text-white text-xs sm:text-sm flex items-center gap-2">
                <FileText className="w-4 h-4 text-amber-400" />
                <span>{isSi ? 'විකුණුම් බිල්පත් ලැයිස්තුව (Bills Log)' : 'Processed Sales Invoices'}</span>
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {isSi
                  ? '💡 බිලක් මත Click කර සම්පූර්ණ විස්තර බලන්න & Print කරන්න. අලුත්ම බිල ඉහළින්ම ඇත.'
                  : '💡 Click any bill to review details & re-print receipt. Latest bill is on top.'}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full font-mono font-bold border border-slate-700">
                {displayedInvoices.length} {isSi ? 'බිල්පත්' : 'bills'}
              </span>
            </div>
          </div>

          {/* Quick Invoice Search Bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={invoiceSearchQuery}
              onChange={(e) => setInvoiceSearchQuery(e.target.value)}
              placeholder={isSi ? 'බිල්පත් අංකය හෝ නම සොයන්න (උදා: POS-9748)...' : 'Search by Bill # (e.g. POS-9748) or customer name...'}
              className="w-full pl-8 pr-8 py-1.5 bg-slate-800/90 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 outline-none focus:border-amber-400 transition-colors"
            />
            {invoiceSearchQuery && (
              <button
                onClick={() => setInvoiceSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {displayedInvoices.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-500 space-y-1">
                <FileText className="w-8 h-8 mx-auto text-slate-600 opacity-50" />
                <p>{isSi ? 'සොයන බිල්පත හමු නොවීය.' : 'No invoices found for this search or period.'}</p>
              </div>
            ) : (
              displayedInvoices.map((ord, idx) => {
                const isLatestBill = idx === 0 && !invoiceSearchQuery;
                const totalItemsCount = ord.items.reduce((s, i) => s + i.quantity, 0);

                // calculate discount if any
                const regularMRP = ord.items.reduce((sum, item) => {
                  const orig = (item.product.originalPrice && item.product.originalPrice > item.unitPrice)
                    ? item.product.originalPrice
                    : item.unitPrice;
                  return sum + orig * item.quantity;
                }, 0);
                const discountAmount = Math.max(ord.discount || 0, Math.max(0, regularMRP - ord.total));

                return (
                  <div
                    key={ord.id}
                    onClick={() => {
                      setSelectedInvoiceForReview(ord);
                      onViewOrder?.(ord);
                    }}
                    role="button"
                    tabIndex={0}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer group flex flex-wrap items-center justify-between gap-3 text-xs ${
                      isLatestBill
                        ? 'bg-gradient-to-r from-emerald-950/40 via-slate-850 to-slate-850 border-emerald-500/80 hover:border-emerald-400 ring-1 ring-emerald-500/30 shadow-md shadow-emerald-950/40'
                        : 'bg-slate-850 hover:bg-slate-800 border-slate-800 hover:border-amber-500/60 shadow-sm'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-mono font-black text-white text-sm group-hover:text-amber-300 transition-colors">
                          {ord.orderNumber}
                        </span>

                        {isLatestBill && (
                          <span className="text-[9px] bg-emerald-500 text-slate-950 px-2 py-0.5 rounded-full font-black uppercase tracking-wider flex items-center gap-1 shadow-xs animate-pulse">
                            <span>🟢</span>
                            <span>{isSi ? 'අලුත්ම බිල (Latest)' : 'Latest Bill'}</span>
                          </span>
                        )}

                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                            ord.channel === 'shop_pos'
                              ? 'bg-amber-950 text-amber-300 border border-amber-800'
                              : 'bg-teal-950 text-teal-300 border border-teal-800'
                          }`}
                        >
                          {ord.channel === 'shop_pos' ? 'POS Counter' : 'Online'}
                        </span>

                        <span
                          className={`text-[9px] px-1.5 py-0.2 rounded font-bold uppercase ${
                            ord.paymentStatus === 'paid'
                              ? 'bg-emerald-950 text-emerald-300'
                              : 'bg-yellow-950 text-yellow-300'
                          }`}
                        >
                          {ord.paymentStatus === 'paid' ? 'Paid' : 'Pending'}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-1 flex-wrap">
                        <span className="text-slate-300 font-medium">{ord.customer.name}</span>
                        <span>•</span>
                        <span>{new Date(ord.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        <span>•</span>
                        <span>{totalItemsCount} {isSi ? 'භාණ්ඩ' : 'items'} ({ord.paymentMethod?.toUpperCase() || 'COD'})</span>
                      </div>
                    </div>

                    <div className="text-right flex items-center gap-3 shrink-0">
                      <div>
                        <span className="font-mono font-black text-emerald-400 block text-base group-hover:scale-105 transition-transform">
                          Rs. {ord.total.toLocaleString()}
                        </span>
                        {discountAmount > 0 ? (
                          <span className="text-[10px] text-emerald-500 font-semibold block">
                            Saved -Rs. {discountAmount.toLocaleString()}
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-500 block">
                            {ord.items.length} lines
                          </span>
                        )}
                      </div>

                      <span className="px-2.5 py-1.5 rounded-xl bg-slate-800 group-hover:bg-amber-500 group-hover:text-slate-950 text-slate-300 font-bold text-[10px] flex items-center gap-1 transition-all shadow-xs shrink-0">
                        <Eye className="w-3.5 h-3.5" />
                        <span>{isSi ? 'බිල බලන්න' : 'Open Bill'} ➔</span>
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      </div>

      {/* Add Petty Expense Modal */}
      {isExpenseModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-black text-white text-sm flex items-center gap-2">
                <Plus className="w-4 h-4 text-amber-400" />
                <span>{isSi ? 'දෛනික කඩේ වියදමක් එක්කරන්න' : 'Add Store Petty Expense'}</span>
              </h3>
              <button
                onClick={() => setIsExpenseModalOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddPettyExpense} className="space-y-3">
              <div>
                <label className="text-xs text-slate-300 font-bold block mb-1">Category (වර්ගය):</label>
                <select
                  value={expenseForm.category}
                  onChange={(e) => setExpenseForm({ ...expenseForm, category: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-xs outline-none"
                >
                  <option value="Meals & Tea">Meals & Tea (සේවක තේ හා ආහාර)</option>
                  <option value="Transport">Transport (ප්‍රවාහන වියදම්)</option>
                  <option value="Cleaning & Bags">Cleaning & Polythene Bags (පිරිසිදු කිරීම් හා බෑග්)</option>
                  <option value="Supplier Payout">Direct Supplier Cash Payout (සැපයුම්කරුට ගෙවීම්)</option>
                  <option value="Maintenance">Store Maintenance & Repair (නඩත්තු)</option>
                  <option value="Miscellaneous">Miscellaneous (වෙනත්)</option>
                </select>
              </div>

              <div>
                <label className="text-xs text-slate-300 font-bold block mb-1">Description (විස්තරය):</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Afternoon tea for 3 staff"
                  value={expenseForm.description}
                  onChange={(e) => setExpenseForm({ ...expenseForm, description: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white text-xs outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-300 font-bold block mb-1">Amount in LKR (රුපියල්):</label>
                <input
                  type="number"
                  required
                  min="1"
                  placeholder="e.g. 450"
                  value={expenseForm.amount}
                  onChange={(e) => setExpenseForm({ ...expenseForm, amount: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white font-mono text-sm font-bold outline-none focus:border-amber-400"
                />
              </div>

              <div className="flex items-center gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsExpenseModalOpen(false)}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-750 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-md cursor-pointer transition-all"
                >
                  {isSi ? 'වියදම සටහන් කරන්න' : 'Record Expense'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ================= BILL REVIEW & RE-PRINT MODAL ================= */}
      {selectedInvoiceForReview && (
        <div className="fixed inset-0 z-50 p-4 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center animate-in fade-in overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl max-h-[92vh] flex flex-col border border-slate-200">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <div className="text-left">
                <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider block">
                  {isSi ? 'බිල්පත් සමාලෝචනය & මුද්‍රණය' : 'Invoice Review & Re-Print'}
                </span>
                <h3 className="font-black text-lg text-slate-950 font-mono">
                  #{selectedInvoiceForReview.orderNumber}
                </h3>
              </div>
              <button
                onClick={() => setSelectedInvoiceForReview(null)}
                className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center cursor-pointer transition-colors"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Printable Receipt Paper Container */}
            <div
              id="report-bill-review-print-area"
              className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 font-mono text-xs overflow-y-auto flex-1 shadow-inner"
            >
              {/* Superstore details */}
              <div className="text-center border-b pb-2.5 space-y-0.5">
                <h4 className="font-black text-sm tracking-tight text-slate-900">SMAPA 27 MEGA STORE</h4>
                <p className="text-[10px] text-slate-600">No. 128, High Level Road, Maharagama</p>
                <p className="text-[10px] text-slate-600">Hotline: 077 477 8190 | orders@lankamart.lk</p>
                <div className="flex items-center justify-center gap-1.5 pt-1">
                  <span className="text-[9px] bg-slate-200 text-slate-800 px-2 py-0.5 rounded font-bold uppercase">
                    {selectedInvoiceForReview.channel === 'shop_pos' ? 'Physical POS Cash Bill' : 'Online Web Store Order'}
                  </span>
                  <span className="text-[9px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded font-bold uppercase">
                    {selectedInvoiceForReview.paymentStatus === 'paid' ? 'PAID' : 'PAYMENT PENDING'}
                  </span>
                </div>
              </div>

              {/* Bill Details */}
              <div className="text-[11px] space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Bill / Receipt #:</span>
                  <span className="font-bold text-slate-900">#{selectedInvoiceForReview.orderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Date & Time:</span>
                  <span>{new Date(selectedInvoiceForReview.createdAt).toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Customer:</span>
                  <span className="font-semibold text-slate-900">
                    {selectedInvoiceForReview.customer.name} ({selectedInvoiceForReview.customer.phone || 'Counter Walk-in'})
                  </span>
                </div>
                {selectedInvoiceForReview.customer.address && selectedInvoiceForReview.customer.address !== 'Physical Superstore Counter' && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">Delivery Address:</span>
                    <span>{selectedInvoiceForReview.customer.address}, {selectedInvoiceForReview.customer.city}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-500">Payment Channel:</span>
                  <span className="uppercase font-semibold text-slate-800">{selectedInvoiceForReview.paymentMethod || 'CASH'}</span>
                </div>
              </div>

              {/* Items Table */}
              <div className="border-t border-b py-2 space-y-1.5 divide-y divide-slate-200">
                {selectedInvoiceForReview.items.map((it, idx) => {
                  const effectivePrice = it.unitPrice || it.product.price;
                  const hasDiscount = it.product.originalPrice && it.product.originalPrice > effectivePrice;
                  const itemDiscount = hasDiscount ? (it.product.originalPrice! - effectivePrice) * it.quantity : 0;

                  return (
                    <div key={idx} className="pt-1.5 first:pt-0 flex justify-between items-start">
                      <div className="min-w-0 pr-2">
                        <span className="font-bold text-slate-900 block truncate">
                          {isSi ? it.product.nameSi : it.product.name} × {it.quantity}
                        </span>
                        <div className="text-[10px] text-slate-500 flex items-center gap-1.5">
                          <span>{it.product.unit}</span>
                          {hasDiscount && (
                            <span className="line-through text-slate-400">
                              Rs. {it.product.originalPrice?.toLocaleString()}
                            </span>
                          )}
                          <span>@ Rs. {effectivePrice.toLocaleString()}</span>
                          {it.isWholesaleApplied && (
                            <span className="bg-amber-100 text-amber-900 px-1 py-0.2 rounded font-bold text-[9px]">
                              Wholesale
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="font-black text-slate-900 block">
                          Rs. {(effectivePrice * it.quantity).toLocaleString()}
                        </span>
                        {itemDiscount > 0 && (
                          <span className="text-[9px] text-emerald-600 font-bold block">
                            Saved -Rs. {itemDiscount.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Financial Calculations & Discount Breakdown */}
              {(() => {
                const totalRegularMRP = selectedInvoiceForReview.items.reduce((sum, item) => {
                  const orig = (item.product.originalPrice && item.product.originalPrice > (item.unitPrice || item.product.price))
                    ? item.product.originalPrice
                    : (item.unitPrice || item.product.price);
                  return sum + orig * item.quantity;
                }, 0);
                const netSub = selectedInvoiceForReview.items.reduce((sum, item) => sum + (item.unitPrice || item.product.price) * item.quantity, 0);
                const savings = Math.max(selectedInvoiceForReview.discount || 0, Math.max(0, totalRegularMRP - netSub));

                return (
                  <div className="space-y-1 text-[11px] pt-1">
                    {savings > 0 && (
                      <div className="flex justify-between text-slate-500">
                        <span>Items Regular Total (MRP):</span>
                        <span className="line-through">Rs. {totalRegularMRP.toLocaleString()}</span>
                      </div>
                    )}

                    {savings > 0 && (
                      <div className="flex justify-between font-bold text-emerald-800 bg-emerald-100/80 px-2 py-1 rounded-lg border border-emerald-300">
                        <span>🎉 Total Discount Saved (ලැබුණු වට්ටම):</span>
                        <span>-Rs. {savings.toLocaleString()}</span>
                      </div>
                    )}

                    <div className="flex justify-between text-slate-600">
                      <span>Subtotal:</span>
                      <span className="font-semibold">Rs. {selectedInvoiceForReview.subtotal.toLocaleString()}</span>
                    </div>

                    <div className="flex justify-between text-slate-600">
                      <span>Delivery Fee:</span>
                      <span className="font-semibold">
                        {selectedInvoiceForReview.deliveryFee === 0 ? 'FREE / 0' : `Rs. ${selectedInvoiceForReview.deliveryFee.toLocaleString()}`}
                      </span>
                    </div>

                    <div className="pt-1.5 border-t border-slate-300 flex justify-between font-black text-sm text-slate-900">
                      <span>Net Total Payable:</span>
                      <span className="text-emerald-700 text-base">Rs. {selectedInvoiceForReview.total.toLocaleString()}</span>
                    </div>

                    {selectedInvoiceForReview.cashTendered !== undefined && selectedInvoiceForReview.cashTendered > 0 && (
                      <>
                        <div className="flex justify-between text-slate-600 pt-1">
                          <span>Cash Tendered:</span>
                          <span>Rs. {selectedInvoiceForReview.cashTendered.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between font-bold text-emerald-700">
                          <span>Change Returned:</span>
                          <span>Rs. {(selectedInvoiceForReview.changeGiven || 0).toLocaleString()}</span>
                        </div>
                      </>
                    )}

                    {savings > 0 && (
                      <div className="text-center py-1.5 bg-amber-50 border border-amber-200 rounded-lg text-[10px] font-bold text-amber-900 mt-2">
                        ⭐ Customer Saved Rs. {savings.toLocaleString()} on this bill!
                      </div>
                    )}
                  </div>
                );
              })()}

              <div className="text-center pt-2 border-t text-[10px] text-slate-500">
                <p>Thank you for shopping with us! • ස්තුතියි! නැවත එන්න.</p>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="pt-1 flex gap-2">
              <button
                onClick={() => window.print()}
                className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer shadow-md transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>{isSi ? '🖨️ බිල Print කරන්න' : '🖨️ Re-Print Receipt'}</span>
              </button>
              <button
                onClick={() => setSelectedInvoiceForReview(null)}
                className="py-2.5 px-5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
