import React, { useState } from 'react';
import {
  Truck, Edit, Plus, CheckCircle2, ShieldCheck, MapPin, Sparkles,
  Layers, Check, DollarSign, Clock
} from 'lucide-react';
import { DeliveryRider, DeliveryZoneConfig, Language } from '../../types';
import { UnifiedStore } from '../../services/store';

interface DeliveryZonesManagerProps {
  lang: Language;
  zones: DeliveryZoneConfig[];
  riders: DeliveryRider[];
}

export const DeliveryZonesManager: React.FC<DeliveryZonesManagerProps> = ({
  lang,
  zones: initialZones,
  riders
}) => {
  const isSi = lang === 'si';

  const [zones, setZones] = useState<DeliveryZoneConfig[]>(initialZones);
  const [editingZone, setEditingZone] = useState<DeliveryZoneConfig | null>(null);
  const [newTownInput, setNewTownInput] = useState('');
  const [notice, setNotice] = useState<string | null>(null);

  const handleOpenEdit = (zone: DeliveryZoneConfig) => {
    setEditingZone({ ...zone });
    setNewTownInput('');
  };

  const handleSaveZone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingZone) return;

    UnifiedStore.saveDeliveryZone(editingZone);
    setZones(UnifiedStore.getDeliveryZones());
    setNotice(isSi ? `බෙදාහැරීමේ කලාපය (${editingZone.name}) සාර්ථකව යාවත්කාලීන විය!` : `Delivery Zone (${editingZone.name}) updated successfully!`);
    setEditingZone(null);
    setTimeout(() => setNotice(null), 3500);
  };

  const handleAddTown = () => {
    if (!newTownInput.trim() || !editingZone) return;
    const town = newTownInput.trim();
    if (!editingZone.coverageAreas.includes(town)) {
      setEditingZone({
        ...editingZone,
        coverageAreas: [...editingZone.coverageAreas, town]
      });
    }
    setNewTownInput('');
  };

  const handleRemoveTown = (town: string) => {
    if (!editingZone) return;
    setEditingZone({
      ...editingZone,
      coverageAreas: editingZone.coverageAreas.filter((t) => t !== town)
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold">
            <Truck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white">
                {isSi ? 'බෙදාහැරීම් ප්‍රදේශ සහ ගාස්තු කළමනාකරණය (Step 6)' : 'Delivery Areas & Zone Fee System Manager'}
              </h2>
              <span className="text-[10px] bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded-full border border-indigo-800 font-bold">
                {zones.length} Zones Active
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {isSi
                ? 'ප්‍රදේශ අනුව Standard & Express ගාස්තු, නොමිලේ ඩිලිවරි සීමාවන් (Free Delivery Threshold) සහ ආවරණය වන නගර මෙතැනින් පාලනය කරන්න.'
                : 'Configure standard & express delivery charges, free delivery minimum thresholds, and covered suburbs per zone.'}
            </p>
          </div>
        </div>
      </div>

      {notice && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/80 border border-emerald-500/60 text-emerald-200 text-xs flex items-center gap-2 font-bold animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notice}</span>
        </div>
      )}

      {/* Zone Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {zones.map((zone) => (
          <div
            key={zone.id}
            className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-4 shadow-lg hover:border-indigo-500/40 transition-colors"
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-bold text-white text-sm">{zone.name}</h3>
                <p className="text-[11px] text-slate-400">{zone.nameSi}</p>
              </div>

              <button
                onClick={() => handleOpenEdit(zone)}
                className="flex items-center gap-1 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-indigo-300 rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Edit Zone</span>
              </button>
            </div>

            {/* Fees Grid */}
            <div className="grid grid-cols-3 gap-2 bg-slate-850 p-3.5 rounded-2xl border border-slate-750 text-xs">
              <div>
                <span className="text-[10px] text-slate-400 block uppercase">Standard Fee</span>
                <span className="font-bold text-white">Rs. {zone.standardFee}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block uppercase">Express Fee</span>
                <span className="font-bold text-emerald-400">Rs. {zone.expressFee}</span>
              </div>
              <div>
                <span className="text-[10px] text-slate-400 block uppercase">Free Over</span>
                <span className="font-bold text-amber-300">
                  {zone.freeDeliveryThreshold ? `Rs. ${zone.freeDeliveryThreshold.toLocaleString()}` : 'None'}
                </span>
              </div>
            </div>

            <div className="text-xs space-y-2">
              <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                <Clock className="w-3.5 h-3.5 text-slate-500" />
                <span>Lead Time: <strong className="text-slate-200">{zone.estimatedHours}</strong></span>
              </div>

              <div>
                <span className="text-[10px] uppercase font-bold text-slate-500 block mb-1">
                  Covered Towns & Postal Areas ({zone.coverageAreas.length})
                </span>
                <div className="flex flex-wrap gap-1">
                  {zone.coverageAreas.map((town, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md border border-slate-700"
                    >
                      {town}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Fleet & Active Delivery Riders */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-4">
        <h3 className="font-bold text-white text-sm flex items-center gap-2">
          <Truck className="w-4 h-4 text-emerald-400" />
          <span>Active Delivery Riders & Logistics Partners Fleet</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {riders.map((r) => (
            <div key={r.id} className="bg-slate-800/80 p-4 rounded-2xl border border-slate-700 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-700 text-emerald-400 flex items-center justify-center font-bold">
                <Truck className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <span className="font-bold text-white block">{r.name}</span>
                <span className="text-[11px] text-slate-400 font-mono">{r.phone}</span>
                <span className="text-[10px] text-indigo-400 font-semibold block">{r.agency} • {r.vehicleNumber}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Edit Zone Modal */}
      {editingZone && (
        <div className="fixed inset-0 z-50 p-4 bg-slate-950/85 backdrop-blur-xs flex items-center justify-center animate-in fade-in">
          <div className="bg-slate-900 border border-slate-700 rounded-3xl max-w-lg w-full p-6 space-y-4 max-h-[90vh] overflow-y-auto">
            <h3 className="text-base font-bold text-white">
              Edit Zone: {editingZone.name}
            </h3>

            <form onSubmit={handleSaveZone} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">Standard Delivery Fee (Rs.) *</label>
                  <input
                    type="number"
                    required
                    value={editingZone.standardFee}
                    onChange={(e) => setEditingZone({ ...editingZone, standardFee: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">Express Delivery Fee (Rs.) *</label>
                  <input
                    type="number"
                    required
                    value={editingZone.expressFee}
                    onChange={(e) => setEditingZone({ ...editingZone, expressFee: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none font-bold text-emerald-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Free Delivery Minimum Order (Rs.)</label>
                <input
                  type="number"
                  value={editingZone.freeDeliveryThreshold || ''}
                  onChange={(e) => setEditingZone({ ...editingZone, freeDeliveryThreshold: Number(e.target.value) })}
                  placeholder="e.g. 7500"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none"
                />
                <span className="text-[10px] text-slate-500 mt-0.5 block">
                  Customers who order above this subtotal get free standard delivery.
                </span>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">Estimated Delivery Hours / Lead Time</label>
                <input
                  type="text"
                  value={editingZone.estimatedHours}
                  onChange={(e) => setEditingZone({ ...editingZone, estimatedHours: e.target.value })}
                  placeholder="Within 2-4 Hours (Same Day)"
                  className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none"
                />
              </div>

              {/* Towns List Editor */}
              <div>
                <label className="block text-slate-400 mb-1">Covered Suburbs & Towns</label>
                <div className="flex gap-2 mb-2">
                  <input
                    type="text"
                    value={newTownInput}
                    onChange={(e) => setNewTownInput(e.target.value)}
                    placeholder="Enter town name (e.g. Maharagama)..."
                    className="flex-1 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none text-xs"
                  />
                  <button
                    type="button"
                    onClick={handleAddTown}
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold"
                  >
                    + Add
                  </button>
                </div>

                <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-2 bg-slate-850 rounded-xl border border-slate-800">
                  {editingZone.coverageAreas.map((town, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1 text-[11px] bg-slate-800 text-slate-200 px-2 py-0.5 rounded-md"
                    >
                      <span>{town}</span>
                      <button
                        type="button"
                        onClick={() => handleRemoveTown(town)}
                        className="text-slate-400 hover:text-rose-400 ml-1 font-bold"
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingZone(null)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl cursor-pointer"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
