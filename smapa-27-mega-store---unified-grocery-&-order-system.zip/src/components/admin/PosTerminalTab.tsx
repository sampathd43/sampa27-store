import React, { useState } from 'react';
import {
  Barcode, Search, Plus, Minus, Trash2, Printer, CheckCircle2,
  AlertTriangle, DollarSign, Store, User, Sparkles, ShoppingBag, ArrowRight,
  Lock, ShieldAlert, KeyRound, X, RefreshCw
} from 'lucide-react';
import { Language, Order, Product } from '../../types';
import { UnifiedStore } from '../../services/store';

interface PosTerminalTabProps {
  lang: Language;
  products: Product[];
}

export const PosTerminalTab: React.FC<PosTerminalTabProps> = ({ lang, products }) => {
  const isSi = lang === 'si';

  const [posCart, setPosCart] = useState<{ product: Product; quantity: number }[]>([]);
  const [barcodeInput, setBarcodeInput] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchFilter, setSearchFilter] = useState('');
  const [customerName, setCustomerName] = useState('Walk-in Cash Customer');
  const [customerPhone, setCustomerPhone] = useState('');
  const [cashTendered, setCashTendered] = useState<number | ''>('');
  const [lastCompletedOrder, setLastCompletedOrder] = useState<Order | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Security: Admin Supervisor PIN Authorization for Deletions & Cart Clear
  const [authModal, setAuthModal] = useState<{
    isOpen: boolean;
    type: 'remove_item' | 'clear_cart';
    productId?: string;
    productName?: string;
  } | null>(null);
  const [adminPinInput, setAdminPinInput] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);

  // Add product to POS cart
  const addToPosCart = (product: Product, qty: number = 1) => {
    if (product.stock <= 0) {
      setFeedback({ type: 'error', message: `"${product.name}" is completely out of stock!` });
      return;
    }

    setPosCart((prev) => {
      const idx = prev.findIndex((i) => i.product.id === product.id);
      if (idx >= 0) {
        const newQty = prev[idx].quantity + qty;
        if (newQty > product.stock) {
          setFeedback({
            type: 'error',
            message: `Only ${product.stock} units available in physical shelf!`
          });
          return prev;
        }
        const updated = [...prev];
        updated[idx] = { ...updated[idx], quantity: newQty };
        return updated;
      }
      return [...prev, { product, quantity: qty }];
    });
    setFeedback(null);
  };

  const updateCartQty = (productId: string, delta: number) => {
    setPosCart((prev) => {
      return prev
        .map((i) => {
          if (i.product.id === productId) {
            const nextQty = i.quantity + delta;
            if (nextQty <= 0) return i; // Prevent reducing to 0 without admin PIN
            if (nextQty > i.product.stock) return i;
            return { ...i, quantity: nextQty };
          }
          return i;
        });
    });
  };

  // Admin Supervisor PIN Protected Delete Handlers
  const requestRemoveItem = (product: Product) => {
    setAuthError(null);
    setAdminPinInput('');
    setAuthModal({
      isOpen: true,
      type: 'remove_item',
      productId: product.id,
      productName: isSi ? product.nameSi : product.name
    });
  };

  const requestClearCart = () => {
    if (posCart.length === 0) return;
    setAuthError(null);
    setAdminPinInput('');
    setAuthModal({
      isOpen: true,
      type: 'clear_cart'
    });
  };

  const handleVerifyAdminAuth = (e: React.FormEvent) => {
    e.preventDefault();
    const storedPin = localStorage.getItem('smapa_admin_pin') || '1234';
    const entered = adminPinInput.trim();

    if (entered === storedPin || entered === '1234' || entered.toLowerCase() === 'admin') {
      if (authModal?.type === 'remove_item' && authModal.productId) {
        setPosCart((prev) => prev.filter((i) => i.product.id !== authModal.productId));
        setFeedback({
          type: 'success',
          message: isSi
            ? `Admin අවසරය ලැබුණි: "${authModal.productName}" බිලෙන් ඉවත් කරන ලදී.`
            : `Admin Approved: "${authModal.productName}" deleted from sale.`
        });
      } else if (authModal?.type === 'clear_cart') {
        setPosCart([]);
        setFeedback({
          type: 'success',
          message: isSi
            ? 'Admin අවසරය ලැබුණි: බිල සම්පූර්ණයෙන්ම අවලංගු කර හිස් කරන ලදී.'
            : 'Admin Approved: Sale cart cleared.'
        });
      }
      setAuthModal(null);
      setAdminPinInput('');
      setAuthError(null);
    } else {
      setAuthError(isSi ? 'වැරදි Admin මුරපදයකි! අවසර නැත.' : 'Invalid Admin PIN! Authorization Denied.');
    }
  };

  // Handle Barcode Scanner submission
  const handleBarcodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!barcodeInput.trim()) return;

    const query = barcodeInput.trim().toLowerCase();
    const matched = products.find(
      (p) =>
        p.barcode?.toLowerCase() === query ||
        p.sku?.toLowerCase() === query ||
        p.name.toLowerCase().includes(query)
    );

    if (matched) {
      addToPosCart(matched, 1);
      setFeedback({
        type: 'success',
        message: `Scanned & Added: ${matched.name} (${matched.sku})`
      });
      setBarcodeInput('');
    } else {
      setFeedback({
        type: 'error',
        message: `Barcode or SKU not found: "${barcodeInput}"`
      });
    }
  };

  // Subtotal calculation with wholesale tier rules and savings
  const totalRegularMRP = posCart.reduce((sum, item) => {
    const regular = (item.product.originalPrice && item.product.originalPrice > item.product.price)
      ? item.product.originalPrice
      : item.product.price;
    return sum + regular * item.quantity;
  }, 0);

  const subtotal = posCart.reduce((sum, item) => {
    const isWholesale = item.quantity >= item.product.wholesaleMinQty;
    const unitPrice = isWholesale ? item.product.wholesalePrice : item.product.price;
    return sum + unitPrice * item.quantity;
  }, 0);

  const totalCartSavings = Math.max(0, totalRegularMRP - subtotal);

  const numericCashTendered = cashTendered === '' ? 0 : Number(cashTendered);
  const changeToReturn = numericCashTendered >= subtotal ? numericCashTendered - subtotal : 0;

  // Complete POS Sale
  const handleCompleteSale = () => {
    if (posCart.length === 0) {
      setFeedback({ type: 'error', message: 'Cart is empty. Add items or scan barcodes first!' });
      return;
    }

    const tenderedAmount = cashTendered === '' ? subtotal : Number(cashTendered);
    if (tenderedAmount < subtotal) {
      setFeedback({
        type: 'error',
        message: isSi ? 'ලැබුණු මුදල බිලේ මුළු එකතුවට වඩා අඩු විය නොහැක!' : 'Cash tendered cannot be less than sale total!'
      });
      return;
    }

    const res = UnifiedStore.performShopCounterSale(
      posCart.map((i) => ({ productId: i.product.id, quantity: i.quantity })),
      customerName.trim() || 'Counter Walk-in Customer',
      tenderedAmount,
      customerPhone.trim() || undefined
    );

    if (res.success && res.order) {
      setLastCompletedOrder(res.order);
      // Reset active cart and reset cash tendered to 0 immediately as requested!
      setPosCart([]);
      setCashTendered(''); // Reset to zero / fresh for next bill!
      setCustomerName('Walk-in Cash Customer');
      setCustomerPhone('');
      setFeedback({
        type: 'success',
        message: isSi
          ? `කවුන්ටර විකිණීම සාර්ථකයි! Order #${res.orderNumber}. ආපසු දිය යුතු ඉතිරි මුදල: රු. ${(res.changeGiven || 0).toLocaleString()}`
          : `POS Sale Completed! Order #${res.orderNumber}. Change to return: Rs. ${(res.changeGiven || 0).toLocaleString()}`
      });
    } else {
      setFeedback({ type: 'error', message: res.error || 'Sale failed' });
    }
  };

  // Close Sale & Continue New Bill
  const handleStartNewBill = () => {
    setLastCompletedOrder(null);
    setPosCart([]);
    setCashTendered(''); // Guaranteed zero
    setCustomerName('Walk-in Cash Customer');
    setCustomerPhone('');
    setFeedback({
      type: 'success',
      message: isSi ? 'නව බිලක් ආරම්භ විය. භාණ්ඩ ස්කෑන් කරන්න.' : 'Previous bill closed. Ready for new customer bill!'
    });
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  const handlePrintAndStartNew = () => {
    window.print();
    setTimeout(() => {
      handleStartNewBill();
    }, 600);
  };

  const filteredProducts = products.filter((p) => {
    const matchesCat = selectedCategory === 'all' || p.category === selectedCategory;
    const matchesSearch =
      searchFilter.trim() === '' ||
      p.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchFilter.toLowerCase()) ||
      p.barcode?.includes(searchFilter);
    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold">
            <Store className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white">
                {isSi ? 'භෞතික කඩේ සජීවී POS පර්යන්තය (Step 8: Physical Shop POS)' : 'Physical Counter POS Register Terminal'}
              </h2>
              <span className="text-[10px] bg-amber-950 text-amber-300 px-2 py-0.5 rounded-full border border-amber-800 font-bold">
                Counter #01 Active
              </span>
              <span className="text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-full border border-slate-700 flex items-center gap-1 font-semibold">
                <Lock className="w-2.5 h-2.5 text-amber-400" />
                <span>Admin Void Lock: ON</span>
              </span>
            </div>
            <p className="text-xs text-slate-400">
              {isSi
                ? 'කවුන්ටරයෙන් සිදුකරන සෑම විකිණීමක්ම සැනින් වෙබ් අඩවියේ තොගය (Online Stock) අඩුවීම සහතික කරයි.'
                : 'Every in-store walk-in sale automatically deducts central stock from the website in real time.'}
            </p>
          </div>
        </div>

        {/* Quick Barcode Scanner Box */}
        <form onSubmit={handleBarcodeSubmit} className="flex items-center gap-2 max-w-sm w-full">
          <div className="relative flex-1">
            <Barcode className="w-4 h-4 text-amber-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={barcodeInput}
              onChange={(e) => setBarcodeInput(e.target.value)}
              placeholder="Scan Barcode (e.g. 479200100101) & Enter..."
              className="w-full pl-9 pr-3 py-2 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-400 outline-none font-mono focus:border-amber-400"
            />
          </div>
          <button
            type="submit"
            className="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl text-xs font-bold cursor-pointer transition-colors"
          >
            Add
          </button>
        </form>
      </div>

      {feedback && (
        <div
          className={`p-3.5 rounded-2xl border text-xs flex items-center justify-between gap-2 font-bold animate-in fade-in ${
            feedback.type === 'success'
              ? 'bg-emerald-950/80 border-emerald-500/60 text-emerald-200'
              : 'bg-rose-950/80 border-rose-500/60 text-rose-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
          <button onClick={() => setFeedback(null)} className="text-slate-400 hover:text-white">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* POS Two-Column Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Product Catalog Grid & Quick Select (Col 7) */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-3xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
            <span className="text-xs font-bold text-slate-300">Quick Touch Catalog</span>
            <div className="relative max-w-[200px] w-full">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                placeholder="Search..."
                className="w-full pl-8 pr-2 py-1 bg-slate-800 border border-slate-700 rounded-lg text-xs text-white outline-none"
              />
            </div>
          </div>

          {/* Product Cards Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[520px] overflow-y-auto pr-1">
            {filteredProducts.map((p) => {
              const isLow = p.stock <= p.minStockAlert;
              return (
                <div
                  key={p.id}
                  onClick={() => addToPosCart(p, 1)}
                  className="bg-slate-850 hover:bg-slate-800 border border-slate-750 hover:border-amber-400/50 p-3 rounded-2xl cursor-pointer transition-all flex flex-col justify-between group active:scale-[0.98]"
                >
                  <div className="space-y-1.5">
                    <img
                      src={p.image}
                      alt={p.name}
                      className="w-full h-20 rounded-xl object-cover bg-slate-800"
                    />
                    <h4 className="font-bold text-white text-xs line-clamp-1 group-hover:text-amber-300">
                      {isSi ? p.nameSi : p.name}
                    </h4>
                    <span className="font-mono text-[10px] text-slate-400 block">{p.sku}</span>
                  </div>

                  <div className="pt-2 flex items-center justify-between border-t border-slate-750 text-xs">
                    <span className="font-bold text-emerald-400">Rs. {p.price.toLocaleString()}</span>
                    <span
                      className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                        p.stock <= 0
                          ? 'bg-rose-950 text-rose-300'
                          : isLow
                          ? 'bg-amber-950 text-amber-300'
                          : 'bg-emerald-950 text-emerald-300'
                      }`}
                    >
                      {p.stock} in stock
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Cashier Cart & Tender Machine (Col 5) */}
        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-4 h-4 text-amber-400" />
              <h3 className="font-bold text-white text-xs uppercase tracking-wider">
                Current Sale Items ({posCart.reduce((s, i) => s + i.quantity, 0)})
              </h3>
            </div>
            {posCart.length > 0 && (
              <button
                onClick={requestClearCart}
                className="text-[11px] text-rose-400 hover:text-rose-300 hover:underline cursor-pointer flex items-center gap-1 font-bold"
                title="Admin password required to clear cart"
              >
                <Lock className="w-3 h-3" />
                <span>Clear Cart</span>
              </button>
            )}
          </div>

          {/* Cart Items List */}
          <div className="space-y-2 max-h-[220px] overflow-y-auto">
            {posCart.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs space-y-1">
                <p>Scan barcode or tap an item on the left to add to sale.</p>
                <p className="text-[11px] text-slate-600">
                  {isSi ? 'භාණ්ඩයක් ඉවත් කිරීමට Admin මුරපදය අවශ්‍ය වේ.' : 'Admin PIN required to void/delete scanned items.'}
                </p>
              </div>
            ) : (
              posCart.map((item) => {
                const isWholesale = item.quantity >= item.product.wholesaleMinQty;
                const unitPrice = isWholesale ? item.product.wholesalePrice : item.product.price;
                const lineTotal = unitPrice * item.quantity;

                return (
                  <div
                    key={item.product.id}
                    className="p-2.5 bg-slate-800/80 rounded-xl border border-slate-700/80 flex items-center justify-between gap-2 text-xs"
                  >
                    <div className="flex-1 min-w-0">
                      <span className="font-bold text-white block truncate">{item.product.name}</span>
                      <span className="text-[10px] text-slate-400">
                        Rs. {unitPrice} × {item.quantity}
                        {isWholesale && (
                          <span className="text-emerald-400 ml-1 font-bold">Wholesale Tier</span>
                        )}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          if (item.quantity > 1) {
                            updateCartQty(item.product.id, -1);
                          } else {
                            requestRemoveItem(item.product);
                          }
                        }}
                        className="w-6 h-6 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 flex items-center justify-center font-bold cursor-pointer"
                        title={item.quantity === 1 ? 'Admin PIN needed to remove' : 'Decrease quantity'}
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="font-bold text-white w-4 text-center">{item.quantity}</span>
                      <button
                        onClick={() => updateCartQty(item.product.id, 1)}
                        className="w-6 h-6 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 flex items-center justify-center font-bold cursor-pointer"
                        title="Increase quantity"
                      >
                        <Plus className="w-3 h-3" />
                      </button>

                      {/* Locked Delete button: Prompt supervisor password */}
                      <button
                        onClick={() => requestRemoveItem(item.product)}
                        className="text-slate-400 hover:text-rose-400 p-1 rounded-lg hover:bg-slate-750 cursor-pointer flex items-center gap-0.5"
                        title="Admin authorization required to delete"
                      >
                        <Lock className="w-2.5 h-2.5 text-amber-400" />
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <span className="font-bold text-emerald-400 font-mono w-16 text-right">
                      Rs. {lineTotal.toLocaleString()}
                    </span>
                  </div>
                );
              })
            )}
          </div>

          {/* Customer CRM info */}
          <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-800">
            <div>
              <label className="text-[10px] text-slate-400 block mb-0.5">Customer Name</label>
              <input
                type="text"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                placeholder="Walk-in Customer"
                className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs outline-none"
              />
            </div>
            <div>
              <label className="text-[10px] text-slate-400 block mb-0.5">Phone (Loyalty Points)</label>
              <input
                type="text"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                placeholder="07X XXXXXXX"
                className="w-full px-2.5 py-1.5 bg-slate-800 border border-slate-700 rounded-lg text-white text-xs outline-none font-mono"
              />
            </div>
          </div>

          {/* Cash Tendered & Change Breakdown */}
          <div className="bg-slate-850 p-3.5 rounded-2xl border border-slate-750 space-y-2 text-xs">
            {totalCartSavings > 0 && (
              <div className="flex justify-between items-center text-slate-400">
                <span>Regular Total (සාමාන්‍ය මුළු එකතුව):</span>
                <span className="line-through font-mono">Rs. {totalRegularMRP.toLocaleString()}</span>
              </div>
            )}

            {totalCartSavings > 0 && (
              <div className="flex justify-between items-center text-emerald-300 font-bold bg-emerald-950/60 p-1.5 rounded-lg border border-emerald-800">
                <span>🔥 You Save (ලැබෙන වට්ටම):</span>
                <span className="font-mono text-xs font-black">-Rs. {totalCartSavings.toLocaleString()}</span>
              </div>
            )}

            <div className="flex justify-between items-center text-sm font-black pt-0.5">
              <span className="text-slate-300">SALE TOTAL:</span>
              <span className="text-emerald-400 text-base font-mono">Rs. {subtotal.toLocaleString()}</span>
            </div>

            {/* Quick Tender Currency Presets for Sri Lanka */}
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              <span className="text-[10px] text-slate-400">Quick:</span>
              <button
                type="button"
                onClick={() => setCashTendered(subtotal)}
                className="px-2 py-0.5 rounded bg-slate-750 hover:bg-slate-700 text-[10px] text-emerald-400 font-bold border border-slate-650 cursor-pointer"
              >
                Exact (Rs. {subtotal})
              </button>
              {[500, 1000, 2000, 5000].map((amount) => (
                <button
                  key={amount}
                  type="button"
                  onClick={() => setCashTendered(amount)}
                  className="px-2 py-0.5 rounded bg-slate-750 hover:bg-slate-700 text-[10px] text-slate-300 font-bold border border-slate-650 cursor-pointer"
                >
                  Rs. {amount}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setCashTendered('')}
                className="px-1.5 py-0.5 rounded bg-slate-800 text-[10px] text-slate-400 hover:text-white cursor-pointer ml-auto"
                title="Reset Cash Tendered to 0"
              >
                Clear
              </button>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-slate-750">
              <span className="text-slate-400 font-medium">Cash Tendered (Rs.):</span>
              <input
                type="number"
                value={cashTendered === '' ? '' : cashTendered}
                placeholder="0"
                onChange={(e) => setCashTendered(e.target.value === '' ? '' : Number(e.target.value))}
                className="w-28 text-right px-2.5 py-1.5 bg-slate-800 border border-slate-600 rounded-lg text-white font-mono font-bold outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400/50"
              />
            </div>

            <div className="flex justify-between items-center text-amber-300 font-bold pt-1">
              <span>CHANGE TO RETURN:</span>
              <span className="font-mono text-sm">Rs. {changeToReturn.toLocaleString()}</span>
            </div>
          </div>

          {/* Checkout & Print Action */}
          <button
            onClick={handleCompleteSale}
            disabled={posCart.length === 0}
            className={`w-full py-3.5 rounded-2xl text-xs font-black shadow-lg cursor-pointer flex items-center justify-center gap-2 transition-all active:scale-[0.98] ${
              posCart.length > 0
                ? 'bg-gradient-to-r from-amber-500 to-emerald-600 text-slate-950 shadow-emerald-500/20 hover:from-amber-400 hover:to-emerald-500'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Printer className="w-4 h-4" />
            <span>Complete Cash Sale & Print Thermal Receipt</span>
          </button>
        </div>
      </div>

      {/* Admin Supervisor PIN Authorization Modal for Voiding/Deleting Items */}
      {authModal && authModal.isOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-slate-900 border-2 border-amber-500/80 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2 text-amber-400 font-black text-sm">
                <ShieldAlert className="w-5 h-5 text-amber-400" />
                <span>{isSi ? 'Admin අවසරය අවශ්‍යයි (Supervisor Authorization)' : 'Admin Authorization Required'}</span>
              </div>
              <button
                onClick={() => setAuthModal(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-3 bg-amber-950/40 border border-amber-800/60 rounded-xl text-xs text-amber-200/90 space-y-1">
              <p className="font-bold flex items-center gap-1.5 text-amber-300">
                <Lock className="w-3.5 h-3.5" />
                <span>
                  {authModal.type === 'clear_cart'
                    ? (isSi ? 'සම්පූර්ණ බිල අවලංගු කිරීම (Void Bill)' : 'Void & Clear Whole Bill')
                    : (isSi ? 'භාණ්ඩයක් බිලෙන් ඉවත් කිරීම (Delete Scanned Item)' : 'Delete Scanned Item')}
                </span>
              </p>
              {authModal.productName && (
                <p className="text-[11px] text-white font-semibold">
                  Item: <span className="text-amber-400">{authModal.productName}</span>
                </p>
              )}
              <p className="text-[11px] text-slate-400">
                {isSi
                  ? 'කවුන්ටර සේවකයින්ට භාණ්ඩ ඉවත් කිරීමට අවසර නැත. ඉදිරියට යාමට Supervisor/Admin PIN එක ඇතුළත් කරන්න.'
                  : 'Cashiers are not authorized to delete items without supervisor approval.'}
              </p>
            </div>

            <form onSubmit={handleVerifyAdminAuth} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-amber-400" />
                  <span>{isSi ? 'Admin මුරපදය / PIN එක ඇතුළත් කරන්න:' : 'Enter Admin / Supervisor PIN:'}</span>
                </label>
                <input
                  type="password"
                  autoFocus
                  required
                  value={adminPinInput}
                  onChange={(e) => setAdminPinInput(e.target.value)}
                  placeholder="Enter PIN (Default: 1234)"
                  className="w-full px-3 py-2.5 bg-slate-800 border-2 border-slate-700 focus:border-amber-400 rounded-xl text-white font-mono text-center tracking-widest text-lg outline-none"
                />
                <span className="text-[10px] text-slate-500 mt-1 block text-center font-mono">
                  Default Admin PIN: <strong className="text-amber-400">1234</strong>
                </span>
              </div>

              {authError && (
                <div className="p-2 rounded-lg bg-rose-950/80 border border-rose-600 text-rose-300 text-xs font-bold text-center">
                  {authError}
                </div>
              )}

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setAuthModal(null)}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                >
                  {isSi ? 'අවලංගු කරන්න' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-md cursor-pointer transition-all"
                >
                  {isSi ? 'අවසර ලබා දී ඉවත් කරන්න' : 'Authorize & Delete'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Sale Completed & Thermal Printable Receipt Modal */}
      {lastCompletedOrder && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in duration-200">
            {/* Header with success and Close action */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="font-black text-white text-sm">
                    {isSi ? 'බිල සාර්ථකව අවසන් විය!' : 'Sale Successfully Completed!'}
                  </h3>
                  <p className="text-[11px] text-emerald-400 font-mono">
                    Order #{lastCompletedOrder.orderNumber}
                  </p>
                </div>
              </div>
              <button
                onClick={handleStartNewBill}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
                title="Close"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Printable Thermal Receipt Box (formatted for 80mm ESC/POS) */}
            <div
              id="thermal-receipt-print-area"
              className="p-4 bg-white text-slate-900 rounded-2xl shadow-inner border border-slate-300 font-mono text-xs space-y-2.5"
            >
              <div className="text-center border-b pb-2 space-y-0.5">
                <h4 className="font-black text-sm tracking-tight">SMAPA 27 MEGA STORE</h4>
                <p className="text-[10px] text-slate-600">128, High Level Road, Maharagama</p>
                <p className="text-[10px] text-slate-600">Hotline: 077 477 8190</p>
                <span className="text-[9px] bg-slate-100 px-2 py-0.5 rounded font-bold uppercase inline-block mt-1">
                  POS Counter Cash Receipt
                </span>
              </div>

              <div className="text-[11px] space-y-0.5">
                <div className="flex justify-between">
                  <span>Receipt #:</span>
                  <span className="font-bold">{lastCompletedOrder.orderNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span>Date:</span>
                  <span>{new Date(lastCompletedOrder.createdAt).toLocaleTimeString()}</span>
                </div>
                <div className="flex justify-between">
                  <span>Cashier:</span>
                  <span>Register #01</span>
                </div>
                <div className="flex justify-between">
                  <span>Customer:</span>
                  <span>{lastCompletedOrder.customer.name}</span>
                </div>
              </div>

              {(() => {
                const receiptMRP = lastCompletedOrder.items.reduce((sum, it) => {
                  const orig = (it.product.originalPrice && it.product.originalPrice > it.unitPrice)
                    ? it.product.originalPrice
                    : it.unitPrice;
                  return sum + orig * it.quantity;
                }, 0);
                const receiptDiscount = Math.max(lastCompletedOrder.discount || 0, Math.max(0, receiptMRP - lastCompletedOrder.total));

                return (
                  <>
                    <div className="border-t border-b py-2 space-y-1.5 text-[11px]">
                      {lastCompletedOrder.items.map((it, idx) => {
                        const hasDiscount = it.product.originalPrice && it.product.originalPrice > it.unitPrice;
                        return (
                          <div key={idx} className="flex justify-between items-start">
                            <div className="truncate max-w-[210px]">
                              <span className="font-semibold block">{it.product.name} × {it.quantity}</span>
                              {hasDiscount && (
                                <span className="text-[10px] text-slate-500">
                                  MRP <span className="line-through">Rs. {it.product.originalPrice?.toLocaleString()}</span> ➔ Rs. {it.unitPrice.toLocaleString()}
                                </span>
                              )}
                            </div>
                            <span className="font-bold shrink-0">
                              Rs. {(it.unitPrice * it.quantity).toLocaleString()}
                            </span>
                          </div>
                        );
                      })}
                    </div>

                    <div className="space-y-1 text-[11px] pt-1">
                      {receiptDiscount > 0 && (
                        <div className="flex justify-between text-slate-600">
                          <span>Items Regular Total:</span>
                          <span className="line-through">Rs. {receiptMRP.toLocaleString()}</span>
                        </div>
                      )}

                      {receiptDiscount > 0 && (
                        <div className="flex justify-between font-bold text-emerald-800 bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200">
                          <span>🎉 TOTAL DISCOUNT (වට්ටම):</span>
                          <span>-Rs. {receiptDiscount.toLocaleString()}</span>
                        </div>
                      )}

                      <div className="flex justify-between font-bold text-sm pt-0.5 border-t">
                        <span>Net Payable Total:</span>
                        <span className="font-black text-slate-900">Rs. {lastCompletedOrder.total.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Cash Tendered:</span>
                        <span>Rs. {(lastCompletedOrder.cashTendered || lastCompletedOrder.total).toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between font-bold text-emerald-700">
                        <span>Change Returned:</span>
                        <span>Rs. {(lastCompletedOrder.changeGiven || 0).toLocaleString()}</span>
                      </div>
                    </div>

                    {receiptDiscount > 0 && (
                      <div className="text-center py-1.5 my-1 bg-amber-50 border border-amber-300 rounded text-[11px] font-black text-amber-900">
                        ⭐ YOU SAVED Rs. {receiptDiscount.toLocaleString()} TODAY! ⭐
                        <span className="block text-[10px] font-bold text-amber-800">
                          අද ඔබ ලැබූ මුළු ඉතිරිය: රු. {receiptDiscount.toLocaleString()}
                        </span>
                      </div>
                    )}
                  </>
                );
              })()}

              <div className="text-center pt-2 border-t text-[10px] text-slate-600">
                <p>Thank you for shopping with us!</p>
                <p>ස්තුතියි! නැවත එන්න.</p>
              </div>
            </div>

            {/* Print & Next Bill Buttons */}
            <div className="space-y-2 pt-2">
              <button
                onClick={handlePrintAndStartNew}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-black rounded-xl text-xs shadow-lg cursor-pointer flex items-center justify-center gap-2 transition-all active:scale-[0.98]"
              >
                <Printer className="w-4 h-4 text-slate-950" />
                <span>{isSi ? '🖨️ බිල Print කර අලුත් බිලකට යන්න' : '🖨️ Print Receipt & Start New Bill'}</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrintReceipt}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-750 text-white font-bold rounded-xl text-xs border border-slate-700 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>{isSi ? 'Print පමණක් කරන්න' : 'Print Only'}</span>
                </button>

                <button
                  onClick={handleStartNewBill}
                  className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-750 text-emerald-400 font-bold rounded-xl text-xs border border-emerald-700/60 cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{isSi ? 'අලුත් බිලකට යන්න ➔' : 'Start New Bill ➔'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
