import React, { useState, useRef, useEffect } from 'react';
import {
  Upload, Sparkles, Image as ImageIcon, Camera, Trash2, Check,
  RefreshCw, Sliders, Eye, Wand2, ShieldCheck, Download
} from 'lucide-react';
import { Language } from '../../types';

interface ProductImageStudioUploaderProps {
  lang: Language;
  imageUrl: string;
  onChange: (newUrl: string) => void;
  productName?: string;
  category?: string;
}

// Curated high-res studio product presets for fast 1-click fallback
const SRI_LANKAN_STUDIO_PRESETS = [
  {
    name: 'Munchee Chocolate Biscuit',
    nameSi: 'මැන්චි චොක්ලට් බිස්කට්',
    category: 'biscuits-sweets',
    url: 'https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Munchee Cream Cracker (500g)',
    nameSi: 'මැන්චි සුපර් ක්‍රීම් ක්‍රැකර්',
    category: 'biscuits-sweets',
    url: 'https://images.unsplash.com/photo-1590080875515-8a3a8dc5735e?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Araliya Keeri Samba (5kg)',
    nameSi: 'අරලිය කීරි සම්බා සහල්',
    category: 'rice',
    url: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Nipuna Red Raw Rice (5kg)',
    nameSi: 'නිපුණ රතු කැකුළු සහල්',
    category: 'rice',
    url: 'https://images.unsplash.com/photo-1536304993881-ff6e9eefa2a6?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Anchor Milk Powder (400g)',
    nameSi: 'ඇන්කර් ෆුල් ක්‍රීම් කිරිපිටි',
    category: 'dairy-milk',
    url: 'https://images.unsplash.com/photo-1550583724-b2692b85b150?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Sunlight Soap (Pack of 4)',
    nameSi: 'සන්ලයිට් සබන් කැට 4',
    category: 'soap',
    url: 'https://images.unsplash.com/photo-1607006314368-809c916fc3ea?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Mysore Red Dhal (1kg)',
    nameSi: 'මයිසූර් රතු පරිප්පු',
    category: 'dhal-legumes',
    url: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Marina Coconut Oil (750ml)',
    nameSi: 'මැරීනා පිරිසිදු පොල්තෙල්',
    category: 'cooking-oils',
    url: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Wijaya Roasted Curry (250g)',
    nameSi: 'විජය බැදපු තුනපහ',
    category: 'spices',
    url: 'https://images.unsplash.com/photo-1596040033229-a9821ebd058d?auto=format&fit=crop&w=600&q=80'
  },
  {
    name: 'Fresh Farm Potatoes (1kg)',
    nameSi: 'නැවුම් නුවරඑළිය අල',
    category: 'vegetables',
    url: 'https://images.unsplash.com/photo-1518977676601-b53f82aba655?auto=format&fit=crop&w=600&q=80'
  }
];

export const ProductImageStudioUploader: React.FC<ProductImageStudioUploaderProps> = ({
  lang,
  imageUrl,
  onChange,
  productName,
  category
}) => {
  const isSi = lang === 'si';
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [rawImage, setRawImage] = useState<string>(imageUrl || '');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [backgroundMode, setBackgroundMode] = useState<'white' | 'transparent' | 'gradient' | 'original'>('white');
  const [tolerance, setTolerance] = useState<number>(38);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [showPresets, setShowPresets] = useState<boolean>(false);

  useEffect(() => {
    if (imageUrl && !rawImage) {
      setRawImage(imageUrl);
    }
  }, [imageUrl]);

  // Handle file upload from PC / Phone
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  const processSelectedFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert(isSi ? 'කරුණාකර ඡායාරූප ගොනුවක් (Image) තෝරන්න.' : 'Please select an image file.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        setRawImage(result);
        // Automatically perform background removal & studio enhancement
        applyStudioEnhancement(result, 'white', tolerance);
      }
    };
    reader.readAsDataURL(file);
  };

  // Drag and Drop support
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processSelectedFile(file);
    }
  };

  // Canvas-based Automatic Background Removal & Studio Cutout
  const applyStudioEnhancement = (
    imageSrc: string,
    mode: 'white' | 'transparent' | 'gradient' | 'original',
    tol: number = 38
  ) => {
    if (!imageSrc) return;

    if (mode === 'original') {
      setBackgroundMode('original');
      onChange(imageSrc);
      setStatusMessage(isSi ? 'මුල් ඡායාරූපය තෝරාගන්නා ලදී.' : 'Original photo selected.');
      return;
    }

    setIsProcessing(true);
    setStatusMessage(isSi ? 'පසුබිම ඉවත් කරමින් පවතී... ✨' : 'Removing background & enhancing... ✨');

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      try {
        const canvas = canvasRef.current || document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          setIsProcessing(false);
          return;
        }

        // Standard square e-commerce size for crystal-clear presentation
        const targetSize = 600;
        canvas.width = targetSize;
        canvas.height = targetSize;

        // Draw temporary image to extract pixels
        const tempCanvas = document.createElement('canvas');
        const tempCtx = tempCanvas.getContext('2d');
        if (!tempCtx) {
          setIsProcessing(false);
          return;
        }

        tempCanvas.width = img.width;
        tempCanvas.height = img.height;
        tempCtx.drawImage(img, 0, 0);

        const imgData = tempCtx.getImageData(0, 0, img.width, img.height);
        const data = imgData.data;

        // Sample corner pixels to determine dominant background color
        const corners = [
          { x: 0, y: 0 },
          { x: img.width - 1, y: 0 },
          { x: 0, y: img.height - 1 },
          { x: img.width - 1, y: img.height - 1 },
          { x: Math.floor(img.width / 2), y: 0 }, // Top middle
          { x: 0, y: Math.floor(img.height / 2) }  // Left middle
        ];

        let bgR = 0, bgG = 0, bgB = 0;
        corners.forEach((c) => {
          const idx = (c.y * img.width + c.x) * 4;
          bgR += data[idx];
          bgG += data[idx + 1];
          bgB += data[idx + 2];
        });
        bgR = Math.round(bgR / corners.length);
        bgG = Math.round(bgG / corners.length);
        bgB = Math.round(bgB / corners.length);

        // Alpha mask removal with Euclidean color distance & edge feathering
        const threshold = tol * 2.5;

        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];

          // Euclidean color distance from background
          const dist = Math.sqrt(
            Math.pow(r - bgR, 2) + Math.pow(g - bgG, 2) + Math.pow(b - bgB, 2)
          );

          if (dist < threshold) {
            // Background detected - make transparent
            data[i + 3] = 0;
          } else if (dist < threshold + 15) {
            // Feather edge smoothing for crisp silhouette
            const alpha = ((dist - threshold) / 15) * 255;
            data[i + 3] = Math.min(data[i + 3], alpha);
          }
        }

        tempCtx.putImageData(imgData, 0, 0);

        // Render to Final Canvas with Studio Backdrop
        ctx.clearRect(0, 0, targetSize, targetSize);

        if (mode === 'white') {
          // Studio Pure White Backdrop
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, targetSize, targetSize);

          // Subtle grounded soft product floor shadow for high-end look
          const shadowGradient = ctx.createRadialGradient(
            targetSize / 2,
            targetSize - 70,
            20,
            targetSize / 2,
            targetSize - 70,
            180
          );
          shadowGradient.addColorStop(0, 'rgba(0, 0, 0, 0.14)');
          shadowGradient.addColorStop(0.6, 'rgba(0, 0, 0, 0.04)');
          shadowGradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

          ctx.fillStyle = shadowGradient;
          ctx.beginPath();
          ctx.ellipse(targetSize / 2, targetSize - 70, 180, 25, 0, 0, Math.PI * 2);
          ctx.fill();
        } else if (mode === 'gradient') {
          // Soft supermarket catalog light gradient
          const grad = ctx.createLinearGradient(0, 0, 0, targetSize);
          grad.addColorStop(0, '#F8FAFC');
          grad.addColorStop(1, '#EDF2F7');
          ctx.fillStyle = grad;
          ctx.fillRect(0, 0, targetSize, targetSize);
        }

        // Fit & Center the isolated product inside the square frame (82% scale with padding)
        const scale = Math.min((targetSize * 0.82) / img.width, (targetSize * 0.82) / img.height);
        const w = img.width * scale;
        const h = img.height * scale;
        const x = (targetSize - w) / 2;
        const y = (targetSize - h) / 2 - 10;

        ctx.drawImage(tempCanvas, x, y, w, h);

        const finalDataUrl = canvas.toDataURL('image/png', 0.95);
        setBackgroundMode(mode);
        onChange(finalDataUrl);
        setIsProcessing(false);
        setStatusMessage(
          isSi
            ? '✅ පසුබිම සාර්ථකව ඉවත් කර Studio ඡායාරූපය සාදන ලදී!'
            : '✅ Background removed! Studio presentation ready.'
        );
      } catch (err) {
        console.error('Canvas processing error:', err);
        // Fallback to original image if cross-origin tainted
        onChange(imageSrc);
        setIsProcessing(false);
        setStatusMessage(isSi ? 'ඡායාරූපය සාර්ථකව ඇතුළත් විය.' : 'Photo saved successfully.');
      }
    };

    img.onerror = () => {
      setIsProcessing(false);
      onChange(imageSrc);
    };

    img.src = imageSrc;
  };

  const handleSelectPreset = (presetUrl: string) => {
    setRawImage(presetUrl);
    applyStudioEnhancement(presetUrl, 'white', tolerance);
    setShowPresets(false);
  };

  return (
    <div className="space-y-3 bg-slate-900/90 p-4 rounded-2xl border-2 border-emerald-500/60 shadow-lg">
      <canvas ref={canvasRef} className="hidden" />

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-800">
        <label className="text-xs font-black text-white flex items-center gap-1.5">
          <Wand2 className="w-4 h-4 text-emerald-400" />
          <span>{isSi ? 'භාණ්ඩයේ ඡායාරූපය & Studio පසුබිම ඉවත් කිරීම (Background Remover)' : 'Product Photo & Studio Background Remover'}</span>
        </label>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowPresets(!showPresets)}
            className="text-[11px] font-bold text-amber-300 hover:text-amber-200 bg-amber-500/10 hover:bg-amber-500/20 px-2.5 py-1 rounded-lg border border-amber-500/40 flex items-center gap-1 cursor-pointer transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{showPresets ? 'Close Presets' : (isSi ? 'Ready Presets (ලංකාවේ බඩු)' : 'Sri Lankan Presets')}</span>
          </button>
        </div>
      </div>

      {/* Preset Picker Dropdown if toggled */}
      {showPresets && (
        <div className="p-3 bg-slate-950 rounded-xl border border-amber-500/50 space-y-2 animate-in fade-in">
          <div className="text-[11px] font-bold text-amber-300 flex items-center justify-between">
            <span>✨ ක්ෂණික Studio Presets (One-Click Sri Lankan Studio Photos):</span>
            <span className="text-[10px] text-slate-400">Click to apply</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 max-h-48 overflow-y-auto pr-1">
            {SRI_LANKAN_STUDIO_PRESETS.map((p, idx) => (
              <div
                key={idx}
                onClick={() => handleSelectPreset(p.url)}
                className="bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-emerald-400 rounded-xl p-2 cursor-pointer transition-all flex flex-col items-center text-center space-y-1 group"
              >
                <div className="w-12 h-12 rounded-lg overflow-hidden bg-white p-1 flex items-center justify-center">
                  <img src={p.url} alt={p.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform" />
                </div>
                <span className="text-[10px] font-bold text-slate-200 line-clamp-1">{isSi ? p.nameSi : p.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Studio Upload & Preview Section */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
        {/* Left: Live 1:1 Studio Preview Box */}
        <div className="sm:col-span-5 flex flex-col items-center">
          <div className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-2xl overflow-hidden border-2 border-emerald-400 shadow-xl flex items-center justify-center bg-white group">
            {/* Background pattern indicator */}
            {backgroundMode === 'transparent' && (
              <div
                className="absolute inset-0 opacity-40 pointer-events-none"
                style={{
                  backgroundImage:
                    'linear-gradient(45deg, #e2e8f0 25%, transparent 25%), linear-gradient(-45deg, #e2e8f0 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #e2e8f0 75%), linear-gradient(-45deg, transparent 75%, #e2e8f0 75%)',
                  backgroundSize: '16px 16px',
                  backgroundPosition: '0 0, 0 8px, 8px -8px, -8px 0px'
                }}
              />
            )}

            {imageUrl ? (
              <img
                src={imageUrl}
                alt="Product Preview"
                className="w-full h-full object-contain p-2 relative z-10 transition-transform group-hover:scale-105"
              />
            ) : (
              <div className="text-center p-4 text-slate-400 space-y-1">
                <ImageIcon className="w-10 h-10 mx-auto text-slate-300" />
                <span className="text-[11px] block">{isSi ? 'ඡායාරූපයක් නැත' : 'No photo yet'}</span>
              </div>
            )}

            {/* Processing Spinner Overlay */}
            {isProcessing && (
              <div className="absolute inset-0 z-20 bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-center text-emerald-400 space-y-2">
                <RefreshCw className="w-7 h-7 animate-spin" />
                <span className="text-[11px] font-bold">{isSi ? 'පසුබිම ඉවත් වෙමින්...' : 'Cutting out background...'}</span>
              </div>
            )}

            {/* Badge on Preview */}
            <div className="absolute top-2 right-2 z-20 bg-slate-900/80 backdrop-blur-md text-emerald-300 text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border border-emerald-500/40">
              {backgroundMode === 'white' && '⚪ Studio White'}
              {backgroundMode === 'transparent' && '🌫️ Cutout PNG'}
              {backgroundMode === 'gradient' && '🎨 Studio Grad'}
              {backgroundMode === 'original' && '📷 Original'}
            </div>
          </div>

          {/* Feedback message */}
          {statusMessage && (
            <p className="text-[11px] text-emerald-400 font-semibold mt-1.5 text-center">
              {statusMessage}
            </p>
          )}
        </div>

        {/* Right: Upload Actions & Background Removal Controls */}
        <div className="sm:col-span-7 space-y-3">
          {/* Drag & Drop or Upload Trigger */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-2xl p-3 sm:p-4 text-center transition-all cursor-pointer ${
              isDragging
                ? 'border-emerald-400 bg-emerald-950/30'
                : 'border-slate-700 hover:border-emerald-500/80 bg-slate-800/60'
            }`}
            onClick={() => fileInputRef.current?.click()}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="hidden"
            />
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleFileChange}
              className="hidden"
            />

            <div className="flex items-center justify-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center shadow-inner">
                <Upload className="w-5 h-5" />
              </div>
              <div className="text-left">
                <h5 className="font-black text-white text-xs">
                  {isSi ? 'ඡායාරූපය Upload කරන්න (Phone / PC)' : 'Upload from Phone or PC'}
                </h5>
                <p className="text-[10px] text-slate-400">
                  {isSi ? 'ඡායාරූපය Drag කර හෝ Click කර තෝරන්න (JPG, PNG, WebP)' : 'Click to browse file or drag & drop image'}
                </p>
              </div>
            </div>

            {/* Quick action buttons */}
            <div className="flex items-center justify-center gap-2 pt-2 mt-2 border-t border-slate-700/60">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  cameraInputRef.current?.click();
                }}
                className="flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] font-bold rounded-lg border border-slate-600 cursor-pointer"
              >
                <Camera className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isSi ? 'කැමරාවෙන් ගන්න' : 'Camera'}</span>
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  fileInputRef.current?.click();
                }}
                className="flex items-center gap-1 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-bold rounded-lg cursor-pointer shadow-md"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{isSi ? 'File එකක් තෝරන්න' : 'Browse File'}</span>
              </button>
            </div>
          </div>

          {/* Background Removal Studio Modes */}
          <div className="bg-slate-800/90 p-3 rounded-xl border border-slate-700 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-bold text-slate-300">
              <span className="flex items-center gap-1 text-emerald-400">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isSi ? 'Studio පසුබිම් මාදිලිය (Backdrop Mode):' : 'Backdrop Presentation Mode:'}</span>
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs">
              <button
                type="button"
                onClick={() => applyStudioEnhancement(rawImage || imageUrl, 'white', tolerance)}
                className={`flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                  backgroundMode === 'white'
                    ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-700'
                }`}
              >
                <span>⚪ White Studio</span>
              </button>

              <button
                type="button"
                onClick={() => applyStudioEnhancement(rawImage || imageUrl, 'transparent', tolerance)}
                className={`flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                  backgroundMode === 'transparent'
                    ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-700'
                }`}
              >
                <span>🌫️ Cutout PNG</span>
              </button>

              <button
                type="button"
                onClick={() => applyStudioEnhancement(rawImage || imageUrl, 'gradient', tolerance)}
                className={`flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                  backgroundMode === 'gradient'
                    ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-700'
                }`}
              >
                <span>🎨 Light Grad</span>
              </button>

              <button
                type="button"
                onClick={() => applyStudioEnhancement(rawImage || imageUrl, 'original', tolerance)}
                className={`flex items-center justify-center gap-1 px-2 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                  backgroundMode === 'original'
                    ? 'bg-amber-400 text-slate-950 font-black shadow-md'
                    : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-700'
                }`}
              >
                <span>📷 Original</span>
              </button>
            </div>

            {/* Threshold fine-tune slider */}
            <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between gap-3 text-[10px] text-slate-400">
              <span className="flex items-center gap-1">
                <Sliders className="w-3 h-3 text-slate-400" />
                <span>{isSi ? 'පසුබිම් ඉවත්කිරීමේ සැර (Clean Sensitivity):' : 'Cutout Sensitivity:'}</span>
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min={15}
                  max={70}
                  value={tolerance}
                  onChange={(e) => {
                    const newTol = Number(e.target.value);
                    setTolerance(newTol);
                    applyStudioEnhancement(rawImage || imageUrl, backgroundMode, newTol);
                  }}
                  className="w-24 accent-emerald-500 cursor-pointer"
                />
                <span className="font-mono text-emerald-400 font-bold">{tolerance}</span>
              </div>
            </div>
          </div>

          {/* Web Image URL Alternative Input */}
          <div className="space-y-1">
            <label className="text-[10px] text-slate-400 block">
              {isSi ? 'හෝ Image Web URL එකක් Paste කරන්න:' : 'Or paste direct Image Web URL:'}
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={imageUrl}
                onChange={(e) => {
                  onChange(e.target.value);
                  setRawImage(e.target.value);
                }}
                placeholder="https://images.unsplash.com/..."
                className="w-full px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-xl text-white outline-none text-xs font-mono"
              />
              {imageUrl && (
                <button
                  type="button"
                  onClick={() => applyStudioEnhancement(imageUrl, 'white', tolerance)}
                  className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold cursor-pointer whitespace-nowrap shadow-sm"
                  title="Remove background from this URL"
                >
                  ✨ Cutout
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
