import React from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag, ArrowRight, MessageCircle } from 'lucide-react';
import { CartItem, Language } from '../types';
import { TRANSLATIONS } from '../translations';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  lang: Language;
  onUpdateQty: (productId: string, qty: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onProceedToCheckout: () => void;
  onQuickWhatsAppOrder: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  lang,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
  onProceedToCheckout,
  onQuickWhatsAppOrder,
}) => {
  if (!isOpen) return null;

  const t = TRANSLATIONS[lang];
  const isSi = lang === 'si';

  const subtotal = items.reduce((sum, item) => sum + (item.unitPrice || item.product.price) * item.quantity, 0);
  const totalItemCount = items.reduce((sum, item) => sum + item.quantity, 0);
  const totalRegularPrice = items.reduce((sum, item) => {
    const orig = item.product.originalPrice && item.product.originalPrice > item.product.price
      ? item.product.originalPrice
      : item.product.price;
    return sum + orig * item.quantity;
  }, 0);
  const totalSavings = Math.max(0, totalRegularPrice - subtotal);

  return (
    <div className="fixed inset-0 z-50 overflow-hidden animate-in fade-in duration-200">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="absolute inset-0 bg-slate-950/60 backdrop-blur-xs transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col">
          {/* Drawer Header */}
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-slate-900">{t.cart}</h2>
                <p className="text-xs text-slate-500 font-medium">
                  {totalItemCount} {t.itemsInCart}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              {items.length > 0 && (
                <button
                  onClick={onClearCart}
                  className="text-xs text-rose-600 hover:text-rose-700 font-medium px-2 py-1 rounded-lg hover:bg-rose-50 cursor-pointer transition-colors"
                >
                  {isSi ? 'හිස් කරන්න' : 'Clear'}
                </button>
              )}
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 flex items-center justify-center cursor-pointer transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Drawer Body - Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
            {items.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400 space-y-3">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center text-slate-300">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <p className="text-sm font-semibold text-slate-600">{t.emptyCart}</p>
                <button
                  onClick={onClose}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl cursor-pointer shadow-sm transition-colors"
                >
                  {t.startShopping}
                </button>
              </div>
            ) : (
              items.map((item) => {
                const effectivePrice = item.unitPrice || item.product.price;
                const itemTotal = effectivePrice * item.quantity;
                const isMaxStock = item.quantity >= item.product.stock;

                return (
                  <div
                    key={item.product.id}
                    className="flex gap-3 bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-200 transition-colors"
                  >
                    {/* Image */}
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-16 h-16 rounded-xl object-cover bg-slate-100 shrink-0"
                    />

                    {/* Info */}
                    <div className="flex-1 min-w-0 flex flex-col justify-between">
                      <div>
                        <div className="flex items-start justify-between gap-1">
                          <h4 className="text-xs font-bold text-slate-900 truncate">
                            {isSi ? item.product.nameSi : item.product.name}
                          </h4>
                          <button
                            onClick={() => onRemoveItem(item.product.id)}
                            className="text-slate-300 hover:text-rose-500 cursor-pointer transition-colors p-0.5"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="flex items-center gap-1.5 flex-wrap text-[11px] text-slate-500">
                          <span>{isSi ? item.product.unitSi : item.product.unit} •</span>
                          {item.product.originalPrice && item.product.originalPrice > effectivePrice && (
                            <span className="line-through text-slate-400 text-[10px]">
                              Rs. {item.product.originalPrice.toLocaleString()}
                            </span>
                          )}
                          <span className="font-bold text-slate-900">Rs. {effectivePrice.toLocaleString()}</span>
                          {item.isWholesaleApplied && (
                            <span className="px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                              Wholesale Rate
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Controls and item total */}
                      <div className="flex items-center justify-between pt-1.5">
                        <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
                          <button
                            onClick={() => onUpdateQty(item.product.id, item.quantity - 1)}
                            className="px-2 py-0.5 hover:bg-slate-200 text-slate-700 font-bold transition-colors cursor-pointer"
                          >
                            <Minus className="w-3 h-3" />
                          </button>
                          <span className="px-2 text-xs font-bold text-slate-900 min-w-[1.5rem] text-center">
                            {item.quantity}
                          </span>
                          <button
                            onClick={() => onUpdateQty(item.product.id, item.quantity + 1)}
                            disabled={isMaxStock}
                            className={`px-2 py-0.5 text-slate-700 font-bold transition-colors ${
                              isMaxStock ? 'opacity-30 cursor-not-allowed' : 'hover:bg-slate-200 cursor-pointer'
                            }`}
                            title={isMaxStock ? 'Maximum available stock reached' : 'Add one more'}
                          >
                            <Plus className="w-3 h-3" />
                          </button>
                        </div>

                        <span className="text-xs font-extrabold text-slate-900">
                          Rs. {itemTotal.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Drawer Footer - Calculations & Actions */}
          {items.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-slate-200/80 bg-slate-50/70 space-y-3">
              {totalSavings > 0 && (
                <div className="bg-gradient-to-r from-emerald-100/90 via-teal-50 to-amber-100/80 border border-emerald-300 rounded-xl p-2.5 flex items-center justify-between text-xs text-emerald-950 font-bold shadow-xs">
                  <div className="flex items-center gap-1.5">
                    <span className="text-base animate-bounce">🎉</span>
                    <span>{isSi ? 'ඔබ ඉතිරි කරගත් මුළු මුදල:' : 'You are saving on this order:'}</span>
                  </div>
                  <span className="text-emerald-700 font-black text-sm">
                    Rs. {totalSavings.toLocaleString()}
                  </span>
                </div>
              )}

              <div className="space-y-1.5 text-xs">
                <div className="flex justify-between text-slate-600 font-medium">
                  <span>{t.subtotal}</span>
                  <div className="text-right">
                    {totalSavings > 0 && (
                      <span className="text-[11px] text-slate-400 line-through mr-1.5">
                        Rs. {totalRegularPrice.toLocaleString()}
                      </span>
                    )}
                    <span className="font-bold text-slate-900">Rs. {subtotal.toLocaleString()}</span>
                  </div>
                </div>
                <div className="flex justify-between text-slate-500">
                  <span>{t.deliveryFee}</span>
                  <span className="italic">{isSi ? 'චෙක්අවුට් එකේදී ගණනය කෙරේ' : 'Calculated at checkout'}</span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-1">
                <button
                  onClick={onProceedToCheckout}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-lg shadow-emerald-600/25 flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-[0.99] text-xs sm:text-sm"
                >
                  <span>{t.checkout}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  onClick={onQuickWhatsAppOrder}
                  className="w-full py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 font-semibold rounded-xl flex items-center justify-center gap-2 cursor-pointer transition-colors text-xs"
                >
                  <MessageCircle className="w-4 h-4 text-emerald-600" />
                  <span>{t.orderViaWhatsApp}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
